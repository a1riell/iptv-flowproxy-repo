"""
Entrypoint de servicio para Kodi: service.iptv.flowproxy
"""

import sys
import threading

try:
    import xbmc
    import xbmcaddon
    IN_KODI = True
except ImportError:
    IN_KODI = False

from resources.lib.local_server import FlowProxyHandler, ThreadedHTTPServer

DEFAULT_PORT = 18080


def get_configured_port() -> int:
    if IN_KODI:
        try:
            addon = xbmcaddon.Addon()
            val = addon.getSetting("proxy_port")
            if val:
                return int(val)
        except Exception:
            pass
    return DEFAULT_PORT


def run_server(port: int) -> None:
    server_address = ("127.0.0.1", port)
    httpd = ThreadedHTTPServer(server_address, FlowProxyHandler)
    msg = f"[IPTV FlowProxy] Servidor iniciado en http://127.0.0.1:{port}"
    if IN_KODI:
        xbmc.log(msg, level=xbmc.LOGINFO)
    else:
        print(msg)
    httpd.serve_forever()


if __name__ == "__main__":
    port = get_configured_port()
    server_thread = threading.Thread(target=run_server, args=(port,), daemon=True)
    server_thread.start()

    if IN_KODI:
        monitor = xbmc.Monitor()
        while not monitor.abortRequested():
            if monitor.waitForAbort(2):
                break
        xbmc.log("[IPTV FlowProxy] Servicio detenido limpiamente", level=xbmc.LOGINFO)
    else:
        print("[IPTV FlowProxy] Ejecutando en modo standalone (presione Ctrl+C para salir)...")
        try:
            import time
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("[IPTV FlowProxy] Detenido.")
            sys.exit(0)
