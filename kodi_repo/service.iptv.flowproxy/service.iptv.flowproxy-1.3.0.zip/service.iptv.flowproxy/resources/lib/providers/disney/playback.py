"""
Motor de resolución de Playback para Disney+ (BAMGrid).
"""
from __future__ import annotations

import base64
import json
import logging
import re
import time
from typing import Optional

from .client_contract import ChromeWebContract
from .http_transport import DefaultHttpTransport, HttpTransport, UpstreamHttpError
from .models import DrmEndpointKind, PlaybackContext

logger = logging.getLogger("flowproxy_disney_playback")


class DisneyPlaybackEngine:
    def __init__(
        self,
        transport: Optional[HttpTransport] = None,
        contract: Optional[ChromeWebContract] = None,
    ) -> None:
        self._transport = transport or DefaultHttpTransport()
        self._contract = contract or ChromeWebContract()

    def resolve(
        self,
        resource_id: str,
        content_type: str = "live",
        access_token: str = "",
        max_resolution: str = "1280x720",
        fps: int = 60,
    ) -> PlaybackContext:
        """
        Solicita la sesión de reproducción a BAMGrid /v7/playback/ctr-regular
        y retorna el PlaybackContext inmutable asociado.
        """
        now = time.time()
        headers = self._contract.build_playback_headers(access_token)
        payload = self._contract.build_playback_payload(
            resource_id=resource_id,
            content_type=content_type,
            max_resolution=max_resolution,
            fps=fps,
        )
        body = json.dumps(payload).encode("utf-8")

        status, resp_bytes, resp_headers = self._transport.request(
            method="POST",
            url=self._contract.PLAYBACK_ENDPOINT,
            headers=headers,
            body=body,
            timeout=12.0,
        )

        if status != 200:
            raise UpstreamHttpError(status, resp_bytes, resp_headers)

        try:
            pdata = json.loads(resp_bytes.decode("utf-8"))
        except Exception as e:
            raise ValueError(f"Error parseando JSON de respuesta de playback: {e}") from e

        stream = pdata.get("stream", {})
        sources = stream.get("sources", [])
        if not sources:
            raise RuntimeError("Respuesta de playback no contiene 'sources'")

        # En eventos en vivo, 'slide' contiene el flujo HLS deslizante con dvt2 token
        stream_src = sources[0]
        url = stream_src.get("slide", {}).get("url") or stream_src.get("complete", {}).get("url")
        if not url:
            raise RuntimeError("No se encontró URL de streaming válida en 'sources'")

        # Extraer derechos de reproducción (contexto obligatorio para la licencia)
        playback_rights = stream.get("playbackRights", {})
        rights_context = playback_rights.get("playbackRightsContext", "")
        if not rights_context or not isinstance(rights_context, str) or not rights_context.strip():
            raise RuntimeError("Respuesta de playback rechazada: falta 'playbackRightsContext' o está vacío")
        rights_context = rights_context.strip()

        # Determinar endpoint DRM
        pr_content_type = playback_rights.get("contentType", content_type)
        if pr_content_type == "linear" or content_type == "linear":
            drm_kind = DrmEndpointKind.LINEAR
        else:
            drm_kind = DrmEndpointKind.EVENT

        # Calcular expiración de la URL (analizar dvt2=exp=(\d+) en la URL firmada)
        url_expiration = now + 86400.0  # Fallback a 24 horas (comprobado en auditoría)
        m_exp = re.search(r"exp=(\d+)", url)
        if m_exp:
            try:
                url_expiration = float(m_exp.group(1))
            except ValueError:
                pass

        # Calcular expiración de derechos desde el JWT si es posible
        rights_expiration = url_expiration
        if rights_context:
            parts = rights_context.split(".")
            if len(parts) >= 2:
                try:
                    pad = -len(parts[1]) % 4
                    claims = json.loads(base64.b64decode(parts[1] + "=" * pad).decode("utf-8"))
                    if "exp" in claims:
                        rights_expiration = float(claims["exp"])
                except Exception:
                    pass

        context = PlaybackContext(
            manifest_url=url,
            rights_context=rights_context,
            drm_endpoint_kind=drm_kind,
            url_expiration=url_expiration,
            rights_expiration=rights_expiration,
            created_at=now,
        )
        return context
