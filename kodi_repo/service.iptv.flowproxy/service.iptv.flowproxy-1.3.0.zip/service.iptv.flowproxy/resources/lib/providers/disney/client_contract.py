"""
ClientContract para Disney+ BAMGrid: Define cabeceras, endpoints y payloads específicos
por familia de cliente (Web/Chrome) y por operación (Playback vs. Licencia).
"""
from __future__ import annotations

from typing import Any, Dict


class ChromeWebContract:
    NAME = "chrome_web"

    # Constantes identificadas en la captura de red real (Linux / Chrome)
    CLIENT_ID = "disney-svod-3d9324fc"
    SDK_VERSION = "35.6"
    SDK_PLATFORM = "javascript/linux/chrome"
    APP_VERSION = "15f4cd16_bap"
    DSS_EDGE_ACCEPT = "vnd.dss.edge+json; version=2"
    USER_AGENT = (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36"
    )
    ORIGIN = "https://www.disneyplus.com"
    REFERER = "https://www.disneyplus.com/"

    # Endpoints
    PLAYBACK_ENDPOINT = "https://disney.playback.edge.bamgrid.com/v7/playback/ctr-regular"
    WIDEVINE_EVENT_ENDPOINT = "https://disney.playback.edge.bamgrid.com/widevine/v1/obtain-license"
    WIDEVINE_LINEAR_ENDPOINT = "https://disney.playback.edge.bamgrid.com/widevine/v1/channel/obtain-license"
    GRAPHQL_DEVICE_ENDPOINT = "https://disney.api.edge.bamgrid.com/graph/v1/device/graphql"
    BROWSER_API_KEY = "Bearer ZGlzbmV5JmJyb3dzZXImMS4wLjA.Cu56AgSfBTDag5NiRA81oLHkDZfu5L3CKadnefEAY84"

    @classmethod
    def build_refresh_headers(cls) -> Dict[str, str]:
        """Cabeceras verificadas para la mutación GraphQL refreshToken en Chrome."""
        return {
            "User-Agent": cls.USER_AGENT,
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": cls.BROWSER_API_KEY,
            "x-bamsdk-client-id": cls.CLIENT_ID,
            "x-bamsdk-platform": cls.SDK_PLATFORM,
            "x-bamsdk-version": cls.SDK_VERSION,
            "x-application-version": cls.APP_VERSION,
            "Origin": cls.ORIGIN,
            "Referer": cls.REFERER,
        }

    @classmethod
    def build_playback_headers(cls, access_token: str) -> Dict[str, str]:
        """
        Construye las cabeceras para solicitud de Playback en Chrome.
        Contrato verificado: Authorization lleva prefijo 'Bearer '.
        Cada llamada genera un diccionario nuevo para evitar colisiones concurrentes.
        """
        token = access_token.strip()
        auth_value = token if token.startswith("Bearer ") else f"Bearer {token}"
        return {
            "User-Agent": cls.USER_AGENT,
            "Authorization": auth_value,
            "x-bamsdk-client-id": cls.CLIENT_ID,
            "x-bamsdk-version": cls.SDK_VERSION,
            "x-bamsdk-platform": cls.SDK_PLATFORM,
            "x-application-version": cls.APP_VERSION,
            "x-dss-edge-accept": cls.DSS_EDGE_ACCEPT,
            "x-dss-feature-filtering": "true",
            "Accept": "application/vnd.media-service+json",
            "Content-Type": "application/json",
            "Origin": cls.ORIGIN,
            "Referer": cls.REFERER,
        }

    @classmethod
    def build_license_headers(
        cls, access_token: str, rights_context: str, content_length: int
    ) -> Dict[str, str]:
        """
        Construye las cabeceras para solicitud de Licencia Widevine en Chrome.
        Contrato verificado:
          - Authorization se envía en RAW (SIN prefijo 'Bearer ').
          - x-playback-rights-authorization contiene el JWT de derechos devuelto por playback.
        """
        # Limpiar cualquier 'Bearer ' que pueda venir por accidente
        raw_token = access_token.replace("Bearer ", "").strip()
        headers = {
            "User-Agent": cls.USER_AGENT,
            "Authorization": raw_token,
            "Content-Type": "application/octet-stream",
            "Content-Length": str(content_length),
            "x-bamsdk-client-id": cls.CLIENT_ID,
            "x-bamsdk-version": cls.SDK_VERSION,
            "x-bamsdk-platform": cls.SDK_PLATFORM,
            "x-application-version": cls.APP_VERSION,
            "x-dss-edge-accept": cls.DSS_EDGE_ACCEPT,
            "Origin": cls.ORIGIN,
            "Referer": cls.REFERER,
            "Accept": "*/*",
        }
        if rights_context:
            headers["x-playback-rights-authorization"] = rights_context.strip()
        return headers

    @classmethod
    def build_playback_payload(
        cls,
        resource_id: str,
        content_type: str = "live",
        max_resolution: str = "1280x720",
        fps: int = 60,
    ) -> Dict[str, Any]:
        """
        Construye el payload JSON para /v7/playback/ctr-regular según el contrato Chrome.
        """
        attributes: Dict[str, Any] = {
            "resolution": {"max": [max_resolution]},
            "protocol": "HTTPS",
            "assetInsertionStrategies": {"point": "SGAI", "range": "SGAI"},
            "playbackInitiationContext": "ONLINE",
            "frameRates": [fps],
            "videoSegmentTypes": ["FMP4"],
            "encryption": ["ctr"],
            "codecs": {
                "video": ["h.264", "vp9"],
                "audio": [{"name": "aac", "muxed": False}],
            },
            "maxSlideDuration": "4_HOUR",
            "supportsPlaylistFiltering": True,
            "iframe": False,
        }

        if content_type == "live":
            attributes["minLiveSegmentTargetDuration"] = 3
            attributes["supportsVp9Hdr"] = True

        return {
            "playbackId": resource_id,
            "playback": {
                "attributes": attributes,
            },
        }
