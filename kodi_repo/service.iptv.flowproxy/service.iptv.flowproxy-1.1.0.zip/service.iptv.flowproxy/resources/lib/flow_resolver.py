"""
FlowSessionResolver: Obtención y caché local de tokens y URLs directas para nodos CDN de Flow.
"""

import logging
import re
import ssl
import time
import urllib.parse
import urllib.request
from typing import Dict, Optional, Tuple

logger = logging.getLogger("flowproxy_resolver")

USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36"


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class FlowSessionResolver:
    """Resuelve en caliente la URL con token de sesión de Flow desde la IP pública del dispositivo."""

    def __init__(self, cache_ttl_seconds: float = 3600.0):
        self.cache_ttl = cache_ttl_seconds
        self._channel_cache: Dict[str, Tuple[str, float]] = {}  # slug -> (target_url, expires_at)

        self.ssl_ctx = ssl.create_default_context()
        self.ssl_ctx.check_hostname = False
        self.ssl_ctx.verify_mode = ssl.CERT_NONE
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPSHandler(context=self.ssl_ctx),
            NoRedirect,
        )

    def resolve_stream(self, slug: str, rel_path: str) -> str:
        now = time.time()
        if slug in self._channel_cache:
            url, exp = self._channel_cache[slug]
            if now < exp:
                return url

        # Telecom Flow requiere consultar con el perfil SA_Live_dash_cenc
        seed_rel = re.sub(r"SA_Live_dash_enc(_wl)?", "SA_Live_dash_cenc", rel_path.lstrip("/"))
        seed_url = f"https://cdn.cvattv.com.ar/{seed_rel}"

        req = urllib.request.Request(
            seed_url,
            headers={"User-Agent": USER_AGENT},
        )
        try:
            self.opener.open(req, timeout=4.0)
        except urllib.error.HTTPError as err:
            if err.code == 302:
                loc = err.headers.get("Location")
                if loc:
                    self._channel_cache[slug] = (loc, now + self.cache_ttl)
                    return loc
            logger.warning(f"Seed {seed_url} devolvió HTTP {err.code}: {err.headers.get('Location')}")
        except Exception as exc:
            logger.warning(f"Error consultando seed {seed_url}: {exc}")

        # Fallback si el slug no pudo resolverse por seed directo pero existe una entrada previa
        if slug in self._channel_cache:
            return self._channel_cache[slug][0]

        raise RuntimeError(f"No se pudo resolver redirección 302 para canal {slug}")
