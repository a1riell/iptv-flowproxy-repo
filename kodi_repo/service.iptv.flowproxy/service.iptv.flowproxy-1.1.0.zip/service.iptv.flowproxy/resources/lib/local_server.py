"""
Servidor HTTP Local Zero-CPU para redirecciones de Flow en Kodi.
"""

from __future__ import annotations

import http.server
import json
import logging
import os
import re
import socketserver
import urllib.parse
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, Union

from .flow_resolver import FlowSessionResolver

logger = logging.getLogger("flowproxy_server")

MAPPINGS_FILE = Path(__file__).resolve().parent / "slug_mappings.json"
SLUG_MAPPINGS: Dict[str, str] = {}

if MAPPINGS_FILE.is_file():
    try:
        SLUG_MAPPINGS = json.loads(MAPPINGS_FILE.read_text(encoding="utf-8"))
    except Exception as e:
        logger.warning(f"No se pudo cargar slug_mappings.json: {e}")



def extract_seed_rel(entry: Any) -> Tuple[Optional[str], Optional[str]]:
    """Extrae y valida la ruta relativa del seed desde una entrada de mapping.

    Retorna (seed_rel, error_reason). Si es válida, error_reason es None.
    """
    if entry is None:
        return None, "slug_not_found"

    if isinstance(entry, dict):
        seed = entry.get("seed_rel")
    elif isinstance(entry, str):
        seed = entry
    else:
        return None, "invalid_type"

    if not isinstance(seed, str) or not seed.strip():
        return None, "empty_seed_rel"

    seed = seed.strip()
    if ".." in seed:
        return None, "path_traversal"
    if seed.startswith("/"):
        return None, "absolute_path"
    if "://" in seed:
        return None, "external_host"

    return seed, None


class FlowProxyHandler(http.server.BaseHTTPRequestHandler):
    resolver = FlowSessionResolver()

    def do_GET(self) -> None:
        path = urllib.parse.unquote(self.path)
        if "/kodi/live/" in path:
            raw_slug = path.split("/kodi/live/")[-1]
            slug = re.sub(r"\.(mpd|m3u8)$", "", raw_slug, flags=re.IGNORECASE).strip().lower()

            entry = SLUG_MAPPINGS.get(slug)
            target_rel, err = extract_seed_rel(entry)

            if err == "slug_not_found":
                self.send_error(404, f"Canal no encontrado: {slug}")
                return
            elif err:
                self.send_error(400, f"Ruta de seed inválida para canal {slug}: {err}")
                return

            try:
                target_url = self.resolver.resolve_stream(slug, target_rel)

                self.send_response(302)
                self.send_header("Location", target_url)
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "no-cache, no-store")
                self.end_headers()
            except Exception as e:
                self.send_error(503, f"Error resolviendo canal {slug}: {e}")
        elif path == "/status" or path == "/health":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"status": "ok", "service": "service.iptv.flowproxy"}')
        else:
            self.send_error(404, "Endpoint no reconocido")

    def log_message(self, format: str, *args) -> None:
        pass


class ThreadedHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True
