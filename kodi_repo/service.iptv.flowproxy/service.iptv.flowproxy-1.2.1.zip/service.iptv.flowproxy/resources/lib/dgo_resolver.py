"""
DgoSessionResolver: Resolución y caché de manifiestos DASH y proxy de licencias Widevine para DGO.
Diseñado para correr en service.iptv.flowproxy (Kodi 19+, 20+, 21+) en Python 3 puro.
"""

from __future__ import annotations

import base64
import json
import logging
import os
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger("flowproxy_dgo_resolver")

USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36"

def _load_dgo_channels_catalog() -> Dict[str, Dict[str, Any]]:
    """Carga el catálogo completo de canales DGO desde dgo_channels.json."""
    catalog: Dict[str, Dict[str, Any]] = {
        "espn-premium": {
            "channel_id": "CH0100000000182",
            "drm_id": "Live_1125",
            "name": "ESPN Premium Argentina",
        },
        "tnt-sports": {
            "channel_id": "CH0100000000040",
            "drm_id": "Live_1233",
            "name": "TNT Sports Argentina",
        },
        "espn": {
            "channel_id": "CH0100000000162",
            "drm_id": "Live_1104",
            "name": "ESPN Argentina",
        },
        "espn2": {
            "channel_id": "CH0100000000016",
            "drm_id": "Live_1099",
            "name": "ESPN 2 Argentina",
        },
        "espn3": {
            "channel_id": "CH0100000000163",
            "drm_id": "Live_1103",
            "name": "ESPN 3 Sur",
        },
        "fox-sports": {
            "channel_id": "CH0100000000177",
            "drm_id": "Live_1118",
            "name": "Fox Sports Argentina",
        },
        "fox-sports2": {
            "channel_id": "CH0100000000335",
            "drm_id": "Live_1281",
            "name": "Fox Sports 2 Argentina",
        },
        "fox-sports3": {
            "channel_id": "CH0100000000336",
            "drm_id": "Live_1280",
            "name": "Fox Sports 3 Argentina",
        },
        "tyc-sports": {
            "channel_id": "CH0100000000036",
            "drm_id": "Live_1240",
            "name": "TyC Sports",
        },
    }

    candidates = [
        Path(__file__).resolve().parent / "dgo_channels.json",
    ]
    try:
        import xbmc
        import xbmcaddon
        profile_dir = Path(xbmc.translatePath(xbmcaddon.Addon().getAddonInfo("profile")))
        candidates.append(profile_dir / "dgo_channels.json")
    except Exception:
        pass

    for candidate in candidates:
        if candidate.is_file():
            try:
                data = json.loads(candidate.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    for slug, info in data.items():
                        if isinstance(info, dict) and "channel_id" in info and "drm_id" in info:
                            item = dict(info)
                            if "name" not in item and "title" in item:
                                item["name"] = item["title"]
                            catalog[slug] = item
                    break
            except Exception as e:
                logger.warning("No se pudo cargar %s: %s", candidate, e)

    return catalog


# Mapeo canónico de canales DGO
DGO_CHANNELS: Dict[str, Dict[str, Any]] = _load_dgo_channels_catalog()

# Inverso drm_id -> slug
DRM_ID_TO_SLUG: Dict[str, str] = {
    info["drm_id"].lower(): slug for slug, info in DGO_CHANNELS.items() if "drm_id" in info
}


def _extract_jwt_exp(token: str) -> Optional[int]:
    """Extrae el claim 'exp' de un JWT sin validar la firma."""
    if not token or "." not in token:
        return None
    try:
        parts = token.split(".")
        if len(parts) < 2:
            return None
        payload_b64 = parts[1] + "=" * (-len(parts[1]) % 4)
        payload = json.loads(base64.urlsafe_b64decode(payload_b64))
        return int(payload.get("exp", 0))
    except Exception:
        return None


def rewrite_dgo_mpd(raw_mpd: bytes, remote_url: str) -> bytes:
    """Reescribe un manifiesto DASH de DGO para inyectar BaseURL y parámetros de query en los segmentos.

    Akamai requiere que cada petición a los segmentos (.mp4) incluya la firma hdnts=...
    presente en la URL del manifiesto. Los reproductores estándar (como Kodi) resuelven
    los segmentos relativos descartando los query parameters, provocando HTTP 403 Forbidden.
    """
    if isinstance(raw_mpd, str):
        raw_mpd = raw_mpd.encode("utf-8")

    parsed = urllib.parse.urlsplit(remote_url)
    query = parsed.query.strip()
    if not query:
        return raw_mpd

    base_dir = parsed.path.rsplit("/", 1)[0] + "/"
    fallback_base_url = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, base_dir, "", ""))

    try:
        ET.register_namespace("", "urn:mpeg:dash:schema:mpd:2011")
        root = ET.fromstring(raw_mpd)

        # 1. BaseURL check/insertion
        ns = {"mpd": "urn:mpeg:dash:schema:mpd:2011"}
        base_elem = root.find("mpd:BaseURL", ns)
        if base_elem is None:
            base_elem = root.find("BaseURL")
        if base_elem is None:
            base_elem = ET.Element("{urn:mpeg:dash:schema:mpd:2011}BaseURL")
            base_elem.text = fallback_base_url
            root.insert(0, base_elem)
        elif base_elem.text and not base_elem.text.endswith("/"):
            base_elem.text += "/"

        # 2. Location removal para asegurar que Kodi refresque el manifiesto a través del proxy local
        for loc in list(root.findall("mpd:Location", ns)) + list(root.findall("Location")):
            root.remove(loc)

        # 3. Reescribir atributos de SegmentTemplate y SegmentURL
        for elem in root.iter():
            tag = elem.tag.rsplit("}", 1)[-1]
            if tag == "SegmentTemplate":
                for attr in ("initialization", "media"):
                    val = elem.attrib.get(attr)
                    if val and "?" not in val:
                        elem.attrib[attr] = f"{val}?{query}"
            elif tag == "SegmentURL":
                for attr in ("media", "initialization"):
                    val = elem.attrib.get(attr)
                    if val and "?" not in val:
                        elem.attrib[attr] = f"{val}?{query}"

        return ET.tostring(root, encoding="utf-8", xml_declaration=True)
    except Exception as e:
        logger.error("Error reescribiendo MPD de DGO: %s", e)
        return raw_mpd


class DgoSessionResolver:
    """Resuelve URLs DASH firmadas de DGO y gestiona el proxy local de licencias Widevine CPIX."""

    AUTHORIZER_ENDPOINT = "https://api.directvgo.com/entitlement/v3/playback/token/authorizer"
    CPIX_LICENSE_ENDPOINT = "https://cpix.tbxdrm.com/v1/license/dtvgo/widevine"
    SAFETY_MARGIN_SECONDS = 120.0
    DEFAULT_DRM_TTL = 3000.0
    DEFAULT_STREAM_TTL = 1800.0

    def __init__(self, credentials_path: Optional[str] = None):
        self._credentials_path = credentials_path
        # slug -> (manifest_url, monotonic_deadline)
        self._stream_cache: Dict[str, Tuple[str, float]] = {}
        # slug -> (rewritten_mpd_bytes, monotonic_deadline)
        self._manifest_cache: Dict[str, Tuple[bytes, float]] = {}
        # drm_id (lower) -> (bearer_token, monotonic_deadline)
        self._drm_token_cache: Dict[str, Tuple[str, float]] = {}

        self.ssl_ctx = ssl.create_default_context()
        self.ssl_ctx.check_hostname = False
        self.ssl_ctx.verify_mode = ssl.CERT_NONE

    def _find_credentials_file(self) -> Optional[Path]:
        """Localiza el archivo de credenciales en orden de prioridad."""
        if self._credentials_path:
            p = Path(self._credentials_path)
            if p.is_file():
                return p

        # 1. En Kodi userdata si está disponible
        try:
            import xbmc
            import xbmcaddon
            profile_dir = Path(xbmc.translatePath(xbmcaddon.Addon().getAddonInfo("profile")))
            kodi_creds = profile_dir / "dgo_credentials.json"
            if kodi_creds.is_file():
                return kodi_creds
        except Exception:
            pass

        # 2. En ~/.flow_cache/dgo_credentials.json (Linux / sistema)
        flow_cache_creds = Path.home() / ".flow_cache" / "dgo_credentials.json"
        if flow_cache_creds.is_file():
            return flow_cache_creds

        # 3. En la propia carpeta del addon (desarrollo local)
        local_creds = Path(__file__).resolve().parent / "dgo_credentials.local.json"
        if local_creds.is_file():
            return local_creds

        return None

    def load_credentials(self) -> Dict[str, str]:
        """Carga las credenciales activas de DGO."""
        creds_file = self._find_credentials_file()
        if not creds_file:
            raise FileNotFoundError(
                "No se encontró el archivo de credenciales de DGO (dgo_credentials.json)"
            )
        try:
            return json.loads(creds_file.read_text(encoding="utf-8"))
        except Exception as e:
            raise RuntimeError(f"Error leyendo credenciales de DGO desde {creds_file}: {e}")

    def _build_request_headers(self, creds: Dict[str, str]) -> Dict[str, str]:
        """Construye las cabeceras exactas para la API de DGO."""
        id_token = creds.get("id_token", "").strip()
        profile_token = creds.get("profile_token", "").strip()
        if not id_token:
            raise ValueError("Falta 'id_token' en las credenciales de DGO")

        headers = {
            "authorization": f"Bearer {id_token}",
            "x-environment": creds.get("environment", "prd"),
            "x-app": creds.get("app", "dgo"),
            "x-client-id": creds.get("client_id", "web"),
            "x-client-version": creds.get("client_version", "3.69.0"),
            "content-type": "application/json",
            "origin": "https://www.directvgo.com",
            "referer": "https://www.directvgo.com/",
            "user-agent": USER_AGENT,
        }
        if profile_token:
            headers["x-profile-token"] = profile_token
        return headers

    def get_stream_url(self, slug: str) -> str:
        """Obtiene la URL firmada de MediaTailor/Akamai (.mpd) para el canal solicitado."""
        norm_slug = re.sub(r"\.(mpd|m3u8)$", "", slug, flags=re.IGNORECASE).strip().lower()
        ch_info = DGO_CHANNELS.get(norm_slug)
        if not ch_info:
            raise ValueError(f"Canal DGO no mapeado: '{norm_slug}'")

        mono_now = time.monotonic()
        cached = self._stream_cache.get(norm_slug)
        if cached:
            url, deadline = cached
            if mono_now < deadline:
                return url
            self._stream_cache.pop(norm_slug, None)

        creds = self.load_credentials()
        headers = self._build_request_headers(creds)
        payload = json.dumps(
            {
                "delay": 0,
                "mobileNetwork": False,
                "isLive": True,
                "contentId": ch_info["channel_id"],
            }
        ).encode("utf-8")

        req = urllib.request.Request(
            self.AUTHORIZER_ENDPOINT,
            data=payload,
            headers=headers,
            method="POST",
        )

        try:
            with urllib.request.urlopen(req, timeout=8.0, context=self.ssl_ctx) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            err_body = e.read().decode("utf-8", errors="ignore")
            logger.error("DGO Authorizer HTTP %s: %s", e.code, err_body)
            raise RuntimeError(f"Error DGO Authorizer ({e.code}) para {norm_slug}") from e
        except Exception as e:
            logger.error("Error conectando con DGO Authorizer: %s", e)
            raise RuntimeError(f"Fallo de conexión con DGO Authorizer para {norm_slug}: {e}") from e

        manifest_data = data.get("manifest", {}).get("dash", {})
        dash_url = manifest_data.get("primary")
        if not dash_url:
            raise RuntimeError(f"DGO no devolvió URL DASH para el canal {norm_slug}")

        drm_id = data.get("drmId") or ch_info["drm_id"]
        auth_token = data.get("authorization")

        # Guardar en caché el token de DRM Widevine
        if auth_token and drm_id:
            exp = _extract_jwt_exp(auth_token)
            if exp:
                remaining = exp - time.time() - self.SAFETY_MARGIN_SECONDS
                ttl = max(60.0, remaining)
            else:
                ttl = self.DEFAULT_DRM_TTL
            self._drm_token_cache[drm_id.lower()] = (auth_token, time.monotonic() + ttl)

        # Guardar en caché el manifest DASH
        self._stream_cache[norm_slug] = (dash_url, time.monotonic() + self.DEFAULT_STREAM_TTL)
        return dash_url

    def get_manifest(self, slug: str) -> bytes:
        """Descarga el MPD firmado desde Akamai y lo reescribe con BaseURL y query params en segmentos."""
        norm_slug = re.sub(r"\.(mpd|m3u8)$", "", slug, flags=re.IGNORECASE).strip().lower()
        stream_url = self.get_stream_url(norm_slug)

        mono_now = time.monotonic()
        cached = self._manifest_cache.get(norm_slug)
        if cached:
            body, deadline = cached
            if mono_now < deadline:
                return body

        headers = {
            "User-Agent": USER_AGENT,
            "Origin": "https://www.directvgo.com",
            "Referer": "https://www.directvgo.com/",
        }
        req = urllib.request.Request(stream_url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=5.0, context=self.ssl_ctx) as resp:
                raw_mpd = resp.read()
        except urllib.error.HTTPError as e:
            if e.code in (401, 403):
                logger.warning("Akamai retorno HTTP %s para %s; refrescando token DGO...", e.code, norm_slug)
                self._stream_cache.pop(norm_slug, None)
                stream_url = self.get_stream_url(norm_slug)
                req = urllib.request.Request(stream_url, headers=headers)
                with urllib.request.urlopen(req, timeout=5.0, context=self.ssl_ctx) as resp:
                    raw_mpd = resp.read()
            else:
                raise

        rewritten = rewrite_dgo_mpd(raw_mpd, stream_url)
        self._manifest_cache[norm_slug] = (rewritten, mono_now + 3.0)
        return rewritten

    def get_drm_token(self, content_id: str) -> str:
        """Obtiene el Bearer token válido para el contentId / drmId solicitado."""
        norm_id = content_id.strip().lower()
        mono_now = time.monotonic()
        cached = self._drm_token_cache.get(norm_id)
        if cached:
            token, deadline = cached
            if mono_now < deadline:
                return token
            self._drm_token_cache.pop(norm_id, None)

        # Si no está en caché, refrescar invocando authorizer para el canal asociado
        slug = DRM_ID_TO_SLUG.get(norm_id)
        if slug:
            self.get_stream_url(slug)
            cached = self._drm_token_cache.get(norm_id)
            if cached and mono_now < cached[1]:
                return cached[0]

        raise RuntimeError(f"No hay token de DRM disponible ni recuperable para {content_id}")

    def proxy_license(
        self, content_id: str, challenge_data: bytes
    ) -> Tuple[int, bytes, Dict[str, str]]:
        """Envía el challenge binario de Widevine al CPIX de DGO inyectando el token Bearer."""
        bearer_token = self.get_drm_token(content_id)
        target_url = f"{self.CPIX_LICENSE_ENDPOINT}?contentId={content_id}"

        headers = {
            "Authorization": f"Bearer {bearer_token}",
            "Content-Type": "application/octet-stream",
            "Origin": "https://www.directvgo.com",
            "Referer": "https://www.directvgo.com/",
            "User-Agent": USER_AGENT,
        }

        req = urllib.request.Request(
            target_url,
            data=challenge_data,
            headers=headers,
            method="POST",
        )

        try:
            with urllib.request.urlopen(req, timeout=6.0, context=self.ssl_ctx) as resp:
                resp_bytes = resp.read()
                return resp.status, resp_bytes, {"Content-Type": "application/octet-stream"}
        except urllib.error.HTTPError as e:
            err_body = e.read()
            logger.error("CPIX DRM HTTP %s para contentId=%s: %s", e.code, content_id, err_body[:200])
            return e.code, err_body, {"Content-Type": "application/octet-stream"}
        except Exception as e:
            logger.error("Error conectando con CPIX DRM para %s: %s", content_id, e)
            raise RuntimeError(f"Fallo de proxy CPIX DRM para {content_id}: {e}") from e
