"""
Entrypoint de servicio para Kodi: service.iptv.flowproxy
"""

import json
import os
from pathlib import Path
import sys
import threading
import xml.etree.ElementTree as ET

try:
    import xbmc
    import xbmcaddon
    import xbmcvfs
    IN_KODI = True
except ImportError:
    IN_KODI = False

from resources.lib.local_server import FlowProxyHandler, ThreadedHTTPServer, close_resolvers

DEFAULT_PORT = 18080


def get_configured_port() -> int:
    if IN_KODI:
        try:
            addon = xbmcaddon.Addon()
            val = addon.getSetting("proxy_port")
            if val:
                return int(val)
        except Exception:
            pass
    return DEFAULT_PORT


_current_httpd = None


def update_iptv_simple_refresh_settings(
    profile_dir: Path, interval_minutes: int = 10
) -> int:
    """Configura todas las instancias IPTV Simple para recargar la M3U periódicamente.

    Retorna cuántos archivos cambiaron. El reemplazo es atómico para no dejar
    una configuración XML parcial si Android termina Kodi durante la escritura.
    """
    if interval_minutes < 1 or interval_minutes > 120:
        raise ValueError("interval_minutes debe estar entre 1 y 120")

    settings_dir = profile_dir / "addon_data" / "pvr.iptvsimple"
    if not settings_dir.is_dir():
        return 0

    changed_files = 0
    for settings_path in sorted(settings_dir.glob("instance-settings-*.xml")):
        try:
            tree = ET.parse(settings_path)
            root = tree.getroot()
            settings = {
                node.get("id"): node
                for node in root.findall(".//setting")
                if node.get("id")
            }
            refresh_mode = settings.get("m3uRefreshMode")
            refresh_interval = settings.get("m3uRefreshIntervalMins")
            if refresh_mode is None or refresh_interval is None:
                continue

            changed = False
            if (refresh_mode.text or "").strip() != "1":
                refresh_mode.text = "1"
                changed = True
            if refresh_mode.attrib.pop("default", None) is not None:
                changed = True
            desired_interval = str(interval_minutes)
            if (refresh_interval.text or "").strip() != desired_interval:
                refresh_interval.text = desired_interval
                changed = True
            if refresh_interval.attrib.pop("default", None) is not None:
                changed = True
            if not changed:
                continue

            temporary = settings_path.with_name(
                f".{settings_path.name}.flowproxy-{os.getpid()}.tmp"
            )
            try:
                tree.write(temporary, encoding="utf-8", xml_declaration=True)
                os.replace(temporary, settings_path)
            finally:
                try:
                    if temporary.exists():
                        temporary.unlink()
                except OSError:
                    pass
            changed_files += 1
        except (OSError, ET.ParseError):
            continue
    return changed_files


def _set_kodi_addon_enabled(addon_id: str, enabled: bool) -> bool:
    if not IN_KODI:
        return False
    request = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "Addons.SetAddonEnabled",
        "params": {"addonid": addon_id, "enabled": enabled},
    }
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        return response.get("result") == "OK"
    except Exception:
        return False


def configure_kodi_playlist_refresh() -> None:
    """Aplica el intervalo dinámico y recarga IPTV Simple una sola vez si cambió."""
    if not IN_KODI:
        return
    try:
        profile_dir = Path(xbmcvfs.translatePath("special://profile"))
        changed = update_iptv_simple_refresh_settings(profile_dir, interval_minutes=10)
        if not changed:
            return
        # El cliente binario conserva los ajustes en memoria. Un reinicio breve
        # fuerza la primera descarga y deja activo su temporizador de 10 minutos.
        disabled = _set_kodi_addon_enabled("pvr.iptvsimple", False)
        xbmc.sleep(750)
        enabled = _set_kodi_addon_enabled("pvr.iptvsimple", True)
        xbmc.log(
            "[IPTV FlowProxy] IPTV Simple configurado para refrescar cada 10 min "
            f"({changed} instancia(s), reload={disabled and enabled})",
            level=xbmc.LOGINFO,
        )
    except Exception as exc:
        xbmc.log(
            f"[IPTV FlowProxy] No se pudo configurar el refresco de IPTV Simple: {exc}",
            level=xbmc.LOGWARNING,
        )


def shutdown_server() -> None:
    global _current_httpd
    if _current_httpd:
        try:
            _current_httpd.shutdown()
            _current_httpd.server_close()
        finally:
            _current_httpd = None
    close_resolvers()


def run_server(port: int) -> None:
    global _current_httpd
    server_address = ("127.0.0.1", port)
    _current_httpd = ThreadedHTTPServer(server_address, FlowProxyHandler)
    msg = f"[IPTV FlowProxy] Servidor iniciado en http://127.0.0.1:{port}"
    if IN_KODI:
        xbmc.log(msg, level=xbmc.LOGINFO)
    else:
        print(msg)
    _current_httpd.serve_forever()


if __name__ == "__main__":
    port = get_configured_port()
    server_thread = threading.Thread(target=run_server, args=(port,), daemon=True)
    server_thread.start()

    # Pre-cargar o auto-descargar credenciales DGO en segundo plano
    def _warmup_dgo():
        try:
            from resources.lib.local_server import _get_dgo_resolver
            resolver = _get_dgo_resolver()
            resolver.warmup()
        except Exception:
            pass

    threading.Thread(target=_warmup_dgo, daemon=True).start()

    # Pre-cargar sesión oficial Flow en segundo plano si está configurado
    def _warmup_flow():
        try:
            from resources.lib.local_server import _get_flow_auth
            auth = _get_flow_auth()
            if auth.is_configured:
                auth.get_session()
        except Exception:
            pass

    threading.Thread(target=_warmup_flow, daemon=True).start()

    # Pre-cargar sesión y bindings Disney en segundo plano si está configurado
    def _warmup_disney():
        try:
            from resources.lib.local_server import (
                _find_disney_bindings_file,
                _get_disney_registry,
                _get_disney_session,
                sync_disney_bindings_from_remote,
            )
            sync_disney_bindings_from_remote(force=True)
            session = _get_disney_session()
            if not session.is_authenticated():
                try:
                    session.get_access_token_snapshot()
                except Exception:
                    pass
            if session.is_authenticated():
                registry = _get_disney_registry()
                bfile = _find_disney_bindings_file()
                if bfile:
                    registry.load_from_file(bfile)
        except Exception:
            pass

    threading.Thread(target=_warmup_disney, daemon=True).start()

    # Asegurar que los eventos efímeros publicados en el Gist aparezcan sin
    # intervención del usuario. Sólo reinicia IPTV Simple si había que cambiar
    # su configuración; en arranques posteriores no produce interrupciones.
    if IN_KODI:
        threading.Thread(target=configure_kodi_playlist_refresh, daemon=True).start()

    if IN_KODI:
        monitor = xbmc.Monitor()
        maintenance_ticks = 0
        while not monitor.abortRequested():
            if monitor.waitForAbort(2):
                break
            maintenance_ticks += 1
            if maintenance_ticks >= 15:
                maintenance_ticks = 0
                try:
                    from resources.lib.local_server import _get_dgo_resolver
                    _get_dgo_resolver().maintenance()
                except Exception as exc:
                    xbmc.log(
                        f"[IPTV FlowProxy] Mantenimiento DGO omitido: {exc}",
                        level=xbmc.LOGWARNING,
                    )
                try:
                    from resources.lib.local_server import (
                        _find_disney_bindings_file,
                        _get_disney_registry,
                        sync_disney_bindings_from_remote,
                    )
                    sync_disney_bindings_from_remote()
                    bfile = _find_disney_bindings_file()
                    if bfile:
                        _get_disney_registry().load_from_file(bfile)
                except Exception as exc:
                    xbmc.log(
                        f"[IPTV FlowProxy] Sincronización periódica Disney omitida: {exc}",
                        level=xbmc.LOGDEBUG,
                    )
        try:
            shutdown_server()
        except Exception as exc:
            xbmc.log(f"[IPTV FlowProxy] Error durante cierre: {exc}", level=xbmc.LOGERROR)
        xbmc.log("[IPTV FlowProxy] Servicio detenido limpiamente", level=xbmc.LOGINFO)
    else:
        print("[IPTV FlowProxy] Ejecutando en modo standalone (presione Ctrl+C para salir)...")
        try:
            import time
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            shutdown_server()
            print("[IPTV FlowProxy] Detenido.")
            sys.exit(0)
