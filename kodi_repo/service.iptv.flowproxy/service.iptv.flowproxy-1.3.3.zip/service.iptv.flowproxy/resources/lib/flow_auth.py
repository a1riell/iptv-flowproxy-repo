"""
FlowAuthManager: Manejador autónomo de autenticación oficial de Flow,
sesión Minerva M11, conexión WebSocket de notificaciones y proxy de licencias
DRM Widevine para Kodi InputStream Adaptive.

Desarrollado para arquitectura Zero-CPU / Standard Library en Android TV, Linux y Windows.
"""

from __future__ import annotations

import base64
import hashlib
import http.client
import json
import logging
import os
import re
import socket
import ssl
import threading
import time
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, Union

BOOTSTRAP_SECRET_KEY = "IPTV_FLOWPROXY_SECRET_2026"
DEFAULT_FLOW_GIST_BOOTSTRAP_URL = (
    "https://gist.githubusercontent.com/a1riell/9c1db121510fc81709f28c132afb9c81/raw/flow_credentials.dat"
)


def _deobfuscate_credentials(obfuscated_b64: str, secret_key: str = BOOTSTRAP_SECRET_KEY) -> bytes:
    key_bytes = hashlib.sha256(secret_key.encode("utf-8")).digest()
    data = base64.b64decode(obfuscated_b64.strip())
    out = bytearray(len(data))
    for i in range(len(data)):
        out[i] = data[i] ^ key_bytes[i % len(key_bytes)]
    return bytes(out)

logger = logging.getLogger("flowproxy_auth")

FLOW_OFFICIAL_CHANNELS_FILE = Path(__file__).resolve().parent / "flow_channels.json"
USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36"
SESSION_REFRESH_MARGIN_SECONDS = 300.0  # 5 minutos antes de expirar
PLAYBACK_CACHE_TTL_SECONDS = 900.0  # 15 minutos
INGRESS_HOST = "ingress011.bo.flow.com.ar"
INGRESS_PORT = 443
M11_CONNECT_PATH = "/ingress011/8097/notifications/v1/connect"
M11_WIDEVINE_PATH = "/ingress011/8097/notifications/v1/prm/m11_drm_proxy/Widevine"


def _create_insecure_ssl_context() -> ssl.SSLContext:
    """Crea contexto SSL sin verificación estricta de host/CA para Android/TV Box."""
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


def _extract_jwt_exp(token: str) -> Optional[int]:
    """Extrae el claim exp de un JWT sin verificar firma."""
    if not token or not isinstance(token, str):
        return None
    parts = token.split(".")
    if len(parts) < 2:
        return None
    try:
        payload_b64 = parts[1] + "=" * (-len(parts[1]) % 4)
        payload = json.loads(base64.urlsafe_b64decode(payload_b64))
        return int(payload.get("exp", 0))
    except Exception:
        return None


def find_flow_credentials_path() -> Optional[Path]:
    """Descubre la ruta de credenciales oficiales de Flow con múltiples fallbacks."""
    # 1. Variable de entorno explícita
    env_path = os.environ.get("FLOW_CREDENTIALS_PATH")
    if env_path and Path(env_path).is_file():
        return Path(env_path)

    # 2. Addon profile directory de Kodi (si se ejecuta dentro de Kodi)
    try:
        import xbmcaddon
        import xbmcvfs
        addon = xbmcaddon.Addon("service.iptv.flowproxy")
        profile_dir = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        p = Path(profile_dir) / "flow_credentials.json"
        if p.is_file():
            return p
    except Exception:
        pass

    # 3. Cache local en home del usuario (~/.flow_cache/flow_credentials.json)
    cache_path = Path.home() / ".flow_cache" / "flow_credentials.json"
    if cache_path.is_file():
        return cache_path

    # 4. Carpeta Download en Android (útil para TV Box y sideloading)
    android_paths = [
        Path("/storage/emulated/0/Download/flow_credentials.json"),
        Path("/sdcard/Download/flow_credentials.json"),
    ]
    for p in android_paths:
        if p.is_file():
            return p

    # 5. Raíz del home o directorio de usuario
    home_file = Path.home() / "flow_credentials.json"
    if home_file.is_file():
        return home_file

    # 6. Fallback a /home/fer/flow_credentials.json
    fer_file = Path("/home/fer/flow_credentials.json")
    if fer_file.is_file():
        return fer_file

    return None


class FlowAuthManager:
    """Gestiona sesión M11, WebSocket de notificaciones y proxy de licencias Widevine para Flow."""

    def __init__(self, credentials_path: Optional[Union[str, Path]] = None):
        self._lock = threading.Lock()
        self._ws_lock = threading.Lock()
        self.ssl_ctx = _create_insecure_ssl_context()

        # Cargar mapeos de canales
        self._slug_to_id: Dict[str, str] = {}
        self._id_to_slug: Dict[str, str] = {}
        self._load_channel_catalog()

        # Credenciales
        self.credentials_path = Path(credentials_path) if credentials_path else find_flow_credentials_path()
        self._last_bootstrap_attempt: float = 0.0
        self.creds: Dict[str, Any] = {}
        self.is_configured = False
        self._load_credentials()

        # Estado de sesión M11
        self._session_jwt: Optional[str] = None
        self._region_token: Optional[str] = None
        self._session_exp: int = 0

        # Caché de tokens de reproducción: channel_id -> (playback_token, deadline_mono)
        self._playback_cache: Dict[str, Tuple[str, float]] = {}

        # Conexión WebSocket persistente para notificaciones Minerva
        self._ws_sock: Optional[ssl.SSLSocket] = None
        self._ws_active_session: Optional[str] = None

    def _load_channel_catalog(self) -> None:
        if FLOW_OFFICIAL_CHANNELS_FILE.is_file():
            try:
                data = json.loads(FLOW_OFFICIAL_CHANNELS_FILE.read_text(encoding="utf-8"))
                for slug, info in data.items():
                    cid = info.get("channel_id")
                    if cid:
                        self._slug_to_id[slug] = cid
                        self._id_to_slug[cid] = slug
                logger.info("Catálogo Flow cargado con %d canales oficiales", len(self._slug_to_id))
            except Exception as e:
                logger.warning("No se pudo cargar flow_channels.json: %s", e)

    def _bootstrap_remote_credentials_unlocked(self) -> Optional[Path]:
        """Descarga de forma segura las credenciales base ofuscadas desde el Secret Gist en el primer inicio."""
        now = time.monotonic()
        if (now - self._last_bootstrap_attempt) < 30.0:
            return None
        self._last_bootstrap_attempt = now

        try:
            logger.info("Intentando bootstrap seguro de Flow desde Secret Gist...")
            req = urllib.request.Request(
                DEFAULT_FLOW_GIST_BOOTSTRAP_URL,
                headers={"User-Agent": USER_AGENT},
            )
            with urllib.request.urlopen(req, timeout=12.0, context=self.ssl_ctx) as resp:
                data = resp.read().decode("utf-8").strip()

            raw_bytes = _deobfuscate_credentials(data)
            creds = json.loads(raw_bytes.decode("utf-8"))
            required = ("userDeviceToken", "profile", "deviceInfo", "deviceId", "regionId")
            if not isinstance(creds, dict) or not all(k in creds for k in required):
                logger.error("Payload remoto de credenciales Flow inválido.")
                return None

            target_file: Optional[Path] = None
            profile_dir = _get_addon_profile_dir()
            if profile_dir:
                try:
                    profile_dir.mkdir(parents=True, exist_ok=True)
                    target_file = profile_dir / "flow_credentials.json"
                except Exception as e:
                    logger.warning("No se pudo crear profile_dir %s: %s", profile_dir, e)

            if not target_file:
                for candidate_dir in [
                    Path.home() / ".flow_cache",
                    Path("/storage/emulated/0/Download"),
                    Path("/sdcard/Download"),
                ]:
                    try:
                        if candidate_dir.is_dir() or candidate_dir.parent.is_dir():
                            candidate_dir.mkdir(parents=True, exist_ok=True)
                            target_file = candidate_dir / "flow_credentials.json"
                            break
                    except Exception:
                        continue

            if target_file:
                tmp_file = target_file.with_suffix(".tmp")
                tmp_file.write_text(json.dumps(creds, indent=2), encoding="utf-8")
                try:
                    os.chmod(tmp_file, 0o600)
                except Exception:
                    pass
                tmp_file.replace(target_file)
                try:
                    os.chmod(target_file, 0o600)
                except Exception:
                    pass
                logger.info("Credenciales Flow descargadas exitosamente y guardadas en %s", target_file)
                return target_file
        except Exception as e:
            logger.info("Bootstrap remoto de credenciales Flow no disponible: %s", e)
        return None

    def _load_credentials(self) -> bool:
        if not self.credentials_path or not self.credentials_path.is_file():
            bootstrapped = self._bootstrap_remote_credentials_unlocked()
            if bootstrapped:
                self.credentials_path = bootstrapped
            else:
                logger.info("No se encontró archivo flow_credentials.json configurado.")
                self.is_configured = False
                return False

        try:
            content = self.credentials_path.read_text(encoding="utf-8")
            data = json.loads(content)
            required = ("userDeviceToken", "profile", "deviceInfo", "deviceId", "regionId")
            if all(k in data for k in required):
                self.creds = data
                self.is_configured = True
                logger.info("Credenciales Flow cargadas exitosamente desde %s", self.credentials_path)
                return True
            else:
                logger.warning("Archivo de credenciales Flow incompleto. Faltan campos requeridos.")
        except Exception as e:
            logger.warning("Error leyendo credenciales Flow: %s", e)

        self.is_configured = False
        return False

    def get_channel_id(self, slug_or_id: str) -> str:
        """Resuelve un slug de canal al ID oficial de Minerva (o devuelve el ID si ya lo es)."""
        clean = slug_or_id.strip()
        clean = re.sub(r"^/flow/license/", "", clean)
        clean = re.sub(r"\.(mpd|m3u8)$", "", clean, flags=re.IGNORECASE).strip().lower()

        # Si coincide con un slug conocido
        if clean in self._slug_to_id:
            return self._slug_to_id[clean]

        # Si ya es un channel_id conocido
        if slug_or_id.strip() in self._id_to_slug:
            return slug_or_id.strip()

        # Si no se encontró en catálogo, retornar limpio
        return clean

    def get_session(self, force_refresh: bool = False) -> Tuple[str, str]:
        """Obtiene un token de sesión M11 (JWT) válido y el region token."""
        if not self.is_configured:
            if not self._load_credentials():
                raise RuntimeError("Credenciales oficiales de Flow no configuradas")

        now = time.time()
        with self._lock:
            if not self._session_exp and self._session_jwt:
                self._session_exp = _extract_jwt_exp(self._session_jwt) or int(now + 86400)

            if not force_refresh and self._session_jwt and (self._session_exp - now > SESSION_REFRESH_MARGIN_SECONDS):
                return self._session_jwt, self._region_token or ""

            # Realizar POST a /users/node/0/api/v1/session
            s_url = "https://cdn.bo.flow.com.ar/users/node/0/api/v1/session"
            user_id = self.creds.get("user", "")
            dev_id = self.creds.get("deviceId", "")
            prof_id = self.creds.get("profile", "")

            body = json.dumps({
                "userDeviceToken": self.creds["userDeviceToken"],
                "profile": prof_id,
                "deviceInfo": self.creds["deviceInfo"],
            }).encode("utf-8")

            headers = {
                "Content-Type": "application/json",
                "User-Agent": USER_AGENT,
                "Origin": "https://portal.app.flow.com.ar",
                "Referer": "https://portal.app.flow.com.ar/",
                "x-request-id": f"Flow|WEB|4.40.3|{user_id}|{dev_id}|{int(time.time() * 1000)}",
            }

            req = urllib.request.Request(s_url, data=body, headers=headers)
            try:
                with urllib.request.urlopen(req, timeout=12.0, context=self.ssl_ctx) as resp:
                    resp_data = json.loads(resp.read().decode("utf-8"))
            except Exception as e:
                logger.error("Error renovando sesión Flow M11: %s", e)
                raise RuntimeError(f"Fallo renovación sesión Flow: {e}") from e

            tokens = resp_data.get("tokens", {})
            new_jwt = tokens.get("session")
            new_region = tokens.get("region")

            if not new_jwt:
                raise RuntimeError("Respuesta de sesión Flow no contiene token JWT 'session'")

            self._session_jwt = new_jwt
            self._region_token = new_region
            self._session_exp = _extract_jwt_exp(new_jwt) or int(now + 86400)
            logger.info("Sesión Flow M11 renovada exitosamente. Expira en %d segundos.", int(self._session_exp - now))
            return self._session_jwt, self._region_token or ""

    def ensure_notification_ws(self, session_jwt: str) -> None:
        """Garantiza que la conexión WebSocket de notificaciones Minerva permanezca activa."""
        with self._ws_lock:
            if self._ws_sock and self._ws_active_session == session_jwt:
                # Comprobar si el socket sigue vivo
                try:
                    self._ws_sock.settimeout(0.001)
                    peek = self._ws_sock.recv(16, socket.MSG_PEEK)
                    self._ws_sock.settimeout(10.0)
                    if len(peek) == 0:
                        raise ConnectionResetError("Socket cerrado por el servidor remoto")
                    return
                except (socket.timeout, ssl.SSLWantReadError):
                    # No hay datos pendientes de lectura pero la conexión está viva
                    self._ws_sock.settimeout(10.0)
                    return
                except Exception:
                    self._close_ws_socket()

            # Conectar WebSocket a ingress011
            self._close_ws_socket()
            try:
                raw_sock = socket.create_connection((INGRESS_HOST, INGRESS_PORT), timeout=10.0)
                ssock = self.ssl_ctx.wrap_socket(raw_sock, server_hostname=INGRESS_HOST)

                ts = int(time.time() * 1000)
                ws_key = base64.b64encode(os.urandom(16)).decode("utf-8")
                cid = base64.b64encode(os.urandom(6)).decode("utf-8").rstrip("=")

                req_lines = [
                    f"GET {M11_CONNECT_PATH}?seq=1&ts={ts}&cid={cid} HTTP/1.1",
                    f"Host: {INGRESS_HOST}",
                    "Upgrade: websocket",
                    "Connection: Upgrade",
                    f"Sec-WebSocket-Key: {ws_key}",
                    "Sec-WebSocket-Version: 13",
                    f"Sec-WebSocket-Protocol: {session_jwt}, NS.minervanetworks.com-1.0",
                    "Origin: https://portal.app.flow.com.ar",
                    f"User-Agent: {USER_AGENT}",
                    "\r\n",
                ]
                ssock.sendall("\r\n".join(req_lines).encode("utf-8"))
                resp_hdr = ssock.recv(4096).decode("utf-8", errors="ignore")

                if "101" not in resp_hdr:
                    ssock.close()
                    raise RuntimeError(f"Handshake WebSocket rechazado: {resp_hdr.splitlines()[:1]}")

                self._ws_sock = ssock
                self._ws_active_session = session_jwt
                logger.info("WebSocket de notificaciones Minerva conectado con éxito a %s", INGRESS_HOST)
            except Exception as e:
                self._close_ws_socket()
                logger.error("Error conectando WebSocket de notificaciones Minerva: %s", e)
                raise RuntimeError(f"Fallo conexión WebSocket Minerva: {e}") from e

    def _close_ws_socket(self) -> None:
        if self._ws_sock:
            try:
                self._ws_sock.close()
            except Exception:
                pass
            self._ws_sock = None
            self._ws_active_session = None

    def get_playback_token(self, channel_id: str) -> str:
        """Obtiene un token de reproducción m11-playback para el canal especificado."""
        mono_now = time.monotonic()
        cached = self._playback_cache.get(channel_id)
        if cached:
            token, deadline = cached
            if mono_now < deadline:
                return token
            self._playback_cache.pop(channel_id, None)

        session_jwt, region_token = self.get_session()
        categories = self.creds.get("categories", "")

        q_reg = urllib.parse.quote(region_token, safe="")
        q_cat = urllib.parse.quote(categories, safe="")
        pb_url = f"https://cdn.bo.flow.com.ar/content/api/v1/Playback/channel/{channel_id}?v=0&region={q_reg}&categories={q_cat}"

        user_id = self.creds.get("user", "")
        dev_id = self.creds.get("deviceId", "")
        dev_type = self.creds.get("deviceInfo", {}).get("type", "cloud_client")
        prof_id = self.creds.get("profile", "")
        reg_id = self.creds.get("regionId", "")

        headers = {
            "authorization": f"Bearer {session_jwt}",
            "tr-log-deviceId": dev_id,
            "tr-log-deviceType": dev_type,
            "tr-log-profileId": prof_id,
            "tr-log-regionId": reg_id,
            "x-request-id": f"Flow|WEB|4.40.3|{user_id}|{dev_id}|{int(time.time() * 1000)}",
            "User-Agent": USER_AGENT,
            "Origin": "https://portal.app.flow.com.ar",
            "Referer": "https://portal.app.flow.com.ar/",
            "Accept": "application/json, text/plain, */*",
        }

        req = urllib.request.Request(pb_url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=12.0, context=self.ssl_ctx) as resp:
                pb_json = json.loads(resp.read().decode("utf-8"))
        except Exception as e:
            logger.error("Error consultando Playback API para canal %s: %s", channel_id, e)
            raise RuntimeError(f"Fallo consulta Playback API: {e}") from e

        play_items = pb_json.get("data", {}).get("play", [])
        playback_token = None
        for p in play_items:
            if p.get("drm") == "Widevine" and p.get("playbackToken"):
                playback_token = p["playbackToken"]
                break

        if not playback_token:
            # Fallback a cualquier item con playbackToken
            for p in play_items:
                if p.get("playbackToken"):
                    playback_token = p["playbackToken"]
                    break

        if not playback_token:
            raise RuntimeError(f"No se encontró playbackToken para canal {channel_id}")

        self._playback_cache[channel_id] = (playback_token, mono_now + PLAYBACK_CACHE_TTL_SECONDS)
        return playback_token

    def _execute_license_request(
        self, session_jwt: str, playback_token: str, challenge_data: bytes
    ) -> Tuple[int, bytes, Dict[str, str]]:
        """Envía el challenge binario al endpoint Minerva PRM vía http.client HTTPS."""
        query_str = urllib.parse.urlencode({
            "m11-user-session": session_jwt,
            "m11-playback": playback_token,
        })
        lic_path = f"{M11_WIDEVINE_PATH}?{query_str}"

        user_id = self.creds.get("user", "")
        dev_id = self.creds.get("deviceId", "")

        headers = {
            "User-Agent": USER_AGENT,
            "Origin": "https://portal.app.flow.com.ar",
            "Referer": "https://portal.app.flow.com.ar/",
            "x-request-id": f"Flow|WEB|4.40.3|{user_id}|{dev_id}|{int(time.time() * 1000)}",
            "Accept": "*/*",
            "Content-Length": str(len(challenge_data)),
        }

        hconn = http.client.HTTPSConnection(INGRESS_HOST, INGRESS_PORT, context=self.ssl_ctx, timeout=12.0)
        try:
            hconn.request("POST", lic_path, body=challenge_data, headers=headers)
            resp = hconn.getresponse()
            status = resp.status
            body = resp.read()
            resp_headers = {k.lower(): v for k, v in resp.getheaders()}
            return status, body, resp_headers
        finally:
            try:
                hconn.close()
            except Exception:
                pass

    def proxy_license(
        self, slug_or_id: str, challenge_data: bytes
    ) -> Tuple[int, bytes, Dict[str, str]]:
        """Procesa una solicitud de licencia Widevine desde Kodi/InputStream Adaptive.

        Devuelve (status_code, license_bytes, headers).
        """
        if not challenge_data:
            return 400, b"Challenge Widevine vacio", {}

        if not self.is_configured:
            if not self._load_credentials():
                return 503, b"Credenciales oficiales de Flow no configuradas", {}

        channel_id = self.get_channel_id(slug_or_id)

        try:
            session_jwt, _ = self.get_session()
            self.ensure_notification_ws(session_jwt)
            playback_token = self.get_playback_token(channel_id)

            status, body, headers = self._execute_license_request(
                session_jwt, playback_token, challenge_data
            )

            # Auto-recuperación si el servidor desconectó el WebSocket ("No opened WebSocket")
            if status == 401 and b"No opened WebSocket" in body:
                logger.warning("Minerva devolvió 'No opened WebSocket'. Reconectando WS y reintentando...")
                self._close_ws_socket()
                self.ensure_notification_ws(session_jwt)
                status, body, headers = self._execute_license_request(
                    session_jwt, playback_token, challenge_data
                )

            # Auto-recuperación si la sesión venció durante la reproducción
            if status == 401 and b"AUTHENTICATION_FAILED" in body:
                logger.warning("Minerva devolvió AUTHENTICATION_FAILED. Renovando sesión y reintentando...")
                session_jwt, _ = self.get_session(force_refresh=True)
                self.ensure_notification_ws(session_jwt)
                # Invalidar token de reproducción
                self._playback_cache.pop(channel_id, None)
                playback_token = self.get_playback_token(channel_id)
                status, body, headers = self._execute_license_request(
                    session_jwt, playback_token, challenge_data
                )

            return status, body, headers
        except Exception as e:
            logger.error("Error en proxy_license para canal %s: %s", slug_or_id, e)
            return 503, f"Error en proxy de licencia Flow: {e}".encode("utf-8"), {}

    def close(self) -> None:
        """Cierra sockets y libera recursos al apagar el add-on."""
        self._close_ws_socket()
        self._playback_cache.clear()
        logger.info("FlowAuthManager cerrado limpiamente.")
