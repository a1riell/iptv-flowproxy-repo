"""
Parser de catálogo y exploración de Disney+ BAMGrid (Explore API v1.20).
Soporta resolución recursiva de acciones anidadas en contenedores 'modal'.
"""
from __future__ import annotations

import base64
import json
import logging
from typing import Any, Dict, Iterator, List, Optional

logger = logging.getLogger("flowproxy_disney_catalog")


def iter_playback_actions(actions: Any, depth: int = 0) -> Iterator[Dict[str, Any]]:
    """
    Recorre recursivamente el árbol de acciones para descubrir acciones de tipo 'playback'
    incluso si están encapsuladas dentro de acciones intermedias de tipo 'modal'.
    """
    if depth > 8 or not isinstance(actions, list):
        return

    for action in actions:
        if not isinstance(action, dict):
            continue

        act_type = action.get("type")
        if act_type == "playback" and action.get("resourceId"):
            yield action
        elif act_type == "modal":
            nested_actions = action.get("actions", [])
            yield from iter_playback_actions(nested_actions, depth + 1)


class DisneyCatalogParser:
    @staticmethod
    def parse_explore_set(set_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Normaliza una respuesta de CuratedSet de BAMGrid a una lista de señales
        y eventos directamente reproducibles.
        """
        results: List[Dict[str, Any]] = []
        set_obj = set_data.get("data", {}).get("set", {}) or {}
        items = set_obj.get("items", [])

        for item in items:
            if not isinstance(item, dict):
                continue

            vis = item.get("visuals", {}) or {}
            title = vis.get("title") or vis.get("displayText") or "Evento Disney+"
            
            # Estado del evento (vivo, hoy, replay)
            badging = vis.get("badging") or {}
            airing_state = (badging.get("airingEventState") or {}).get("state")
            timeline = (badging.get("airingEventState") or {}).get("timeline") or {}
            start_time = timeline.get("startTime")
            end_time = timeline.get("endTime")

            # Buscar acciones de reproducción (recursivas dentro de modales)
            actions = item.get("actions", [])
            play_actions = list(iter_playback_actions(actions))
            if not play_actions:
                continue

            # Priorizar from_live o primera acción con resourceId
            play_action = play_actions[0]
            resource_id = play_action.get("resourceId")
            content_type = play_action.get("contentType") or "live"
            avail_id = play_action.get("availId")
            internal_title = play_action.get("internalTitle")

            # Decodificar descriptor de resourceId si es base64
            media_id = None
            channel_id = None
            try:
                pad = -len(resource_id) % 4
                desc = json.loads(base64.b64decode(resource_id + "=" * pad).decode("utf-8"))
                media_id = desc.get("mediaId")
                channel_id = desc.get("channelId")
            except Exception:
                pass

            # Identidad determinista del binding
            if content_type == "linear":
                stable_ref = channel_id or avail_id or "linear"
                binding = f"disney-linear-{stable_ref}"
            else:
                stable_ref = media_id or avail_id or "event"
                binding = f"disney-live-{stable_ref}"

            entry = {
                "binding": binding,
                "title": title,
                "internal_title": internal_title,
                "content_type": content_type,
                "state": airing_state or ("live" if content_type == "linear" else "scheduled"),
                "start_time": start_time,
                "end_time": end_time,
                "resource_id": resource_id,
                "resource_ref": stable_ref,
                "media_id": media_id,
                "channel_id": channel_id,
                "avail_id": avail_id,
            }
            results.append(entry)

        logger.debug("CatalogParser procesó %d ítems -> %d reproducibles", len(items), len(results))
        return results
