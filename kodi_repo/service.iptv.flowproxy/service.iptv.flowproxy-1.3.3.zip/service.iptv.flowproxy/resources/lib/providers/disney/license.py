"""
Proxy de licencias Widevine para Disney+ (BAMGrid).
"""
from __future__ import annotations

import logging
from typing import Dict, Optional, Tuple

from .client_contract import ChromeWebContract
from .http_transport import DefaultHttpTransport, HttpTransport
from .models import DrmEndpointKind, PlaybackContext
from .playback_registry import PlaybackRegistry

logger = logging.getLogger("flowproxy_disney_license")


class DisneyLicenseProxy:
    def __init__(
        self,
        registry: PlaybackRegistry,
        transport: Optional[HttpTransport] = None,
        contract: Optional[ChromeWebContract] = None,
    ) -> None:
        self._registry = registry
        self._transport = transport or DefaultHttpTransport()
        self._contract = contract or ChromeWebContract()

    def proxy_license(
        self,
        binding: str,
        challenge_bytes: bytes,
        access_token: str,
        context: Optional[PlaybackContext] = None,
    ) -> Tuple[int, bytes, Dict[str, str]]:
        """
        Intercepta el desafío binario de Widevine de Kodi, asocia el snapshot inmutable
        del binding, inyecta las cabeceras exactas del contrato y reenvía a BAMGrid.
        Si se suministra context, se utiliza directamente para evitar carreras por doble lectura.
        """
        target_context = context if context is not None else self._registry.get_license_context(binding)
        if not target_context:
            logger.error("Solicitud de licencia para binding sin contexto activo: '%s'", binding)
            return 404, b"Binding context not found or expired", {"content-type": "text/plain"}

        if target_context.is_rights_expired:
            logger.error("Solicitud de licencia para binding con derechos expirados: '%s'", binding)
            return 403, b"Playback rights context expired", {"content-type": "text/plain"}

        # Seleccionar endpoint según el tipo de señal
        if target_context.drm_endpoint_kind == DrmEndpointKind.LINEAR:
            endpoint = self._contract.WIDEVINE_LINEAR_ENDPOINT
        else:
            endpoint = self._contract.WIDEVINE_EVENT_ENDPOINT

        # Construir cabeceras estrictas del contrato de licencia (Token raw sin 'Bearer')
        headers = self._contract.build_license_headers(
            access_token=access_token,
            rights_context=target_context.rights_context,
            content_length=len(challenge_bytes),
        )

        status, body, resp_headers = self._transport.request(
            method="POST",
            url=endpoint,
            headers=headers,
            body=challenge_bytes,
            timeout=10.0,
        )

        logger.debug(
            "Licencia Widevine procesada para binding '%s' -> HTTP %s (bytes=%d)",
            binding,
            status,
            len(body),
        )
        return status, body, resp_headers
