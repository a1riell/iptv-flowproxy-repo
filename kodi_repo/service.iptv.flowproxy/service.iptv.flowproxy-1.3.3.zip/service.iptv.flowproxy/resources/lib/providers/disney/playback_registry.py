"""
PlaybackRegistry: Registro centralizado y seguro de bindings de reproducción para Disney+.

Garantiza:
1. Asociación inequívoca entre GET /disney/live/{binding}.m3u8 y POST /disney/license/{binding}.
2. Publicación atómica de snapshots inmutables (PlaybackContext).
3. Agrupación Single-Flight ante peticiones concurrentes del mismo binding.
4. Política de retención que no desaloja contextos activos mientras la licencia esté en vuelo.
"""
from __future__ import annotations

import inspect
import logging
import threading
import time
from pathlib import Path
from typing import Callable, Dict, Optional, Tuple, Union

from .models import BindingRecord, PlaybackContext

logger = logging.getLogger("flowproxy_disney_registry")


class IdentityGenerationMismatch(Exception):
    """Lanzada cuando un binding muta de identidad mientras una resolución estaba en vuelo."""
    pass


def _invoke_resolve_fn(fn: Callable[..., PlaybackContext], record: BindingRecord) -> PlaybackContext:
    """
    Invoca resolve_fn pasando el BindingRecord actual si su firma acepta parámetros.
    Inspecciona la firma previamente para no enmascarar TypeErrors legítimos dentro del resolver.
    """
    accepts_arg = False
    try:
        sig = inspect.signature(fn)
        params = list(sig.parameters.values())
        if params:
            first = params[0]
            if first.kind in (
                inspect.Parameter.POSITIONAL_ONLY,
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
                inspect.Parameter.VAR_POSITIONAL,
            ):
                accepts_arg = True
    except (ValueError, TypeError):
        accepts_arg = True

    if accepts_arg:
        return fn(record)
    return fn()


class _InFlightOp:
    """Representa una operación de resolución en curso con resultado explícito, identidad versionada y deadline."""

    def __init__(
        self, generation: int, identity_generation: int, deadline: float, lock: threading.RLock
    ) -> None:
        self.condition = threading.Condition(lock)
        self.generation = generation
        self.identity_generation = identity_generation
        self.deadline = deadline
        self.completed = False
        self.invalidated = False
        self.result: Optional[BindingRecord] = None
        self.error: Optional[Exception] = None


class PlaybackRegistry:
    def __init__(self, reuse_ttl_seconds: float = 300.0) -> None:
        self._lock = threading.RLock()
        self._records: Dict[str, BindingRecord] = {}
        self._in_flight: Dict[str, _InFlightOp] = {}
        self._generation_counter: int = 0
        self._reuse_ttl = reuse_ttl_seconds

    def register_binding(
        self,
        binding: str,
        resource_ref: str,
        resource_id: str,
        content_type: str,
        contract_name: str = "chrome_web",
        profile_id: str = "default",
        session_epoch: int = 1,
    ) -> BindingRecord:
        """
        Registra o actualiza la identidad base de un binding.
        Si cambian resource_id, profile_id, contract_name o session_epoch:
        - Incrementa de manera monotónica su identity_generation.
        - Invalida inmediatamente el contexto de reproducción previo para garantizar aislamiento.
        """
        with self._lock:
            existing = self._records.get(binding)
            if existing:
                identity_changed = (
                    existing.resource_id != resource_id
                    or existing.profile_id != profile_id
                    or existing.contract_name != contract_name
                    or existing.session_epoch != session_epoch
                )
                new_gen = existing.identity_generation + 1 if identity_changed else existing.identity_generation
                if identity_changed:
                    logger.info(
                        "Identidad de binding '%s' modificada (gen %d -> %d). Invalidando contexto previo.",
                        binding,
                        existing.identity_generation,
                        new_gen,
                    )
                record = BindingRecord(
                    binding=binding,
                    resource_ref=resource_ref,
                    resource_id=resource_id,
                    content_type=content_type,
                    contract_name=contract_name,
                    profile_id=profile_id,
                    session_epoch=session_epoch,
                    identity_generation=new_gen,
                    playback_context=None if identity_changed else existing.playback_context,
                    last_resolved_at=0.0 if identity_changed else existing.last_resolved_at,
                )
            else:
                record = BindingRecord(
                    binding=binding,
                    resource_ref=resource_ref,
                    resource_id=resource_id,
                    content_type=content_type,
                    contract_name=contract_name,
                    profile_id=profile_id,
                    session_epoch=session_epoch,
                    identity_generation=1,
                )
            self._records[binding] = record
            return record

    def get_binding(self, binding: str) -> Optional[BindingRecord]:
        """Obtiene una copia inmutable del registro para el binding solicitado."""
        with self._lock:
            return self._records.get(binding)

    def get_license_context(self, binding: str) -> Optional[PlaybackContext]:
        """
        Retorna un snapshot inmutable del PlaybackContext para el endpoint de licencia.
        Valida que el contexto exista y que los derechos NO hayan expirado.
        """
        with self._lock:
            record = self._records.get(binding)
            if not record or not record.playback_context:
                return None
            ctx = record.playback_context
            if ctx.is_rights_expired:
                logger.warning("Contexto de derechos para binding '%s' expirado", binding)
                return None
            return ctx

    def update_playback_context(
        self,
        binding: str,
        context: PlaybackContext,
        resolved_at: Optional[float] = None,
        expected_generation: Optional[int] = None,
    ) -> BindingRecord:
        """
        Publica atómicamente un nuevo PlaybackContext inmutable.
        Si se especifica expected_generation, valida que la identidad del registro actual
        no haya mutado mientras la resolución estuvo en vuelo. Si mutó, levanta IdentityGenerationMismatch.
        """
        ts = resolved_at if resolved_at is not None else time.time()
        with self._lock:
            record = self._records.get(binding)
            if not record:
                raise KeyError(f"No existe registro previo para binding '{binding}'")
            if expected_generation is not None and record.identity_generation != expected_generation:
                raise IdentityGenerationMismatch(
                    f"Identidad de binding '{binding}' mutó durante la resolución en vuelo "
                    f"(esperada gen {expected_generation}, actual gen {record.identity_generation})"
                )
            updated = record.with_playback_context(context, ts)
            self._records[binding] = updated
            logger.debug(
                "PlaybackContext publicado para binding '%s' (gen=%d, DRM kind=%s)",
                binding,
                record.identity_generation,
                context.drm_endpoint_kind.value,
            )
            return updated

    def resolve_single_flight(
        self,
        binding: str,
        resolve_fn: Callable[..., PlaybackContext],
        now_ts: Optional[float] = None,
        timeout_seconds: float = 15.0,
        max_retries: int = 3,
    ) -> Tuple[BindingRecord, bool]:
        """
        Resuelve el manifiesto aplicando Single-Flight robusto y versionado de identidad:
        - Si existe un contexto vigente dentro del reuse_ttl y no expirado, lo retorna directamente (reutilizado=True).
        - Si una llamada está en curso para la identidad actual, los consumidores esperan a que termine.
        - Si el líder falla, la excepción se propaga a todos los consumidores en espera sin devolver contextos vencidos.
        - Si la identidad muta durante la resolución en vuelo (gen mismatch), el líder descarta el contexto obsoleto
          y reintenta resolviendo la identidad nueva.
        - Se respeta un deadline total acumulado para evitar bloqueos indefinidos.
        """
        deadline = (now_ts if now_ts is not None else time.time()) + timeout_seconds

        for attempt in range(max_retries):
            now = now_ts if now_ts is not None else time.time()
            if now >= deadline:
                raise TimeoutError(f"Tiempo de espera total agotado resolviendo binding '{binding}'")

            is_leader = False
            with self._lock:
                record = self._records.get(binding)
                if not record:
                    raise KeyError(f"Binding desconocido: '{binding}'")

                # Comprobar reutilización válida (URL y derechos no expirados dentro del TTL)
                ctx = record.playback_context
                if ctx and not ctx.is_url_expired and not ctx.is_rights_expired:
                    if (now - record.last_resolved_at) < self._reuse_ttl:
                        return record, True

                target_gen = record.identity_generation

                if binding in self._in_flight:
                    op = self._in_flight[binding]
                    if op.identity_generation == target_gen:
                        is_leader = False
                    else:
                        # Operación in-flight para generación obsoleta; esperamos a que limpie o aborte
                        is_leader = False
                else:
                    self._generation_counter += 1
                    op = _InFlightOp(
                        generation=self._generation_counter,
                        identity_generation=target_gen,
                        deadline=deadline,
                        lock=self._lock,
                    )
                    self._in_flight[binding] = op
                    is_leader = True

            if not is_leader:
                # Seguidor: esperar a que la operación en curso termine respetando el deadline
                with self._lock:
                    while not op.completed:
                        remaining = op.deadline - time.time()
                        if remaining <= 0:
                            raise TimeoutError(f"Tiempo de espera total agotado resolviendo binding '{binding}'")
                        op.condition.wait(timeout=min(remaining, 0.2))

                    if op.invalidated:
                        # La operación previa fue invalidada por mutación de identidad en vuelo.
                        # El seguidor no debe lanzar timeout; reintenta en el bucle for
                        # para unirse o liderar la resolución de la nueva generación.
                        continue

                    if op.error is not None:
                        raise op.error

                    if op.result is not None:
                        current = self._records.get(binding)
                        if (
                            current
                            and op.result.identity_generation == current.identity_generation
                            and op.result.playback_context
                            and not op.result.playback_context.is_url_expired
                            and not op.result.playback_context.is_rights_expired
                        ):
                            return op.result, True

                # Si el resultado fue para otra generación o no es válido, reintentar en el bucle
                continue

            # Somos el líder para esta operación
            op_cleaned_up = False
            try:
                new_context = _invoke_resolve_fn(resolve_fn, record)
                if new_context.is_url_expired or new_context.is_rights_expired:
                    raise ValueError(f"La resolución de '{binding}' produjo un contexto ya vencido")

                with self._lock:
                    updated_record = self.update_playback_context(
                        binding,
                        new_context,
                        now_ts if now_ts is not None else time.time(),
                        expected_generation=target_gen,
                    )
                    op.result = updated_record
                    op.completed = True
                    return updated_record, False

            except IdentityGenerationMismatch as mismatch_err:
                logger.warning(
                    "Resolución descartada por mutación de identidad en vuelo para '%s': %s. Reintentando...",
                    binding,
                    mismatch_err,
                )
                with self._lock:
                    op.invalidated = True
                    op.completed = True
                    if self._in_flight.get(binding) is op:
                        self._in_flight.pop(binding, None)
                    op_cleaned_up = True
                    with op.condition:
                        op.condition.notify_all()
                continue

            except Exception as exc:
                with self._lock:
                    op.error = exc
                    op.completed = True
                raise

            finally:
                if not op_cleaned_up:
                    with self._lock:
                        if self._in_flight.get(binding) is op:
                            self._in_flight.pop(binding, None)
                        with op.condition:
                            op.condition.notify_all()

        raise RuntimeError(
            f"Se superó el límite de reintentos ({max_retries}) resolviendo binding '{binding}' debido a mutaciones concurrentes de identidad"
        )

    def clear(self) -> None:
        """Limpia el registro de bindings."""
        with self._lock:
            self._records.clear()
            self._in_flight.clear()


    def save_to_file(self, path: Union[str, Path]) -> None:
        """Persiste los bindings (sin contextos volátiles) en un archivo JSON atómico."""
        import json
        import os
        import tempfile

        dest = Path(path)
        dest.parent.mkdir(parents=True, exist_ok=True)
        payload = {}
        with self._lock:
            for b, r in self._records.items():
                payload[b] = {
                    "resource_ref": r.resource_ref,
                    "resource_id": r.resource_id,
                    "content_type": r.content_type,
                    "contract_name": r.contract_name,
                    "profile_id": r.profile_id,
                    "session_epoch": r.session_epoch,
                }

        tmp_fd, tmp_path = tempfile.mkstemp(prefix="disney_bindings_", dir=str(dest.parent))
        try:
            with open(tmp_fd, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2)
            os.replace(tmp_path, dest)
            logger.debug("Persistidos %d bindings Disney en %s", len(payload), dest)
        except Exception:
            if os.path.exists(tmp_path):
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
            raise

    def load_from_file(self, path: Union[str, Path]) -> int:
        """Carga bindings persistidos desde un archivo JSON."""
        import json

        src = Path(path)
        if not src.is_file():
            return 0

        try:
            with open(src, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                return 0
            count = 0
            for b, item in data.items():
                if not isinstance(item, dict):
                    continue
                self.register_binding(
                    binding=b,
                    resource_ref=item.get("resource_ref", b),
                    resource_id=item.get("resource_id", ""),
                    content_type=item.get("content_type", "live"),
                    contract_name=item.get("contract_name", "chrome_web"),
                    profile_id=item.get("profile_id", "default"),
                    session_epoch=item.get("session_epoch", 1),
                )
                count += 1
            logger.info("Cargados %d bindings Disney desde %s", count, src)
            return count
        except Exception as e:
            logger.warning("No se pudieron cargar bindings Disney desde %s: %e", src, e)
            return 0
