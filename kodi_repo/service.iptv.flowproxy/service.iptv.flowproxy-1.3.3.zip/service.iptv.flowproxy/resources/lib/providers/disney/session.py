"""
Gestor de sesión y credenciales para Disney+ (BAMGrid).
Totalmente desacoplado de Kodi, con soporte para recarga automática,
coordinador Single-Flight de refresco, lock interproceso y persistencia atómica.
"""
from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import ssl
import tempfile
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, Union

from .client_contract import ChromeWebContract
from .http_transport import DefaultHttpTransport, HttpTransport, UpstreamHttpError
from .models import (
    AccessTokenSnapshot,
    AuthError,
    AuthNetworkError,
    AuthResponseInvalidError,
    AuthState,
    ReauthRequiredError,
)

logger = logging.getLogger("flowproxy_disney_session")

BOOTSTRAP_SECRET_KEY = "IPTV_FLOWPROXY_SECRET_2026"
DEFAULT_DISNEY_GIST_BOOTSTRAP_URL = (
    "https://gist.githubusercontent.com/a1riell/9c1db121510fc81709f28c132afb9c81/raw/disney_session.dat"
)


def _deobfuscate_credentials(obfuscated_b64: str, secret_key: str = BOOTSTRAP_SECRET_KEY) -> bytes:
    key_bytes = hashlib.sha256(secret_key.encode("utf-8")).digest()
    data = base64.b64decode(obfuscated_b64.strip())
    out = bytearray(len(data))
    for i in range(len(data)):
        out[i] = data[i] ^ key_bytes[i % len(key_bytes)]
    return bytes(out)


REFRESH_MUTATION = (
    "mutation refreshToken($input:RefreshTokenInput!) { "
    "refreshToken(refreshToken:$input) { activeSession{sessionId} } }"
)


def find_session_file(custom_path: Optional[Union[str, Path]] = None) -> Optional[Path]:
    """Localiza el archivo de sesión de Disney en las ubicaciones estándar."""
    if custom_path:
        p = Path(custom_path)
        if p.is_file():
            return p

    # 1. Variable de entorno
    env_path = os.environ.get("DISNEY_SESSION_PATH")
    if env_path and Path(env_path).is_file():
        return Path(env_path)

    # 2. Addon profile directory de Kodi (si se ejecuta dentro de Kodi)
    try:
        import xbmcaddon
        import xbmcvfs
        addon = xbmcaddon.Addon("service.iptv.flowproxy")
        profile_dir = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        p = Path(profile_dir) / "disney_session.json"
        if p.is_file():
            return p
    except Exception:
        pass

    # 3. Ubicaciones directas conocidas
    candidates = [
        Path.home() / ".kodi" / "userdata" / "addon_data" / "service.iptv.flowproxy" / "disney_session.json",
        Path.home() / ".flow_cache" / "disney_session.json",
        Path("/storage/emulated/0/Download/disney_session.json"),
        Path("/sdcard/Download/disney_session.json"),
        Path.home() / "disney_session.json",
    ]

    for cand in candidates:
        try:
            if cand.is_file():
                return cand
        except OSError:
            continue

    return None


class InterProcessFileLock:
    """
    Abstracción de lock interproceso portátil.
    Utiliza fcntl.flock si está disponible y soportado en el sistema de archivos.
    Aplica fallback basado en creación atómica de archivo (O_CREAT | O_EXCL)
    con detección de locks obsoletos (stale locks).
    """

    def __init__(
        self,
        lock_path: Union[str, Path],
        timeout_seconds: float = 10.0,
        poll_interval: float = 0.05,
    ) -> None:
        self.lock_path = Path(lock_path)
        self.timeout_seconds = timeout_seconds
        self.poll_interval = poll_interval
        self._fd: Optional[int] = None
        self._mode: Optional[str] = None
        self._nonce: str = ""

    def __enter__(self) -> "InterProcessFileLock":
        self.acquire()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.release()

    @staticmethod
    def _is_pid_alive(pid: int) -> bool:
        """Comprueba fehacientemente si un PID sigue existiendo a nivel de SO."""
        if pid <= 0:
            return False
        try:
            os.kill(pid, 0)
            return True
        except OSError as err:
            import errno
            if err.errno == errno.ESRCH:
                # El proceso definitivamente no existe
                return False
            # EPERM u otro error significa que el proceso existe pero pertenece a otro usuario
            return True

    def acquire(self) -> None:
        self.lock_path.parent.mkdir(parents=True, exist_ok=True)
        start_time = time.time()
        import uuid
        self._nonce = uuid.uuid4().hex

        has_fcntl = False
        try:
            import fcntl
            has_fcntl = True
        except ImportError:
            has_fcntl = False

        if has_fcntl:
            try:
                self._fd = os.open(str(self.lock_path), os.O_CREAT | os.O_RDWR, 0o600)
                while True:
                    try:
                        import fcntl
                        fcntl.flock(self._fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                        self._mode = "flock"
                        return
                    except (BlockingIOError, OSError):
                        if (time.time() - start_time) >= self.timeout_seconds:
                            raise TimeoutError(
                                f"Timeout ({self.timeout_seconds}s) adquiriendo flock en {self.lock_path}"
                            )
                        time.sleep(self.poll_interval)
            except (OSError, AttributeError):
                if self._fd is not None:
                    try:
                        os.close(self._fd)
                    except OSError:
                        pass
                    self._fd = None

        # Fallback a creación atómica de archivo (Windows / filesystems especiales)
        self._mode = "atomic_file"
        stale_timeout = max(self.timeout_seconds * 3.0, 30.0)
        while True:
            try:
                self._fd = os.open(str(self.lock_path), os.O_CREAT | os.O_EXCL | os.O_RDWR, 0o600)
                payload = f"{os.getpid()}:{self._nonce}:{time.time()}\n".encode("utf-8")
                os.write(self._fd, payload)
                return
            except FileExistsError:
                # Comprobar si el lockfile pertenece a un proceso que ya murió (stale recovery seguro)
                try:
                    raw_content = self.lock_path.read_text(encoding="utf-8").strip()
                    parts = raw_content.split(":")
                    lock_pid = int(parts[0]) if parts and parts[0].isdigit() else None
                    lock_time = float(parts[2]) if len(parts) > 2 else 0.0

                    pid_alive = self._is_pid_alive(lock_pid) if lock_pid is not None else False
                    age = time.time() - lock_time if lock_time > 0 else (time.time() - self.lock_path.stat().st_mtime)

                    is_dead_process = (lock_pid is not None and not pid_alive)
                    is_corrupt_and_stale = (lock_pid is None and age > stale_timeout)

                    # SOLO se recupera si el proceso ya NO está vivo o si el archivo no tiene PID válido y superó stale_timeout
                    if is_dead_process or is_corrupt_and_stale:
                        try:
                            # Verificar que no fue reemplazado antes de borrar
                            if self.lock_path.is_file() and self.lock_path.read_text(encoding="utf-8").strip() == raw_content:
                                os.unlink(str(self.lock_path))
                        except OSError:
                            pass
                except Exception:
                    pass

                if (time.time() - start_time) >= self.timeout_seconds:
                    raise TimeoutError(
                        f"Timeout ({self.timeout_seconds}s) adquiriendo lock atómico en {self.lock_path}"
                    )
                time.sleep(self.poll_interval)

    def release(self) -> None:
        if self._mode == "flock" and self._fd is not None:
            try:
                import fcntl
                fcntl.flock(self._fd, fcntl.LOCK_UN)
            except Exception:
                pass
            try:
                os.close(self._fd)
            except OSError:
                pass
            self._fd = None
        elif self._mode == "atomic_file":
            if self._fd is not None:
                try:
                    os.close(self._fd)
                except OSError:
                    pass
                self._fd = None
            try:
                # Solo desvincular si el archivo en disco todavía contiene nuestro nonce
                if self.lock_path.is_file():
                    content = self.lock_path.read_text(encoding="utf-8").strip()
                    if self._nonce and self._nonce in content:
                        os.unlink(str(self.lock_path))
            except OSError:
                pass


def validate_absolute_epoch_expires(
    raw_exp: Any, access_token: str
) -> Optional[float]:
    """
    Valida de forma estricta que la expiración sea un epoch absoluto (fail-closed).
    Reglas:
    - Debe ser numérico y >= 1_000_000_000.0 (año 2001+). Valores menores (ej. 14400)
      son relativos o inválidos y son rechazados terminantemente; no se adivina.
    - Si falta en raw_exp, se extrae el claim 'exp' del JWT si es válido y >= 1_000_000_000.
    - Si ambos existen, no deben contradecirse significativamente.
    - Si no puede validarse fehacientemente, retorna None.
    """
    exp_val: Optional[float] = None
    if isinstance(raw_exp, (int, float)) and raw_exp >= 1_000_000_000.0:
        exp_val = float(raw_exp)
    elif isinstance(raw_exp, str) and raw_exp.strip().replace(".", "", 1).isdigit():
        val = float(raw_exp.strip())
        if val >= 1_000_000_000.0:
            exp_val = val

    jwt_exp: Optional[float] = None
    parts = access_token.split(".")
    if len(parts) >= 2:
        try:
            pad = -len(parts[1]) % 4
            claims = json.loads(base64.b64decode(parts[1] + "=" * pad).decode("utf-8"))
            if "exp" in claims and isinstance(claims["exp"], (int, float)):
                if float(claims["exp"]) >= 1_000_000_000.0:
                    jwt_exp = float(claims["exp"])
        except Exception:
            pass

    if exp_val is not None and jwt_exp is not None:
        # Si ambos están presentes, verificar consistencia (tolerancia de 5 min)
        if abs(exp_val - jwt_exp) > 300.0:
            logger.warning(
                "Inconsistencia en expiración de sesión: 'expires' (%f) contradice 'jwt.exp' (%f). Fallando cerrado.",
                exp_val,
                jwt_exp,
            )
            return None
        return exp_val

    if exp_val is not None:
        return exp_val

    if jwt_exp is not None:
        return jwt_exp

    logger.warning(
        "Sesión Disney rechazada: 'expires' falta o es relativo (< 1e9) y JWT sin claim 'exp' absoluto válido"
    )
    return None


class DisneySessionManager:
    """
    Gestiona el ciclo de vida, rotación y persistencia de sesión Disney+ (BAMGrid).
    Implementa Single-Flight para refresco concurrente, liberación de locks en I/O,
    lock interproceso con doble lectura en disco y persistencia atómica con fsync.
    """

    def __init__(
        self,
        session_path: Optional[Union[str, Path]] = None,
        transport: Optional[HttpTransport] = None,
    ) -> None:
        self._lock = threading.RLock()
        self._refresh_condition = threading.Condition(self._lock)
        self._is_refreshing: bool = False
        self._refresh_error: Optional[Exception] = None

        self._explicit_path = Path(session_path) if session_path else None
        self._resolved_path: Optional[Path] = None
        self._cached_session: Optional[Dict[str, Any]] = None
        self._cached_snapshot: Optional[AccessTokenSnapshot] = None
        self._last_mtime: float = 0.0

        self._token_generation: int = 1
        self._session_epoch: int = 1
        self.state: AuthState = AuthState.UNCONFIGURED
        self._transport = transport or DefaultHttpTransport()
        self._last_bootstrap_attempt: float = 0.0

    def _bootstrap_remote_session(self) -> Optional[Path]:
        """Descarga de forma segura la sesión de Disney ofuscada desde el Secret Gist en el primer inicio."""
        now = time.monotonic()
        if (now - self._last_bootstrap_attempt) < 30.0:
            return None
        self._last_bootstrap_attempt = now

        try:
            logger.info("[IPTV Disney] No se encontró sesión local. Intentando bootstrap seguro desde Secret Gist...")
            req = urllib.request.Request(
                DEFAULT_DISNEY_GIST_BOOTSTRAP_URL,
                headers={"User-Agent": ChromeWebContract.USER_AGENT},
            )
            ctx = ssl.create_default_context()
            with urllib.request.urlopen(req, timeout=12.0, context=ctx) as resp:
                data = resp.read().decode("utf-8").strip()

            raw_bytes = _deobfuscate_credentials(data)
            session_payload = json.loads(raw_bytes.decode("utf-8"))
            if not isinstance(session_payload, dict) or not session_payload.get("access_token"):
                logger.error("[IPTV Disney] Payload remoto de sesión inválido (falta access_token).")
                return None

            # Determinar carpeta de destino con permisos de escritura
            target_file: Optional[Path] = None
            try:
                import xbmcaddon
                import xbmcvfs
                addon = xbmcaddon.Addon("service.iptv.flowproxy")
                profile_dir = Path(xbmcvfs.translatePath(addon.getAddonInfo("profile")))
                profile_dir.mkdir(parents=True, exist_ok=True)
                target_file = profile_dir / "disney_session.json"
            except Exception:
                pass

            if not target_file:
                for candidate_dir in [
                    Path.home() / ".kodi" / "userdata" / "addon_data" / "service.iptv.flowproxy",
                    Path.home() / ".flow_cache",
                    Path("/storage/emulated/0/Download"),
                    Path("/sdcard/Download"),
                    Path.home(),
                ]:
                    try:
                        if candidate_dir.is_dir() or candidate_dir.parent.is_dir():
                            candidate_dir.mkdir(parents=True, exist_ok=True)
                            target_file = candidate_dir / "disney_session.json"
                            break
                    except Exception:
                        pass

            if not target_file:
                target_file = Path("/tmp") / "disney_session.json"

            self.save_session(session_payload, target_path=target_file)
            self._resolved_path = target_file
            self._cached_session = session_payload
            self._last_mtime = target_file.stat().st_mtime if target_file.is_file() else 0.0
            self._parse_and_cache_snapshot_locked(session_payload)
            logger.info("[IPTV Disney] ¡Sesión Disney configurada automáticamente desde Secret Gist en %s!", target_file)
            try:
                import xbmc
                xbmc.executebuiltin('Notification(Disney+,Sesión Disney configurada automáticamente,3500)')
            except Exception:
                pass
            return target_file
        except Exception as e:
            logger.warning("[IPTV Disney] No se pudo descargar la sesión remota desde Gist: %s", e)
            return None

    @property
    def session_path(self) -> Optional[Path]:
        with self._lock:
            if self._resolved_path and self._resolved_path.is_file():
                return self._resolved_path
            found = find_session_file(self._explicit_path)
            if found:
                self._resolved_path = found
                return self._resolved_path
            if not self._explicit_path:
                bootstrapped = self._bootstrap_remote_session()
                if bootstrapped:
                    self._resolved_path = bootstrapped
                    return self._resolved_path
            return None

    @property
    def token_generation(self) -> int:
        with self._lock:
            return self._token_generation

    @property
    def session_epoch(self) -> int:
        with self._lock:
            return self._session_epoch

    def get_session(self) -> Optional[Dict[str, Any]]:
        """Obtiene la sesión actual, recargando del disco si el archivo fue modificado."""
        with self._lock:
            path = self.session_path
            if not path or not path.is_file():
                self.state = AuthState.UNCONFIGURED
                return None

            try:
                mtime = path.stat().st_mtime
                if self._cached_session is not None and mtime == self._last_mtime:
                    return self._cached_session

                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)

                if isinstance(data, dict):
                    self._cached_session = data
                    self._last_mtime = mtime
                    self._parse_and_cache_snapshot_locked(data)
                    return self._cached_session
            except Exception as e:
                logger.warning("Error leyendo archivo de sesión Disney (%s): %s", path, e)

            return None

    def _parse_and_cache_snapshot_locked(self, data: Dict[str, Any]) -> Optional[AccessTokenSnapshot]:
        token = data.get("access_token")
        if not token or not isinstance(token, str) or not token.strip():
            self.state = AuthState.REAUTH_REQUIRED
            self._cached_snapshot = None
            return None
        token = token.strip()

        raw_exp = data.get("expires_at", data.get("expires"))
        validated_exp = validate_absolute_epoch_expires(raw_exp, token)
        if validated_exp is None:
            self.state = AuthState.REAUTH_REQUIRED
            self._cached_snapshot = None
            return None

        # Sincronizar generación y epoch si están en disco
        disk_gen = data.get("token_generation")
        if isinstance(disk_gen, int) and disk_gen > self._token_generation:
            self._token_generation = disk_gen

        disk_epoch = data.get("session_epoch")
        if isinstance(disk_epoch, int) and disk_epoch > self._session_epoch:
            self._session_epoch = disk_epoch

        contract = str(data.get("contract_name", "chrome_web"))

        snapshot = AccessTokenSnapshot(
            token=token,
            token_generation=self._token_generation,
            expires_at=validated_exp,
            session_epoch=self._session_epoch,
            contract_name=contract,
        )
        self._cached_snapshot = snapshot
        has_refresh = bool(data.get("refresh_token") and isinstance(data.get("refresh_token"), str) and data["refresh_token"].strip())
        if time.time() >= (validated_exp - 60.0):
            if not has_refresh:
                self.state = AuthState.REAUTH_REQUIRED
            else:
                self.state = AuthState.READY
        else:
            self.state = AuthState.READY
        return snapshot

    def get_access_token_snapshot(
        self,
        safety_margin_seconds: float = 180.0,
        timeout_seconds: float = 15.0,
    ) -> Optional[AccessTokenSnapshot]:
        """
        Retorna el AccessTokenSnapshot vigente. Si el token está próximo a expirar
        (o expirado) y existe un refresh_token, ejecuta o espera la rotación autónoma.
        Si el estado es REAUTH_REQUIRED, falla cerrado y retorna None.
        """
        with self._lock:
            if self.state == AuthState.REAUTH_REQUIRED:
                # Una copia local vencida no debe bloquear para siempre el
                # bootstrap remoto. Esto permite que un TV Box ya instalado
                # adopte la sesión más reciente publicada en el Gist.
                if not self._explicit_path:
                    bootstrapped = self._bootstrap_remote_session()
                    if bootstrapped:
                        self._resolved_path = bootstrapped
                        self._cached_session = None
                        self._cached_snapshot = None
                        self.state = AuthState.UNCONFIGURED
                if self.state == AuthState.REAUTH_REQUIRED:
                    return None

            # Asegurar carga inicial
            if self._cached_snapshot is None:
                self.get_session()
                if self.state == AuthState.REAUTH_REQUIRED:
                    return None

            snap = self._cached_snapshot
            now = time.time()
            if snap is not None and now < (snap.expires_at - safety_margin_seconds):
                return snap

            # Si no hay snapshot o está por expirar, refrescar
            failed_gen = snap.token_generation if snap is not None else None

        # Llamar a refresh_if_generation fuera del lock principal
        try:
            return self.refresh_if_generation(
                failed_generation=failed_gen,
                timeout_seconds=timeout_seconds,
            )
        except Exception as exc:
            logger.warning("Fallo al obtener token snapshot actualizado: %s", exc)
            return None

    def get_access_token(self, safety_margin_seconds: float = 60.0) -> Optional[str]:
        """Método de compatibilidad hacia atrás que devuelve el access_token crudo."""
        snap = self.get_access_token_snapshot(safety_margin_seconds=safety_margin_seconds)
        return snap.token if snap else None

    def is_authenticated(self) -> bool:
        """Indica si existe una sesión con token vigente no expirado."""
        return self.get_access_token(safety_margin_seconds=0.0) is not None

    def get_profile_id(self) -> Optional[str]:
        """Retorna el profile_id si está definido en la sesión."""
        session = self.get_session()
        if session:
            return session.get("profile_id")
        return None

    def refresh_if_generation(
        self,
        failed_generation: Optional[int] = None,
        timeout_seconds: float = 15.0,
    ) -> AccessTokenSnapshot:
        """
        Renueva el token de Disney de manera coordinada (Single-Flight).
        - Si otro hilo ya avanzó la generación, devuelve el snapshot actualizado inmediatamente.
        - El líder libera el lock de memoria durante I/O HTTP y bloqueo interproceso.
        - Los seguidores esperan en una Condition con deadline.
        - Aplica double-checked locking tras adquirir el lock interproceso leyendo el disco.
        """
        deadline = time.time() + timeout_seconds

        with self._lock:
            # 1. Comprobar si ya avanzó la generación o hay un token válido
            if self._cached_snapshot is not None:
                if failed_generation is not None and self._cached_snapshot.token_generation > failed_generation:
                    if time.time() < (self._cached_snapshot.expires_at - 60.0):
                        return self._cached_snapshot

            if self._is_refreshing:
                # Seguidor: esperar a que el líder termine
                while self._is_refreshing:
                    remaining = deadline - time.time()
                    if remaining <= 0:
                        raise TimeoutError(
                            f"Timeout ({timeout_seconds}s) esperando refresco concurrente de token Disney"
                        )
                    self._refresh_condition.wait(timeout=min(remaining, 0.2))

                if self._refresh_error is not None:
                    raise self._refresh_error

                if self._cached_snapshot is not None:
                    if failed_generation is None or self._cached_snapshot.token_generation > failed_generation:
                        return self._cached_snapshot

            # Somos el líder para este ciclo de refresco
            self._is_refreshing = True
            self._refresh_error = None
            self.state = AuthState.REFRESHING

        # Fuera de self._lock: realizamos el trabajo pesado y I/O
        try:
            dest = self.session_path
            if not dest:
                dest = (
                    Path.home()
                    / ".kodi"
                    / "userdata"
                    / "addon_data"
                    / "service.iptv.flowproxy"
                    / "disney_session.json"
                )

            lock_file = dest.parent / "disney_session.lock"
            rem_timeout = max(deadline - time.time(), 1.0)

            with InterProcessFileLock(lock_file, timeout_seconds=rem_timeout):
                # 2. Doble comprobación en disco (otro proceso pudo haber refrescado)
                disk_data = self._read_json_file(dest)
                if disk_data:
                    token_str = disk_data.get("access_token", "")
                    raw_exp = disk_data.get("expires_at", disk_data.get("expires"))
                    valid_exp = validate_absolute_epoch_expires(raw_exp, token_str)
                    disk_gen = disk_data.get("token_generation", self._token_generation)

                    # Si en disco ya hay un token más nuevo o no expirado, consumirlo
                    if valid_exp is not None and valid_exp > (time.time() + 60.0):
                        if failed_generation is None or disk_gen > failed_generation:
                            with self._lock:
                                self._token_generation = disk_gen
                                self._cached_session = disk_data
                                self._last_mtime = dest.stat().st_mtime if dest.is_file() else 0.0
                                snap = self._parse_and_cache_snapshot_locked(disk_data)
                                if snap:
                                    logger.info(
                                        "Token Disney fresco detectado en disco tras lock interproceso (gen=%d)",
                                        disk_gen,
                                    )
                                    self.state = AuthState.READY
                                    return snap

                # 3. Necesitamos rotar el token upstream
                refresh_token = disk_data.get("refresh_token") if disk_data else None
                if not refresh_token or not isinstance(refresh_token, str) or not refresh_token.strip():
                    if not self._explicit_path:
                        bootstrapped = self._bootstrap_remote_session()
                        if bootstrapped:
                            disk_data = self._read_json_file(bootstrapped)
                            if disk_data:
                                token_str = disk_data.get("access_token", "")
                                raw_exp = disk_data.get("expires_at", disk_data.get("expires"))
                                valid_exp = validate_absolute_epoch_expires(raw_exp, token_str)
                                if valid_exp is not None and valid_exp > (time.time() + 60.0):
                                    snap = self._parse_and_cache_snapshot_locked(disk_data)
                                    if snap:
                                        self.state = AuthState.READY
                                        return snap
                                if disk_data.get("refresh_token"):
                                    refresh_token = str(disk_data["refresh_token"]).strip()

                    if not refresh_token or not isinstance(refresh_token, str) or not refresh_token.strip():
                        with self._lock:
                            self.state = AuthState.REAUTH_REQUIRED
                        raise ReauthRequiredError(
                            "No se encontró un 'refresh_token' válido en la sesión de Disney para rotar"
                        )

                try:
                    new_access_token, new_refresh_token, expires_in = self._execute_upstream_refresh(
                        refresh_token.strip()
                    )
                except ReauthRequiredError:
                    if not self._explicit_path:
                        bootstrapped = self._bootstrap_remote_session()
                        if bootstrapped:
                            disk_data = self._read_json_file(bootstrapped)
                            if disk_data:
                                token_str = disk_data.get("access_token", "")
                                raw_exp = disk_data.get("expires_at", disk_data.get("expires"))
                                valid_exp = validate_absolute_epoch_expires(raw_exp, token_str)
                                if valid_exp is not None and valid_exp > (time.time() + 60.0):
                                    snap = self._parse_and_cache_snapshot_locked(disk_data)
                                    if snap:
                                        self.state = AuthState.READY
                                        return snap
                    raise

                now = time.time()
                new_expires_at = now + float(expires_in)

                with self._lock:
                    self._token_generation += 1
                    current_gen = self._token_generation
                    current_epoch = self._session_epoch

                # Preparar payload a persistir
                updated_payload = dict(disk_data) if disk_data else {}
                updated_payload["access_token"] = new_access_token
                updated_payload["refresh_token"] = new_refresh_token
                updated_payload["expires_at"] = new_expires_at
                updated_payload["expires"] = new_expires_at  # Compatibilidad
                updated_payload["token_generation"] = current_gen
                updated_payload["session_epoch"] = current_epoch

                # 4. Persistencia Atómica con fsync estricto
                self.save_session(updated_payload, target_path=dest)

                new_snapshot = AccessTokenSnapshot(
                    token=new_access_token,
                    token_generation=current_gen,
                    expires_at=new_expires_at,
                    session_epoch=current_epoch,
                    contract_name=str(updated_payload.get("contract_name", "chrome_web")),
                )

                with self._lock:
                    self._cached_session = updated_payload
                    self._cached_snapshot = new_snapshot
                    self.state = AuthState.READY
                    logger.info(
                        "Token de acceso Disney renovado y rotado exitosamente (gen=%d, expiresIn=%d s)",
                        current_gen,
                        expires_in,
                    )
                    return new_snapshot

        except Exception as exc:
            with self._lock:
                self._refresh_error = exc
                if isinstance(exc, (ReauthRequiredError, AuthResponseInvalidError)):
                    self.state = AuthState.REAUTH_REQUIRED
                else:
                    self.state = AuthState.TEMPORARILY_UNAVAILABLE
            raise
        finally:
            with self._lock:
                self._is_refreshing = False
                self._refresh_condition.notify_all()

    def _execute_upstream_refresh(self, refresh_token: str) -> Tuple[str, str, int]:
        """
        Ejecuta la mutación GraphQL refreshToken contra BAMGrid.
        Valida que la respuesta sea completa y no contenga errores.
        Sanitiza logs: NUNCA imprime secretos ni tokens.
        """
        headers = ChromeWebContract.build_refresh_headers()
        payload = {
            "operationName": "refreshToken",
            "variables": {
                "input": {
                    "refreshToken": refresh_token,
                },
            },
            "query": REFRESH_MUTATION,
        }
        body = json.dumps(payload).encode("utf-8")

        try:
            status, resp_bytes, _ = self._transport.request(
                method="POST",
                url=ChromeWebContract.GRAPHQL_DEVICE_ENDPOINT,
                headers=headers,
                body=body,
                timeout=12.0,
            )
        except Exception as exc:
            raise AuthNetworkError(f"Error de red contactando BAMGrid refreshToken: {exc}") from exc

        if status != 200:
            if status in (400, 401, 403):
                raise ReauthRequiredError(f"BAMGrid rechazó el refresh token (HTTP {status})")
            raise UpstreamHttpError(status, resp_bytes, {})

        try:
            resp_json = json.loads(resp_bytes.decode("utf-8"))
        except Exception as exc:
            raise AuthResponseInvalidError(f"Respuesta de BAMGrid no es JSON válido: {exc}") from exc

        # Comprobar errores GraphQL
        if resp_json.get("errors"):
            errors = resp_json["errors"]
            first_err = errors[0] if isinstance(errors, list) and errors else {}
            err_code = first_err.get("extensions", {}).get("code", "")
            err_msg = first_err.get("message", "Error GraphQL desconocido")
            if any(k in err_code.lower() for k in ("invalid", "revoked", "bad-credentials", "unauthorized")):
                raise ReauthRequiredError(f"Refresh token inválido o revocado ({err_code}): {err_msg}")
            raise AuthResponseInvalidError(f"Error devuelto por BAMGrid ({err_code}): {err_msg}")

        # Extraer credenciales desde extensions.sdk.token
        sdk = resp_json.get("extensions", {}).get("sdk", {})
        token_info = sdk.get("token", {})
        access_token = token_info.get("accessToken")
        new_refresh_token = token_info.get("refreshToken")
        expires_in = token_info.get("expiresIn")

        if not access_token or not isinstance(access_token, str) or not access_token.strip():
            raise AuthResponseInvalidError("BAMGrid no entregó un 'accessToken' válido")

        if not new_refresh_token or not isinstance(new_refresh_token, str) or not new_refresh_token.strip():
            raise AuthResponseInvalidError("BAMGrid no entregó un 'refreshToken' rotado")

        if not isinstance(expires_in, (int, float)) or expires_in < 60 or expires_in > 2592000:
            raise AuthResponseInvalidError(
                f"BAMGrid entregó un 'expiresIn' fuera de rango razonable: {expires_in}"
            )

        return access_token.strip(), new_refresh_token.strip(), int(expires_in)

    def _read_json_file(self, path: Path) -> Optional[Dict[str, Any]]:
        if not path or not path.is_file():
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                d = json.load(f)
                return d if isinstance(d, dict) else None
        except Exception:
            return None

    def save_session(
        self, data: Dict[str, Any], target_path: Optional[Union[str, Path]] = None
    ) -> None:
        """
        Guarda atómicamente la sesión en disco con permisos 0600.
        Garantiza flush() y fsync() antes de os.replace(), y fsync del directorio.
        Si la persistencia falla, invalida el token en RAM y transiciona a REAUTH_REQUIRED.
        """
        with self._lock:
            dest = Path(target_path) if target_path else self.session_path
            if not dest:
                dest = (
                    Path.home()
                    / ".kodi"
                    / "userdata"
                    / "addon_data"
                    / "service.iptv.flowproxy"
                    / "disney_session.json"
                )

            dest.parent.mkdir(parents=True, exist_ok=True)
            tmp_fd, tmp_path = tempfile.mkstemp(
                prefix="disney_sess_", dir=str(dest.parent)
            )
            try:
                with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=2)
                    f.flush()
                    os.fsync(f.fileno())

                os.chmod(tmp_path, 0o600)
                os.replace(tmp_path, dest)

                # fsync del directorio padre
                try:
                    dir_fd = os.open(str(dest.parent), os.O_RDONLY)
                    try:
                        os.fsync(dir_fd)
                    finally:
                        os.close(dir_fd)
                except (OSError, AttributeError):
                    pass

                self._resolved_path = dest
                self._cached_session = data
                self._last_mtime = dest.stat().st_mtime
                self._parse_and_cache_snapshot_locked(data)
                logger.debug("Sesión Disney guardada atómicamente en %s", dest)

            except Exception as exc:
                logger.error("Fallo crítico persistiendo sesión Disney en disco: %s", exc)
                # Fail-closed estricto: nunca mantener en RAM un token que falló al persistirse
                self.state = AuthState.REAUTH_REQUIRED
                self._cached_snapshot = None
                self._cached_session = None
                if os.path.exists(tmp_path):
                    try:
                        os.unlink(tmp_path)
                    except OSError:
                        pass
                raise ReauthRequiredError(
                    f"Fallo de persistencia atómica en disco tras rotación de token: {exc}"
                ) from exc
