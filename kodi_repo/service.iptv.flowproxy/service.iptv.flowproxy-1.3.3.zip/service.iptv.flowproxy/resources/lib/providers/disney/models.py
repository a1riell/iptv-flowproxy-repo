"""
Modelos de datos inmutables y tipados para el proveedor Disney+ (BAMGrid).
Sin dependencias de Kodi ni bibliotecas externas.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class DrmEndpointKind(str, Enum):
    EVENT = "event"
    LINEAR = "linear"


class AuthState(str, Enum):
    UNCONFIGURED = "UNCONFIGURED"
    READY = "READY"
    REFRESHING = "REFRESHING"
    REAUTH_REQUIRED = "REAUTH_REQUIRED"
    TEMPORARILY_UNAVAILABLE = "TEMPORARILY_UNAVAILABLE"


class AuthError(Exception):
    """Excepción base para errores de autenticación Disney."""
    pass


class ReauthRequiredError(AuthError):
    """Indica que el refresh token es inválido o expiró; se requiere reautenticación."""
    pass


class AuthNetworkError(AuthError):
    """Error transitorio de red durante el refresco."""
    pass


class AuthResponseInvalidError(AuthError):
    """Respuesta de orquestación/BAMGrid inválida o incompleta."""
    pass


@dataclass(frozen=True)
class AccessTokenSnapshot:
    """Snapshot inmutable de un token de acceso vigente con su generación y contexto."""
    token: str
    token_generation: int
    expires_at: float
    session_epoch: int
    contract_name: str = "chrome_web"

    def __repr__(self) -> str:
        return (
            f"AccessTokenSnapshot(token=***, token_generation={self.token_generation}, "
            f"expires_at={self.expires_at:.1f}, session_epoch={self.session_epoch}, contract_name='{self.contract_name}')"
        )


@dataclass(frozen=True)
class PlaybackContext:
    """Snapshot inmutable de una sesión de reproducción activa."""
    manifest_url: str
    rights_context: str
    drm_endpoint_kind: DrmEndpointKind
    url_expiration: float
    rights_expiration: float
    created_at: float

    @property
    def is_url_expired(self) -> bool:
        import time
        return time.time() >= self.url_expiration

    @property
    def is_rights_expired(self) -> bool:
        import time
        return time.time() >= self.rights_expiration


@dataclass(frozen=True)
class BindingRecord:
    """
    Registro completo de identidad, referencia y contexto de una señal/evento.
    identity_generation incrementa de manera monotónica ante cualquier cambio de
    resource_id, profile_id, contract_name o session_epoch.
    """
    binding: str
    resource_ref: str
    resource_id: str
    content_type: str
    contract_name: str = "chrome_web"
    profile_id: str = "default"
    session_epoch: int = 1
    identity_generation: int = 1
    playback_context: Optional[PlaybackContext] = None
    last_resolved_at: float = 0.0

    def with_playback_context(self, context: PlaybackContext, resolved_at: float) -> BindingRecord:
        """Retorna una nueva instancia inmutable con el contexto actualizado preservando la generación."""
        return BindingRecord(
            binding=self.binding,
            resource_ref=self.resource_ref,
            resource_id=self.resource_id,
            content_type=self.content_type,
            contract_name=self.contract_name,
            profile_id=self.profile_id,
            session_epoch=self.session_epoch,
            identity_generation=self.identity_generation,
            playback_context=context,
            last_resolved_at=resolved_at,
        )
