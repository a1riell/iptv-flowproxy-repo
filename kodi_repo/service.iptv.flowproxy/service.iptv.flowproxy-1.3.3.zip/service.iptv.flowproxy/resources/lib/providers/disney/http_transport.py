"""
Capa de transporte HTTP para Disney+ con soporte para inyección y tests unitarios.
"""
from __future__ import annotations

import http.client
import logging
import ssl
import urllib.parse
from typing import Dict, Optional, Protocol, Tuple

logger = logging.getLogger("flowproxy_disney_transport")


class HttpTransportError(Exception):
    """Error base de transporte HTTP."""
    pass


class UpstreamHttpError(HttpTransportError):
    def __init__(self, status: int, body: bytes, headers: Dict[str, str]):
        super().__init__(f"Upstream HTTP error {status}")
        self.status = status
        self.body = body
        self.headers = headers


class HttpTransport(Protocol):
    def request(
        self,
        method: str,
        url: str,
        headers: Dict[str, str],
        body: Optional[bytes] = None,
        timeout: float = 12.0,
    ) -> Tuple[int, bytes, Dict[str, str]]:
        ...


class DefaultHttpTransport:
    def __init__(self, ssl_context: Optional[ssl.SSLContext] = None) -> None:
        if ssl_context is None:
            self._ssl_ctx = ssl.create_default_context()
        else:
            self._ssl_ctx = ssl_context

    def request(
        self,
        method: str,
        url: str,
        headers: Dict[str, str],
        body: Optional[bytes] = None,
        timeout: float = 12.0,
    ) -> Tuple[int, bytes, Dict[str, str]]:
        parsed = urllib.parse.urlsplit(url)
        path = parsed.path
        if parsed.query:
            path = f"{path}?{parsed.query}"

        # Diccionario nuevo para no mutar el del llamador
        req_headers = dict(headers)
        if body is not None and "Content-Length" not in req_headers:
            req_headers["Content-Length"] = str(len(body))

        if parsed.scheme == "https":
            conn = http.client.HTTPSConnection(parsed.netloc, timeout=timeout, context=self._ssl_ctx)
        else:
            conn = http.client.HTTPConnection(parsed.netloc, timeout=timeout)

        try:
            conn.request(method, path, body=body, headers=req_headers)
            resp = conn.getresponse()
            status = resp.status
            # Limitar tamaño máximo para evitar agotamiento de memoria por respuestas anómalas
            max_bytes = 10 * 1024 * 1024
            resp_body = resp.read(max_bytes + 1)
            if len(resp_body) > max_bytes:
                raise HttpTransportError(f"Respuesta upstream desde {url} excede el límite de 10 MB")
            resp_headers = {k.lower(): v for k, v in resp.getheaders()}
            return status, resp_body, resp_headers
        except Exception as e:
            logger.error("Error en conexión hacia %s: %s", url, e)
            raise HttpTransportError(f"Fallo de conexión hacia {url}: {e}") from e
        finally:
            conn.close()
