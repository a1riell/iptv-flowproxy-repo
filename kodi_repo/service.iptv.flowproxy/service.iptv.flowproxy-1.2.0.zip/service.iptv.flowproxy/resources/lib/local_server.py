"""
Servidor HTTP Local Zero-CPU para redirecciones de Flow en Kodi.
"""

from __future__ import annotations

import http.server
import json
import logging
import os
import re
import socketserver
import ssl
import urllib.parse
import xml.etree.ElementTree as ET
from urllib.parse import urljoin
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, Union

from .flow_resolver import FlowSessionResolver
from .dgo_resolver import DgoSessionResolver

logger = logging.getLogger("flowproxy_server")

USER_AGENT = "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 Kodi/21"

MAPPINGS_FILE = Path(__file__).resolve().parent / "slug_mappings.json"
SLUG_MAPPINGS: Dict[str, str] = {}

if MAPPINGS_FILE.is_file():
    try:
        SLUG_MAPPINGS = json.loads(MAPPINGS_FILE.read_text(encoding="utf-8"))
    except Exception as e:
        logger.warning(f"No se pudo cargar slug_mappings.json: {e}")



def extract_seed_rel(entry: Any) -> Tuple[Optional[str], Optional[str]]:
    """Extrae y valida la ruta relativa del seed desde una entrada de mapping.

    Retorna (seed_rel, error_reason). Si es válida, error_reason es None.
    """
    if entry is None:
        return None, "slug_not_found"

    if isinstance(entry, dict):
        seed = entry.get("seed_rel")
    elif isinstance(entry, str):
        seed = entry
    else:
        return None, "invalid_type"

    if not isinstance(seed, str) or not seed.strip():
        return None, "empty_seed_rel"

    seed = seed.strip()
    if ".." in seed:
        return None, "path_traversal"
    if seed.startswith("/"):
        return None, "absolute_path"
    if "://" in seed:
        return None, "external_host"

    return seed, None


def strip_content_protection(mpd_bytes: bytes, remote_url: str) -> bytes:
    """Quita el <ContentProtection> y hace absolutas las URLs del MPD.

    Varios CDN (PlayMe) DECLARAN Widevine + FairPlay + cenc en el manifiesto pero sirven
    el video EN CLARO. Si ese manifiesto llega tal cual a InputStream Adaptive, el addon
    de Kodi intenta inicializar DRM, no encuentra licencia ni clave, y el canal FALLA
    aunque el stream funcione. Se elimina la declaración de cifrado y se reescribe el
    BaseURL para que los segmentos se pidan al CDN real y no a 127.0.0.1.
    """
    try:
        root = ET.fromstring(mpd_bytes)
    except ET.ParseError:
        return mpd_bytes
    for parent in root.iter():
        for child in list(parent):
            if child.tag.rsplit("}", 1)[-1] == "ContentProtection":
                parent.remove(child)
    namespace_uri = "urn:mpeg:dash:schema:mpd:2011"
    namespace = f"{{{namespace_uri}}}"
    has_base_url = False
    for elem in root.iter():
        if elem.tag.rsplit("}", 1)[-1] != "BaseURL":
            continue
        has_base_url = True
        if elem.text and elem.text.strip():
            elem.text = urljoin(remote_url, elem.text.strip())
    if not has_base_url:
        base = ET.Element(f"{namespace}BaseURL")
        base.text = urljoin(remote_url, ".")
        root.insert(0, base)
    # ElementTree usa el prefijo artificial ``ns0`` si no se registra el
    # namespace por defecto. Aunque XML válido, InputStream Adaptive/Kodi puede
    # rechazar ese MPD DASH. Mantener el namespace DASH por defecto conserva el
    # formato que entrega el CDN.
    ET.register_namespace("", namespace_uri)
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def fetch_clear_manifest(url: str) -> Tuple[bytes, str]:
    """Descarga el manifiesto siguiendo redirecciones y devuelve (cuerpo, url_final)."""
    ctx = ssl.create_default_context()
    # Mismo criterio que el resolver: Kodi en Android no siempre tiene el almacén de CAs.
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=15, context=ctx) as response:
        return response.read(), response.geturl()


class FlowProxyHandler(http.server.BaseHTTPRequestHandler):
    resolver = FlowSessionResolver()
    dgo_resolver = DgoSessionResolver()

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "authorization, content-type, range")
        self.end_headers()

    def do_POST(self) -> None:
        path = urllib.parse.unquote(self.path)
        if "/dgo/license/" in path:
            raw_id = path.split("/dgo/license/")[-1].split("?")[0].strip()
            if not raw_id:
                self.send_error(400, "Falta contentId en la ruta de licencia")
                return

            try:
                length = int(self.headers.get("Content-Length", 0))
            except (ValueError, TypeError):
                length = 0

            challenge_data = self.rfile.read(length) if length > 0 else b""
            try:
                status, license_bytes, _ = self.dgo_resolver.proxy_license(raw_id, challenge_data)
                self.send_response(status)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "no-cache, no-store")
                self.send_header("Content-Length", str(len(license_bytes)))
                self.end_headers()
                self.wfile.write(license_bytes)
            except Exception as e:
                logger.error("Error en proxy de licencia DGO %s: %s", raw_id, e)
                self.send_error(503, f"Error proxy licencia DGO: {e}")
        else:
            self.send_error(404, "Endpoint POST no reconocido")

    def do_GET(self) -> None:
        path = urllib.parse.unquote(self.path)
        if "/dgo/live/" in path:
            raw_slug = path.split("/dgo/live/")[-1]
            slug = re.sub(r"\.(mpd|m3u8)$", "", raw_slug, flags=re.IGNORECASE).strip().lower()
            try:
                manifest_bytes = self.dgo_resolver.get_manifest(slug)
                self.send_response(200)
                self.send_header("Content-Type", "application/dash+xml")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "no-cache, no-store")
                self.send_header("Content-Length", str(len(manifest_bytes)))
                self.end_headers()
                self.wfile.write(manifest_bytes)
            except ValueError as e:
                self.send_error(404, f"Canal DGO no encontrado: {slug}")
            except Exception as e:
                logger.error("Error resolviendo canal DGO %s: %s", slug, e)
                self.send_error(503, f"Error resolviendo canal DGO {slug}: {e}")
        elif "/kodi/clear/" in path:
            # Manifiesto saneado: se sirve SIN la declaración de DRM falsa.
            raw_slug = path.split("/kodi/clear/")[-1]
            slug = re.sub(r"\.(mpd|m3u8)$", "", raw_slug, flags=re.IGNORECASE).strip().lower()
            entry = SLUG_MAPPINGS.get(f"clear:{slug}")
            if not isinstance(entry, dict) or not entry.get("clear_url"):
                self.send_error(404, f"Manifiesto claro no encontrado: {slug}")
                return
            try:
                body, final_url = fetch_clear_manifest(str(entry["clear_url"]))
                saneado = strip_content_protection(body, final_url)
            except Exception as e:  # noqa: BLE001
                self.send_error(503, f"Error obteniendo manifiesto {slug}: {e}")
                return
            self.send_response(200)
            self.send_header("Content-Type", "application/dash+xml")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Cache-Control", "no-cache, no-store")
            self.send_header("Content-Length", str(len(saneado)))
            self.end_headers()
            self.wfile.write(saneado)
        elif "/kodi/live/" in path:
            raw_slug = path.split("/kodi/live/")[-1]
            slug = re.sub(r"\.(mpd|m3u8)$", "", raw_slug, flags=re.IGNORECASE).strip().lower()

            entry = SLUG_MAPPINGS.get(slug)
            target_rel, err = extract_seed_rel(entry)

            if err == "slug_not_found":
                self.send_error(404, f"Canal no encontrado: {slug}")
                return
            elif err:
                self.send_error(400, f"Ruta de seed inválida para canal {slug}: {err}")
                return

            try:
                target_url = self.resolver.resolve_stream(slug, target_rel)

                self.send_response(302)
                self.send_header("Location", target_url)
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "no-cache, no-store")
                self.end_headers()
            except Exception as e:
                self.send_error(503, f"Error resolviendo canal {slug}: {e}")
        elif path == "/status" or path == "/health":
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"status": "ok", "service": "service.iptv.flowproxy"}')
        else:
            self.send_error(404, "Endpoint no reconocido")

    def log_message(self, format: str, *args) -> None:
        pass


class ThreadedHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True
