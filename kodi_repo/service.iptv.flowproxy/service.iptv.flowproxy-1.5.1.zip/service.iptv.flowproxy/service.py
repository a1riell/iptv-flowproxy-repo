"""
Entrypoint de servicio para Kodi: service.iptv.flowproxy
"""

from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import sys
import threading
import time
from typing import Any, Dict, List, Optional, Tuple
import xml.etree.ElementTree as ET

try:
    import xbmc
    import xbmcaddon
    import xbmcvfs
    IN_KODI = True
except ImportError:
    IN_KODI = False


UPDATES_DIR = Path("/storage/emulated/0/Download")
UPDATE_ZIP_NAME = "update_flowproxy.zip"
#: Tope de seguridad para no descomprimir un ZIP corrupto/malicioso.
MAX_UPDATE_UNCOMPRESSED_BYTES = 80 * 1024 * 1024
REQUIRED_UPDATE_ENTRIES = ("addon.xml", "service.py")


def _log_update(message: str, level: str = "info") -> None:
    prefix = "[IPTV FlowProxy] "
    if IN_KODI:
        xbmc.log(prefix + message, level=xbmc.LOGINFO if level == "info" else xbmc.LOGWARNING)
    else:
        print(prefix + message)


def _safe_zip_members(zf, staging_dir: Path) -> Optional[str]:
    """Extrae los miembros del ZIP validando rutas y devuelve el prefijo raíz.

    Nunca usa ``extractall``: cada destino se calcula a partir del nombre relativo,
    se rechazan rutas absolutas, ``..`` y symlinks (zip-slip), y se respeta un tope
    de tamaño descomprimido.
    """
    import zipfile

    members = [info for info in zf.infolist() if not info.is_dir()]
    if not members:
        return None

    total = 0
    for info in members:
        name = info.filename
        if name.startswith("/") or ".." in Path(name).parts or (
            (info.external_attr >> 16) & 0o170000
        ) == 0o120000:
            return None
        total += max(0, info.file_size)
        if total > MAX_UPDATE_UNCOMPRESSED_BYTES:
            return None

    # Prefijo común: el ZIP oficial trae todo dentro de service.iptv.flowproxy/,
    # pero se acepta también un ZIP con los archivos en la raíz.
    names = [info.filename for info in members]
    prefix = ""
    first_parts = {name.split("/", 1)[0] for name in names}
    if len(first_parts) == 1:
        candidate = first_parts.pop()
        if all(name.startswith(candidate + "/") for name in names) and any(
            name == f"{candidate}/addon.xml" for name in names
        ):
            prefix = candidate + "/"

    for info in members:
        relative = info.filename[len(prefix):] if prefix else info.filename
        if not relative:
            continue
        destination = (staging_dir / relative).resolve()
        if not str(destination).startswith(str(staging_dir.resolve()) + os.sep):
            return None
        destination.parent.mkdir(parents=True, exist_ok=True)
        with zf.open(info) as source, open(destination, "wb") as target:
            shutil.copyfileobj(source, target)
    return prefix


def _zip_addon_version(staging_dir: Path) -> Optional[str]:
    try:
        root = ET.parse(staging_dir / "addon.xml").getroot()
        return (root.get("version") or "").strip() or None
    except Exception:
        return None


def _check_local_update() -> None:
    """Aplica una actualización local desde /Download de forma validada y atómica.

    Flujo: validar ZIP → extraer a un directorio de staging → comprobar versión →
    intercambiar el directorio completo. Nunca se descomprime encima del add-on en
    uso, así una descarga cortada no puede dejar la instalación a medias.
    """
    import zipfile

    update_zip = UPDATES_DIR / UPDATE_ZIP_NAME
    if not update_zip.is_file():
        return

    target_dir = Path(__file__).resolve().parent
    staging_dir = target_dir.parent / f".{target_dir.name}.staging-{os.getpid()}"
    backup_dir = target_dir.parent / f".{target_dir.name}.backup-{int(time.time())}"

    try:
        with zipfile.ZipFile(update_zip, "r") as zf:
            if zf.testzip() is not None:
                _log_update(
                    "Auto-actualización descartada: el ZIP está corrupto", level="warning"
                )
                return
            if staging_dir.exists():
                shutil.rmtree(staging_dir, ignore_errors=True)
            staging_dir.mkdir(parents=True)
            if _safe_zip_members(zf, staging_dir) is None:
                _log_update(
                    "Auto-actualización descartada: el ZIP contiene rutas no permitidas",
                    level="warning",
                )
                return

        missing = [name for name in REQUIRED_UPDATE_ENTRIES if not (staging_dir / name).is_file()]
        if missing:
            _log_update(
                f"Auto-actualización descartada: faltan archivos obligatorios ({', '.join(missing)})",
                level="warning",
            )
            return

        new_version = _zip_addon_version(staging_dir)
        if not new_version:
            _log_update(
                "Auto-actualización descartada: addon.xml inválido o sin versión",
                level="warning",
            )
            return

        try:
            current_version = (xbmcaddon.Addon().getAddonInfo("version") if IN_KODI else "")
        except Exception:
            current_version = ""
        if not current_version:
            try:
                current_version = (
                    ET.parse(target_dir / "addon.xml").getroot().get("version") or ""
                )
            except Exception:
                current_version = ""

        if current_version and _parse_version_tuple(new_version) < _parse_version_tuple(
            current_version
        ):
            _log_update(
                f"Auto-actualización descartada: el ZIP trae {new_version} y ya hay {current_version}",
                level="warning",
            )
            return

        # Descartar caché de bytecode del árbol anterior.
        for cache_dir in staging_dir.rglob("__pycache__"):
            shutil.rmtree(cache_dir, ignore_errors=True)

        swapped = False
        try:
            os.replace(target_dir, backup_dir)
            try:
                os.replace(staging_dir, target_dir)
                swapped = True
            finally:
                if not swapped:
                    os.replace(backup_dir, target_dir)
        except OSError as swap_error:
            _log_update(
                f"No se pudo intercambiar el directorio del add-on, se deja la versión actual: {swap_error}",
                level="warning",
            )
            return

        shutil.rmtree(backup_dir, ignore_errors=True)
        update_zip.unlink(missing_ok=True)
        _log_update(
            f"Auto-actualización local aplicada: {current_version or '?'} → {new_version}. "
            "Reiniciar Kodi para cargar el código nuevo."
        )
    except Exception as exc:
        _log_update(f"Error aplicando auto-actualización local: {exc}", level="warning")
    finally:
        shutil.rmtree(staging_dir, ignore_errors=True)


def _parse_version_tuple(v_str: str) -> tuple[int, ...]:
    import re
    nums = [int(n) for n in re.findall(r"\d+", v_str or "")]
    return tuple(nums) if nums else (0,)


_check_local_update()


def _ensure_binary_dependencies() -> None:
    """Garantiza la presencia de inputstream.adaptive y pvr.iptvsimple en Android de forma 100% autónoma."""
    if not IN_KODI:
        return

    import zipfile
    import urllib.request
    import platform

    addons_dir = Path(xbmcvfs.translatePath("special://home/addons"))
    addons_dir.mkdir(parents=True, exist_ok=True)

    arch_map = {
        "arm64": "android-aarch64",
        "aarch64": "android-aarch64",
        "armv7": "android-armv7",
        "arm": "android-armv7",
    }
    machine = platform.machine().lower()
    arch = "android-aarch64"
    for k, v in arch_map.items():
        if k in machine:
            arch = v
            break

    deps = [
        {
            "id": "inputstream.adaptive",
            "url": f"https://mirrors.kodi.tv/addons/omega/inputstream.adaptive+{arch}/inputstream.adaptive-21.5.25.zip",
            "fallback_url": "https://mirrors.dotsrc.org/kodi/addons/omega/inputstream.adaptive+android-aarch64/inputstream.adaptive-21.5.25.zip",
            "local_globs": ["inputstream.adaptive*.zip"],
        },
        {
            "id": "pvr.iptvsimple",
            "url": f"https://mirrors.kodi.tv/addons/omega/pvr.iptvsimple+{arch}/pvr.iptvsimple-21.11.0.zip",
            "fallback_url": "https://mirrors.dotsrc.org/kodi/addons/omega/pvr.iptvsimple+android-aarch64/pvr.iptvsimple-21.11.0.zip",
            "local_globs": ["pvr.iptvsimple*.zip"],
        },
    ]

    installed_any = False
    download_dir = Path("/storage/emulated/0/Download")

    for dep in deps:
        addon_target = addons_dir / dep["id"]
        if addon_target.is_dir() and (addon_target / "addon.xml").is_file():
            _set_kodi_addon_enabled(dep["id"], True)
            continue

        xbmc.log(f"[IPTV FlowProxy] Instalando dependencia requerida {dep['id']}...", level=xbmc.LOGINFO)
        zip_source = None

        # 1. Buscar en Download local
        if download_dir.is_dir():
            for pattern in dep["local_globs"]:
                matches = list(download_dir.glob(pattern))
                if matches and matches[0].is_file() and matches[0].stat().st_size > 50000:
                    zip_source = matches[0]
                    break

        # 2. Si no está en Download, descargar desde mirror oficial
        if not zip_source:
            temp_zip = addons_dir / f".tmp_{dep['id']}.zip"
            for test_url in [dep["url"], dep["fallback_url"]]:
                try:
                    req = urllib.request.Request(
                        test_url,
                        headers={"User-Agent": "Kodi/21.0 (Android)"}
                    )
                    with urllib.request.urlopen(req, timeout=15) as resp:
                        if resp.status == 200:
                            temp_zip.write_bytes(resp.read())
                            zip_source = temp_zip
                            break
                except Exception as dl_err:
                    xbmc.log(f"[IPTV FlowProxy] Aviso descargando {dep['id']} desde {test_url}: {dl_err}", level=xbmc.LOGWARNING)

        # 3. Descomprimir en addons_dir
        if zip_source and zip_source.is_file():
            try:
                with zipfile.ZipFile(str(zip_source), "r") as zf:
                    zf.extractall(str(addons_dir))
                installed_any = True
                xbmc.log(f"[IPTV FlowProxy] Dependencia {dep['id']} instalada correctamente desde {zip_source.name}", level=xbmc.LOGINFO)
            except Exception as unz_err:
                xbmc.log(f"[IPTV FlowProxy] Error descomprimiendo {dep['id']}: {unz_err}", level=xbmc.LOGERROR)
            finally:
                if zip_source.name.startswith(".tmp_"):
                    try:
                        zip_source.unlink()
                    except OSError:
                        pass

    if installed_any:
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.sleep(1000)
        for dep in deps:
            _set_kodi_addon_enabled(dep["id"], True)
        xbmc.log("[IPTV FlowProxy] Dependencias binarias habilitadas automáticamente", level=xbmc.LOGINFO)


def _check_kodi_version_and_isa() -> bool:
    """Valida requisitos estrictos de runtime: Kodi 21 (Omega) e InputStream Adaptive >= 21.5.0."""
    if not IN_KODI:
        return True
    try:
        import xbmc
        import xbmcaddon
        import xbmcgui
        build_str = xbmc.getInfoLabel("System.BuildVersion")
        major_str = build_str.split(".")[0] if build_str else ""
        major_version = int(major_str) if major_str.isdigit() else 0
        if major_version < 21:
            try:
                xbmcgui.Dialog().notification(
                    "IPTV FlowProxy",
                    f"Requiere Kodi 21 (Omega). Detectado: {build_str or 'desconocido'}",
                    xbmcgui.NOTIFICATION_ERROR,
                    5000,
                )
            except Exception:
                pass
            xbmc.log(
                f"[IPTV FlowProxy] Incompatible: requiere Kodi 21 (Omega) o superior (detectado: {build_str})",
                level=xbmc.LOGERROR,
            )
            return False

        try:
            _set_kodi_addon_enabled("inputstream.adaptive", True)
            try:
                isa_addon = xbmcaddon.Addon("inputstream.adaptive")
            except Exception:
                if IN_KODI:
                    xbmc.sleep(250)
                isa_addon = xbmcaddon.Addon("inputstream.adaptive")
            isa_version_str = isa_addon.getAddonInfo("version") or ""
            isa_tuple = _parse_version_tuple(isa_version_str)
            if isa_tuple < (21, 5, 0):
                try:
                    xbmcgui.Dialog().notification(
                        "IPTV FlowProxy",
                        f"Requiere InputStream Adaptive 21.5.0+. Detectado: {isa_version_str or 'desconocido'}",
                        xbmcgui.NOTIFICATION_ERROR,
                        5000,
                    )
                except Exception:
                    pass
                xbmc.log(
                    f"[IPTV FlowProxy] Incompatible: requiere InputStream Adaptive 21.5.0+ (detectado: {isa_version_str})",
                    level=xbmc.LOGERROR,
                )
                return False
            xbmc.log(
                f"[IPTV FlowProxy] Kodi {major_version} activo con InputStream Adaptive {isa_version_str}",
                level=xbmc.LOGINFO,
            )
        except Exception as isa_err:
            xbmc.log(
                f"[IPTV FlowProxy] Error: inputstream.adaptive no se encuentra disponible ({isa_err})",
                level=xbmc.LOGERROR,
            )
            return False
    except Exception as exc:
        xbmc.log(f"[IPTV FlowProxy] Error crítico en guardas de compatibilidad: {exc}", level=xbmc.LOGERROR)
        return False
    return True


def get_disney_quality_profile() -> int:
    """Retorna el perfil de calidad Disney+ configurado en el add-on (0..3)."""
    if IN_KODI:
        try:
            import xbmcaddon
            addon = xbmcaddon.Addon()
            val = addon.getSetting("disney_quality_profile")
            if val is not None and str(val).strip().isdigit():
                return int(val)
        except Exception:
            pass
    return 0


def register_m3u_source(name: str, url: str, profile_dir: Optional[Path] = None) -> None:
    from resources.lib.local_server import register_m3u_source as _reg
    _reg(name, url, profile_dir=profile_dir)


def get_m3u_source(name: str, profile_dir: Optional[Path] = None) -> Optional[str]:
    from resources.lib.local_server import get_m3u_source as _get
    return _get(name, profile_dir=profile_dir)


def get_m3u_slug_for_url(url: str) -> str:
    from resources.lib.local_server import get_m3u_slug_for_url as _slug
    return _slug(url)


DEFAULT_PORT = 18080


def get_configured_port() -> int:
    if IN_KODI:
        try:
            addon = xbmcaddon.Addon()
            val = addon.getSetting("proxy_port")
            if val:
                return int(val)
        except Exception:
            pass
    return DEFAULT_PORT


_current_httpd = None


#: Ajustes de Kodi que el add-on considera canónicos mientras corre.
#: El provisioner de appliance debe respetarlos (ver su
#: ``PROXY_OWNED_GUISETTINGS``) para que no haya dos dueños escribiendo valores
#: distintos en el mismo ``guisettings.xml``.
KODI_SETTINGS_POLICY: Dict[str, Any] = {
    "pvrmanager.backendchannelorder": True,
    "epg.pastdaystodisplay": 1,
    "epg.futuredaystodisplay": 2,
    "epg.epgupdate": 15,
    "epg.hidenoinfoavailable": False,
    "lookandfeel.enablerssfeeds": False,
}


def ensure_advancedsettings_optimized(profile_dir: Path) -> bool:
    """Genera o actualiza userdata/advancedsettings.xml para Kodi 21 Omega en Android TV."""
    adv_file = profile_dir / "advancedsettings.xml"
    changed = False
    try:
        if adv_file.is_file():
            try:
                tree = ET.parse(adv_file)
                root = tree.getroot()
            except Exception:
                root = ET.Element("advancedsettings", attrib={"version": "1.0"})
                tree = ET.ElementTree(root)
                changed = True
        else:
            root = ET.Element("advancedsettings", attrib={"version": "1.0"})
            tree = ET.ElementTree(root)
            changed = True

        # dirty regions = 3 (renderizado por cambio de viewport en Android Mali)
        gui = root.find("gui")
        if gui is None:
            gui = ET.SubElement(root, "gui")
            changed = True
        algo = gui.find("algorithmdirtyregions")
        if algo is None:
            algo = ET.SubElement(gui, "algorithmdirtyregions")
            algo.text = "3"
            changed = True
        elif (algo.text or "").strip() != "3":
            algo.text = "3"
            changed = True

        # imageres y fanartres = 540 (reduce un 50% consumo RAM de texturas)
        for tag in ("imageres", "fanartres"):
            elem = root.find(tag)
            if elem is None:
                elem = ET.SubElement(root, tag)
                elem.text = "540"
                changed = True
            elif (elem.text or "").strip() != "540":
                elem.text = "540"
                changed = True

        # videoscanner ignoreerrors = true
        vs = root.find("videoscanner")
        if vs is None:
            vs = ET.SubElement(root, "videoscanner")
            changed = True
        ie = vs.find("ignoreerrors")
        if ie is None:
            ie = ET.SubElement(vs, "ignoreerrors")
            ie.text = "true"
            changed = True
        elif (ie.text or "").strip().lower() != "true":
            ie.text = "true"
            changed = True

        # Deshabilitar background update de librerias de medios
        for lib_tag in ("musiclibrary", "videolibrary"):
            lib = root.find(lib_tag)
            if lib is None:
                lib = ET.SubElement(root, lib_tag)
                changed = True
            bg = lib.find("backgroundupdate")
            if bg is None:
                bg = ET.SubElement(lib, "backgroundupdate")
                bg.text = "false"
                changed = True
            elif (bg.text or "").strip().lower() != "false":
                bg.text = "false"
                changed = True

        # epg tuning: actualización ágil de tags y reintentos ante desconexión
        epg = root.find("epg")
        if epg is None:
            epg = ET.SubElement(root, "epg")
            changed = True
        epg_tags = {
            "cleanupinterval": "86400",
            "updatecheckinterval": "300",
            "updateemptytagsinterval": "60",
            "retryinterruptedupdateinterval": "30",
        }
        for etag, evalue in epg_tags.items():
            node = epg.find(etag)
            if node is None:
                node = ET.SubElement(epg, etag)
                node.text = evalue
                changed = True
            elif (node.text or "").strip() != evalue:
                node.text = evalue
                changed = True

        if changed:
            temp_file = adv_file.with_name(f".adv_settings.{os.getpid()}.tmp")
            tree.write(temp_file, encoding="utf-8", xml_declaration=True)
            temp_file.replace(adv_file)
            if IN_KODI:
                xbmc.log("[IPTV FlowProxy] advancedsettings.xml optimizado para Kodi 21 con EPG resiliente", level=xbmc.LOGINFO)
            return True
    except Exception as exc:
        if IN_KODI:
            xbmc.log(f"[IPTV FlowProxy] Aviso configurando advancedsettings.xml: {exc}", level=xbmc.LOGWARNING)
    return False


def ensure_guisettings_optimized(profile_dir: Path) -> bool:
    """Aplica los ajustes de PVR y EPG que el add-on considera canónicos.

    Contrato de propiedad (una sola fuente de verdad):

    * Mientras Kodi está corriendo, el add-on es el dueño de estos ajustes y los
      aplica **sólo** por JSON-RPC. Kodi los persiste en ``guisettings.xml`` al
      cerrarse, así que escribir el XML a mano mientras corre es redundante y
      peligroso: Kodi tiene esa configuración en memoria y la reescribe encima.
    * Con Kodi detenido (aprovisionamiento/CLI) sí se parchea el XML, porque no
      hay proceso que vaya a pisarlo.
    * El provisioner de appliance NO debe escribir estos valores: los deja al
      add-on. Ver ``KODI_SETTINGS_POLICY``.
    """
    # 1. Aplicar en runtime vía JSON-RPC Settings.SetSettingValue si estamos en Kodi
    if IN_KODI:
        for sid, val in KODI_SETTINGS_POLICY.items():
            try:
                req = json.dumps({
                    "jsonrpc": "2.0",
                    "id": f"set_{sid}",
                    "method": "Settings.SetSettingValue",
                    "params": {"setting": sid, "value": val},
                })
                xbmc.executeJSONRPC(req)
            except Exception:
                pass
        # Kodi persiste estos valores al salir: no se toca el XML en caliente.
        return False

    # 2. Parchear guisettings.xml en disco sólo con Kodi detenido
    gui_file = profile_dir / "guisettings.xml"
    if not gui_file.is_file():
        return False
    try:
        tree = ET.parse(gui_file)
        root = tree.getroot()
        changed = False

        def _render(value: Any) -> str:
            if isinstance(value, bool):
                return "true" if value else "false"
            return str(value)

        settings_map = {sid: _render(val) for sid, val in KODI_SETTINGS_POLICY.items()}
        existing = {node.get("id"): node for node in root.findall(".//setting") if node.get("id")}
        for sid, val in settings_map.items():
            if sid in existing:
                elem = existing[sid]
                if (elem.text or "").strip().lower() != val.lower():
                    elem.text = val
                    changed = True
                if elem.attrib.get("default") == "true":
                    del elem.attrib["default"]
                    changed = True
            else:
                elem = ET.SubElement(root, "setting", id=sid)
                elem.text = val
                changed = True
        if changed:
            temp_file = gui_file.with_name(f".gui_settings.{os.getpid()}.tmp")
            tree.write(temp_file, encoding="utf-8", xml_declaration=True)
            temp_file.replace(gui_file)
            return True
    except Exception as exc:
        if IN_KODI:
            xbmc.log(f"[IPTV FlowProxy] Aviso parcheando guisettings.xml: {exc}", level=xbmc.LOGDEBUG)
    return False


def reset_epg_last_scan_if_stale(profile_dir: Path) -> bool:
    """Resetea lastepgscan para los canales sin eventos EPG vigentes, forzando su carga inmediata."""
    try:
        import sqlite3
        db_dir = profile_dir / "Database"
        if not db_dir.is_dir():
            return False
        reset_any = False
        now_ts = int(time.time())
        for db_file in db_dir.glob("Epg*.db"):
            try:
                conn = sqlite3.connect(str(db_file), timeout=4.0)
                with conn:
                    cur = conn.cursor()
                    cur.execute("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='epgtags';")
                    if cur.fetchone()[0] == 0:
                        continue
                    cur.execute("SELECT count(DISTINCT idEpg) FROM epgtags WHERE iEndTime > ?;", (now_ts,))
                    channels_with_epg = cur.fetchone()[0]
                    # Si menos de 150 canales tienen guía vigente (en una grilla de >400 canales),
                    # limpiar las marcas de último escaneo para que Kodi consulte a IPTV Simple de inmediato
                    if channels_with_epg < 150:
                        cur.execute(
                            "DELETE FROM lastepgscan WHERE idEpg NOT IN (SELECT DISTINCT idEpg FROM epgtags WHERE iEndTime > ?);",
                            (now_ts,),
                        )
                        reset_any = True
                conn.close()
            except Exception as db_err:
                if IN_KODI:
                    xbmc.log(f"[IPTV FlowProxy] Aviso comprobando EPG db: {db_err}", level=xbmc.LOGDEBUG)
        return reset_any
    except Exception:
        return False


def update_iptv_simple_refresh_settings(
    profile_dir: Path, interval_minutes: int = 0, epg_port: int = DEFAULT_PORT
) -> int:
    """Configura todas las instancias IPTV Simple en modo Lean (m3uRefreshMode=0)
    para evitar bloqueos de mutex en Android TV, consumiendo la guía EPG servida por el proxy local.

    Propiedad de ajustes (evita que dos procesos escriban lo mismo):

    * El add-on es dueño del **contenido** de la instancia: URLs de M3U/EPG
      locales, cachés, ISA y habilitación.
    * Si el appliance fijó ``m3uRefreshMode=0`` explícito (sin ``default="true"``),
      se respeta esa cadencia manual y no se toca el intervalo.

    Retorna cuántos archivos cambiaron. El reemplazo es atómico para no dejar
    una configuración XML parcial si Android termina Kodi durante la escritura.
    """
    settings_dir = profile_dir / "addon_data" / "pvr.iptvsimple"
    if not settings_dir.is_dir():
        return 0

    desired_epg_url = f"http://127.0.0.1:{epg_port}/epg.xml.gz"

    changed_files = 0
    candidate_files = list(sorted(settings_dir.glob("instance-settings-*.xml")))
    legacy_settings = settings_dir / "settings.xml"
    if legacy_settings.is_file() and legacy_settings not in candidate_files:
        candidate_files.append(legacy_settings)

    for settings_path in candidate_files:
        try:
            tree = ET.parse(settings_path)
            root = tree.getroot()
            settings = {
                node.get("id"): node
                for node in root.findall(".//setting")
                if node.get("id")
            }
            refresh_mode = settings.get("m3uRefreshMode")
            refresh_interval = settings.get("m3uRefreshIntervalMins")
            epg_path_type = settings.get("epgPathType")
            epg_url = settings.get("epgUrl")

            changed = False
            is_lean = interval_minutes == 0
            desired_mode = "0" if is_lean else "1"
            desired_interval = "10" if is_lean else str(interval_minutes)
            # Si otro dueño (appliance) fijó modo manual explícito, se respeta el
            # refresco de la lista, pero el resto del archivo (EPG, M3U, caché) sí
            # se normaliza contra el proxy local. Antes se hacía ``continue`` y la
            # instancia quedaba apuntando al EPG/M3U remoto para siempre.
            respect_manual_refresh = False

            if refresh_mode is not None:
                has_default = refresh_mode.attrib.get("default") == "true"
                cur_mode = (refresh_mode.text or "").strip()
                if cur_mode == "0" and not has_default and not is_lean:
                    respect_manual_refresh = True
                else:
                    if cur_mode != desired_mode:
                        refresh_mode.text = desired_mode
                        changed = True
                    if refresh_mode.attrib.pop("default", None) is not None:
                        changed = True
            elif settings:
                refresh_mode = ET.SubElement(root, "setting", id="m3uRefreshMode")
                refresh_mode.text = desired_mode
                changed = True

            if not is_lean and not respect_manual_refresh:
                if refresh_interval is not None:
                    if (refresh_interval.text or "").strip() != desired_interval:
                        refresh_interval.text = desired_interval
                        changed = True
                    if refresh_interval.attrib.pop("default", None) is not None:
                        changed = True
                elif settings:
                    refresh_interval = ET.SubElement(root, "setting", id="m3uRefreshIntervalMins")
                    refresh_interval.text = desired_interval
                    changed = True

            # Auto-configuración transparente del EPG local (127.0.0.1:{epg_port}/epg.xml.gz)
            if epg_path_type is not None:
                if (epg_path_type.text or "").strip() != "1":
                    epg_path_type.text = "1"
                    changed = True
                if epg_path_type.attrib.pop("default", None) is not None:
                    changed = True
            elif settings:
                epg_path_type = ET.SubElement(root, "setting", id="epgPathType")
                epg_path_type.text = "1"
                changed = True

            if epg_url is not None:
                cur_epg = (epg_url.text or "").strip()
                if not cur_epg or ":8080" in cur_epg or "192.168." in cur_epg or "githubusercontent.com" in cur_epg or cur_epg.endswith("/epg.xml"):
                    if cur_epg != desired_epg_url:
                        epg_url.text = desired_epg_url
                        changed = True
                    if epg_url.attrib.pop("default", None) is not None:
                        changed = True
            elif settings:
                epg_url = ET.SubElement(root, "setting", id="epgUrl")
                epg_url.text = desired_epg_url
                changed = True

            # Asegurar almacenamiento en caché para estabilidad offline y arranque rápido
            epg_cache = settings.get("epgCache")
            if epg_cache is not None:
                if (epg_cache.text or "").strip().lower() != "true":
                    epg_cache.text = "true"
                    changed = True
                if epg_cache.attrib.pop("default", None) is not None:
                    changed = True
            elif settings:
                epg_cache = ET.SubElement(root, "setting", id="epgCache")
                epg_cache.text = "true"
                changed = True

            m3u_cache = settings.get("m3uCache")
            if m3u_cache is not None:
                if (m3u_cache.text or "").strip().lower() != "true":
                    m3u_cache.text = "true"
                    changed = True
                if m3u_cache.attrib.pop("default", None) is not None:
                    changed = True
            elif settings:
                m3u_cache = ET.SubElement(root, "setting", id="m3uCache")
                m3u_cache.text = "true"
                changed = True

            # Asegurar que la instancia esté habilitada en Kodi 21
            inst_enabled = settings.get("kodi_addon_instance_enabled")
            if inst_enabled is not None:
                if (inst_enabled.text or "").strip().lower() != "true":
                    inst_enabled.text = "true"
                    changed = True
                if inst_enabled.attrib.pop("default", None) is not None:
                    changed = True
            elif settings:
                inst_enabled = ET.SubElement(root, "setting", id="kodi_addon_instance_enabled")
                inst_enabled.text = "true"
                changed = True

            inst_name = settings.get("kodi_addon_instance_name")
            if inst_name is None and settings:
                inst_name = ET.SubElement(root, "setting", id="kodi_addon_instance_name")
                inst_name.text = "IPTV Simple"
                changed = True

            # Enrutar streams HLS e IPTV a InputStream Adaptive obligatoriamente
            use_isa = settings.get("useInputstreamAdaptiveforHls")
            if use_isa is not None:
                if (use_isa.text or "").strip().lower() != "true":
                    use_isa.text = "true"
                    changed = True
                if use_isa.attrib.pop("default", None) is not None:
                    changed = True
            elif settings:
                use_isa = ET.SubElement(root, "setting", id="useInputstreamAdaptiveforHls")
                use_isa.text = "true"
                changed = True

            # Auto-configuración transparente de M3U
            desired_m3u_url = f"http://127.0.0.1:{epg_port}/playlist.m3u"
            m3u_path_type = settings.get("m3uPathType")
            if m3u_path_type is not None:
                if (m3u_path_type.text or "").strip() != "1":
                    m3u_path_type.text = "1"
                    changed = True
                if m3u_path_type.attrib.pop("default", None) is not None:
                    changed = True
            elif settings:
                m3u_path_type = ET.SubElement(root, "setting", id="m3uPathType")
                m3u_path_type.text = "1"
                changed = True

            m3u_url = settings.get("m3uUrl")
            if m3u_url is not None:
                cur_m3u = (m3u_url.text or "").strip()
                if "githubusercontent.com" in cur_m3u:
                    filename = get_m3u_slug_for_url(cur_m3u)
                    try:
                        target_profile = profile_dir / "addon_data" / "service.iptv.flowproxy"
                        if not target_profile.exists():
                            target_profile = profile_dir
                        register_m3u_source(filename, cur_m3u, profile_dir=target_profile)
                    except Exception as err:
                        logger.warning("No se pudo registrar fuente M3U %s -> %s: %s", filename, cur_m3u, err)
                    desired_m3u_url = f"http://127.0.0.1:{epg_port}/{filename}"
                elif not cur_m3u or ":8080" in cur_m3u:
                    desired_m3u_url = f"http://127.0.0.1:{epg_port}/playlist.m3u"

                if cur_m3u != desired_m3u_url and (not cur_m3u or ":8080" in cur_m3u or "githubusercontent.com" in cur_m3u):
                    m3u_url.text = desired_m3u_url
                    changed = True
                if m3u_url.attrib.pop("default", None) is not None:
                    changed = True
            elif settings:
                m3u_url = ET.SubElement(root, "setting", id="m3uUrl")
                m3u_url.text = desired_m3u_url
                changed = True

            if not changed:
                continue

            temporary = settings_path.with_name(
                f".{settings_path.name}.flowproxy-{os.getpid()}.tmp"
            )
            try:
                tree.write(temporary, encoding="utf-8", xml_declaration=True)
                os.replace(temporary, settings_path)
            finally:
                try:
                    if temporary.exists():
                        temporary.unlink()
                except OSError:
                    pass
            changed_files += 1
        except (OSError, ET.ParseError):
            continue
    return changed_files


def _set_kodi_addon_enabled(addon_id: str, enabled: bool) -> bool:
    if not IN_KODI:
        return False
    request = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "Addons.SetAddonEnabled",
        "params": {"addonid": addon_id, "enabled": enabled},
    }
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        return response.get("result") == "OK"
    except Exception:
        return False


def _ensure_iptv_simple_enabled() -> None:
    if not IN_KODI:
        return
    try:
        req = json.dumps({
            "jsonrpc": "2.0",
            "id": "chk_iptvsimple",
            "method": "Addons.GetAddonDetails",
            "params": {"addonid": "pvr.iptvsimple", "properties": ["enabled"]}
        })
        res = json.loads(xbmc.executeJSONRPC(req))
        addon_info = res.get("result", {}).get("addon")
        if addon_info and not addon_info.get("enabled"):
            _set_kodi_addon_enabled("pvr.iptvsimple", True)
            xbmc.log("[IPTV FlowProxy] pvr.iptvsimple habilitado automáticamente", level=xbmc.LOGINFO)
    except Exception as exc:
        xbmc.log(f"[IPTV FlowProxy] Aviso comprobando estado de pvr.iptvsimple: {exc}", level=xbmc.LOGDEBUG)


def reload_iptv_simple() -> bool:
    """Reinicia la instancia de IPTV Simple limpiamente sin colgar CPVRManager (sin PVR.Scan)."""
    if not IN_KODI:
        return False
    try:
        _set_kodi_addon_enabled("pvr.iptvsimple", False)
        xbmc.sleep(1000)
        _set_kodi_addon_enabled("pvr.iptvsimple", True)
        xbmc.log("[IPTV FlowProxy] pvr.iptvsimple recargado de forma segura mediante toggle de add-on", level=xbmc.LOGINFO)
        return True
    except Exception as exc:
        xbmc.log(f"[IPTV FlowProxy] Aviso reiniciando pvr.iptvsimple: {exc}", level=xbmc.LOGDEBUG)
        return False


def configure_kodi_inputstream_adaptive(profile_dir: Optional[Path] = None) -> bool:
    """Aprovisiona y habilita automáticamente InputStream Adaptive con ajustes seguros para streaming."""
    if not IN_KODI:
        return False
    try:
        _set_kodi_addon_enabled("inputstream.adaptive", True)
        if profile_dir is None:
            profile_dir = Path(xbmcvfs.translatePath("special://profile"))
        isa_dir = profile_dir / "addon_data" / "inputstream.adaptive"
        isa_dir.mkdir(parents=True, exist_ok=True)
        settings_file = isa_dir / "settings.xml"

        desired_settings = {
            "adaptivestream.type": "manual-osd",
            "adaptivestream.bandwidth.init.auto": "false",
            "adaptivestream.bandwidth.init": "500",
            "adaptivestream.res.max": "1080p",
            "adaptivestream.res.secure.max": "1080p",
            "overrides.ignore.screen.res": "true",
            "overrides.ignore.screen.res.change": "true",
            "ASSUREDBUFFERDURATION": "30",
            "MAXBUFFERDURATION": "60",
        }

        changed = False
        if settings_file.is_file():
            try:
                tree = ET.parse(settings_file)
                root = tree.getroot()
            except Exception:
                root = ET.Element("settings", attrib={"version": "2"})
                tree = ET.ElementTree(root)
                changed = True
        else:
            root = ET.Element("settings", attrib={"version": "2"})
            tree = ET.ElementTree(root)
            changed = True

        existing = {node.get("id"): node for node in root.findall(".//setting") if node.get("id")}
        for sid, val in desired_settings.items():
            if sid not in existing:
                elem = ET.SubElement(root, "setting", id=sid)
                elem.text = val
                changed = True
            else:
                elem = existing[sid]
                if sid in ("ASSUREDBUFFERDURATION", "MAXBUFFERDURATION", "adaptivestream.bandwidth.init"):
                    if not (elem.text or "").strip():
                        elem.text = val
                        changed = True

        if changed:
            temp_file = settings_file.with_name(f".isa_settings.{os.getpid()}.tmp")
            tree.write(temp_file, encoding="utf-8", xml_declaration=True)
            temp_file.replace(settings_file)
            xbmc.log("[IPTV FlowProxy] Ajustes óptimos de InputStream Adaptive aprovisionados automáticamente", level=xbmc.LOGINFO)
            return True
    except Exception as exc:
        xbmc.log(f"[IPTV FlowProxy] Aviso configurando InputStream Adaptive: {exc}", level=xbmc.LOGDEBUG)
    return False


CURRENT_EPG_SCHEMA_VERSION = "1.5.0-disney-live-epg"


def purge_epg_database(profile_dir: Path) -> bool:
    """Vacía las tablas epgtags y lastepgscan de Epg*.db para que Kodi cargue la guía limpia sin residuos antiguos."""
    try:
        import sqlite3
        db_dir = profile_dir / "Database"
        if not db_dir.is_dir():
            return False
        for db_file in db_dir.glob("Epg*.db"):
            try:
                conn = sqlite3.connect(str(db_file), timeout=5.0)
                with conn:
                    cur = conn.cursor()
                    cur.execute("SELECT count(*) FROM sqlite_master WHERE type='table' AND name='epgtags';")
                    if cur.fetchone()[0] > 0:
                        cur.execute("DELETE FROM epgtags;")
                        cur.execute("DELETE FROM lastepgscan;")
                conn.close()
                if IN_KODI:
                    xbmc.log(f"[IPTV FlowProxy] Base EPG {db_file.name} purgada con éxito para carga limpia", level=xbmc.LOGINFO)
            except Exception as exc:
                if IN_KODI:
                    xbmc.log(f"[IPTV FlowProxy] Aviso purgando {db_file.name}: {exc}", level=xbmc.LOGDEBUG)
        return True
    except Exception:
        return False


def _seed_bundled_data_to_profile(profile_dir: Path) -> bool:
    """Copia los datos empaquetados (M3U, EPG, bóveda ClearKey) al perfil si no existen o están desactualizados."""
    updated_epg = False
    try:
        flowproxy_profile = profile_dir / "addon_data" / "service.iptv.flowproxy"
        flowproxy_profile.mkdir(parents=True, exist_ok=True)
        data_dir = Path(__file__).resolve().parent / "resources" / "data"
        if not data_dir.is_dir():
            return False

        seeds = [
            ("kodi_canales_funcionales.m3u", "playlist.m3u"),
            ("kodi_canales_funcionales.m3u", "kodi_canales_funcionales.m3u"),
            ("epg.xml.gz", "epg.xml.gz"),
            ("dgo_keys_vault.json", "dgo_keys_vault.json"),
        ]
        for src_name, dst_name in seeds:
            src = data_dir / src_name
            dst = flowproxy_profile / dst_name
            if src.is_file():
                needs_copy = not dst.is_file() or dst.stat().st_size == 0
                if not needs_copy and src_name == "epg.xml.gz":
                    if abs(src.stat().st_size - dst.stat().st_size) > 1024 or src.stat().st_mtime > dst.stat().st_mtime:
                        needs_copy = True
                if needs_copy:
                    shutil.copy2(src, dst)
                    if dst_name == "epg.xml.gz":
                        updated_epg = True
    except Exception as exc:
        if IN_KODI:
            xbmc.log(f"[IPTV FlowProxy] Aviso sembrando datos en perfil: {exc}", level=xbmc.LOGDEBUG)
    return updated_epg


def configure_kodi_playlist_refresh() -> bool:
    """Aplica la configuración atómica de EPG y M3U sin interrumpir el arranque de Kodi."""
    if not IN_KODI:
        return False
    reloaded = False
    try:
        profile_dir = Path(xbmcvfs.translatePath("special://profile"))
        port = get_configured_port()

        # 1. Copiar semillas locales a addon_data/service.iptv.flowproxy (0 ms)
        epg_seeded = _seed_bundled_data_to_profile(profile_dir)

        # 1.1 Si la versión de esquema EPG cambió o se sembró nuevo EPG, purgar SQLite Epg*.db
        flowproxy_profile = profile_dir / "addon_data" / "service.iptv.flowproxy"
        version_file = flowproxy_profile / ".epg_version"
        current_ver = version_file.read_text(encoding="utf-8").strip() if version_file.is_file() else ""
        if current_ver != CURRENT_EPG_SCHEMA_VERSION or epg_seeded:
            purge_epg_database(profile_dir)
            try:
                version_file.write_text(CURRENT_EPG_SCHEMA_VERSION, encoding="utf-8")
            except Exception:
                pass
            reloaded = True

        # 2. Configurar advancedsettings.xml y guisettings.xml lean de forma autónoma
        ensure_advancedsettings_optimized(profile_dir)
        ensure_guisettings_optimized(profile_dir)

        # 3. Configurar InputStream Adaptive
        configure_kodi_inputstream_adaptive(profile_dir)

        # 4. Si pvr.iptvsimple no tiene instancias en disco, aprovisionar la primera ANTES de activar el add-on
        settings_dir = profile_dir / "addon_data" / "pvr.iptvsimple"
        candidate_files = list(settings_dir.glob("instance-settings-*.xml")) if settings_dir.is_dir() else []
        legacy = settings_dir / "settings.xml" if settings_dir.is_dir() else None
        provisioned_new = False
        if not candidate_files and (not legacy or not legacy.is_file()):
            settings_dir.mkdir(parents=True, exist_ok=True)
            initial_file = settings_dir / "instance-settings-1.xml"
            initial_xml = (
                '<?xml version="1.0" encoding="utf-8"?>\n'
                '<settings version="2">\n'
                '  <setting id="kodi_addon_instance_name">IPTV Simple</setting>\n'
                '  <setting id="kodi_addon_instance_enabled">true</setting>\n'
                '  <setting id="m3uPathType">1</setting>\n'
                f'  <setting id="m3uUrl">http://127.0.0.1:{port}/playlist.m3u</setting>\n'
                '  <setting id="m3uCache">true</setting>\n'
                '  <setting id="m3uRefreshMode">1</setting>\n'
                '  <setting id="m3uRefreshIntervalMins">15</setting>\n'
                '  <setting id="epgPathType">1</setting>\n'
                f'  <setting id="epgUrl">http://127.0.0.1:{port}/epg.xml.gz</setting>\n'
                '  <setting id="epgCache">true</setting>\n'
                '  <setting id="useInputstreamAdaptiveforHls">true</setting>\n'
                '</settings>\n'
            )
            initial_file.write_text(initial_xml, encoding="utf-8")
            provisioned_new = True
            xbmc.log("[IPTV FlowProxy] Primera instancia de IPTV Simple aprovisionada automáticamente en modo lean", level=xbmc.LOGINFO)

        changed = update_iptv_simple_refresh_settings(
            profile_dir, interval_minutes=15, epg_port=port
        )
        if changed:
            xbmc.log(
                f"[IPTV FlowProxy] Ajustes de IPTV Simple actualizados atómicamente ({changed} instancia(s))",
                level=xbmc.LOGINFO,
            )

        # 5. Asegurar que IPTV Simple esté habilitado (con los ajustes ya en disco)
        _ensure_iptv_simple_enabled()

        # 6. Si es nueva instalación o cambiaron ajustes en disco, recargar add-on para que tome efecto inmediato
        if provisioned_new or changed > 0:
            xbmc.log("[IPTV FlowProxy] Recargando IPTV Simple para aplicar ajustes en memoria...", level=xbmc.LOGINFO)
            reload_iptv_simple()
            reloaded = True
    except Exception as exc:
        xbmc.log(
            f"[IPTV FlowProxy] No se pudo configurar IPTV Simple: {exc}",
            level=xbmc.LOGWARNING,
        )
    return reloaded


DISNEY_PROP_0 = [
    "#KODIPROP:inputstream.adaptive.stream_selection_type=adaptive",
    "#KODIPROP:inputstream.adaptive.chooser_bandwidth_max=4500000",
    "#KODIPROP:inputstream.adaptive.chooser_resolution_max=720p",
    "#KODIPROP:inputstream.adaptive.chooser_resolution_secure_max=720p",
]
DISNEY_PROP_1 = [
    "#KODIPROP:inputstream.adaptive.stream_selection_type=adaptive",
    "#KODIPROP:inputstream.adaptive.chooser_bandwidth_max=6000000",
    "#KODIPROP:inputstream.adaptive.chooser_resolution_max=1080p",
    "#KODIPROP:inputstream.adaptive.chooser_resolution_secure_max=1080p",
]
DISNEY_PROP_2 = [
    "#KODIPROP:inputstream.adaptive.stream_selection_type=adaptive",
]
DISNEY_PROP_3 = [
    "#KODIPROP:inputstream.adaptive.stream_selection_type=manual-osd",
]


def find_candidate_playlists(profile_dir: Path) -> list[Path]:
    """Descubre todas las listas M3U activas usadas por IPTV Simple o presentes en disco."""
    candidates: set[Path] = set()
    settings_dir = profile_dir / "addon_data" / "pvr.iptvsimple"
    if settings_dir.is_dir():
        candidate_settings = list(settings_dir.glob("instance-settings-*.xml"))
        legacy = settings_dir / "settings.xml"
        if legacy.is_file():
            candidate_settings.append(legacy)
        for sfile in candidate_settings:
            try:
                tree = ET.parse(sfile)
                for node in tree.findall(".//setting"):
                    if node.get("id") in ("m3uPath", "m3uUrl"):
                        val = (node.text or "").strip()
                        if val.startswith("/") or val.startswith("file://") or val.startswith("special://"):
                            clean_val = val.replace("file://", "")
                            if clean_val.startswith("special://") and IN_KODI:
                                clean_val = xbmcvfs.translatePath(clean_val)
                            p = Path(clean_val)
                            if p.is_file():
                                candidates.add(p)
            except Exception:
                pass

    standard_paths = [
        Path("/home/fer/listas_funcionales/kodi_disney.m3u"),
        Path("/home/fer/listas_funcionales/kodi_flowproxy_local.m3u"),
        Path("/home/fer/listas_funcionales/kodi_canales_funcionales.m3u"),
        Path("/home/fer/listas_gist/kodi_disney.m3u"),
        Path("/home/fer/listas_gist/kodi_flowproxy_local.m3u"),
        Path("/home/fer/listas_gist/kodi_canales_funcionales.m3u"),
        Path.home() / ".flow_cache" / "eventos_kodi.m3u",
        Path("/storage/emulated/0/Download/kodi_disney.m3u"),
        Path("/storage/emulated/0/Download/kodi_flowproxy_local.m3u"),
        profile_dir / "addon_data" / "service.iptv.flowproxy" / "kodi_disney.m3u",
    ]
    for sp in standard_paths:
        if sp.is_file():
            candidates.add(sp)

    return sorted(list(candidates))


def transform_m3u_disney_profile(m3u_text: str, quality_profile: int) -> tuple[str, bool]:
    """Transforma las propiedades ISA de los streams Disney según el perfil configurado."""
    lines = m3u_text.splitlines()
    new_lines: list[str] = []
    current_block: list[str] = []
    changed = False

    target_props = (
        DISNEY_PROP_0
        if quality_profile == 0
        else DISNEY_PROP_1
        if quality_profile == 1
        else DISNEY_PROP_2
        if quality_profile == 2
        else DISNEY_PROP_3
    )

    prop_prefixes = (
        "#KODIPROP:inputstream.adaptive.stream_selection_type=",
        "#KODIPROP:inputstream.adaptive.chooser_bandwidth_max=",
        "#KODIPROP:inputstream.adaptive.chooser_resolution_max=",
        "#KODIPROP:inputstream.adaptive.chooser_resolution_secure_max=",
    )

    def process_block(block: list[str]) -> list[str]:
        nonlocal changed
        if not block:
            return []
        url_line = block[-1].strip()
        is_disney = (
            "/disney/" in url_line
            or any("/disney/" in l for l in block if l.startswith("#KODIPROP:"))
        )
        if not is_disney:
            return block

        filtered = []
        for l in block[:-1]:
            if any(l.strip().startswith(prefix) for prefix in prop_prefixes):
                continue
            filtered.append(l)

        insert_idx = len(filtered)
        for i, l in enumerate(filtered):
            if l.strip().startswith("#KODIPROP:inputstream.adaptive.manifest_type"):
                insert_idx = i + 1
                break

        reconstructed = filtered[:insert_idx] + target_props + filtered[insert_idx:] + [block[-1]]
        if reconstructed != block:
            changed = True
        return reconstructed

    for line in lines:
        if line.startswith("#EXTINF:"):
            if current_block:
                new_lines.extend(process_block(current_block))
                current_block = []
            current_block.append(line)
        elif current_block:
            current_block.append(line)
            if not line.startswith("#") and line.strip():
                new_lines.extend(process_block(current_block))
                current_block = []
        else:
            new_lines.append(line)

    if current_block:
        new_lines.extend(process_block(current_block))

    new_text = "\n".join(new_lines) + ("\n" if m3u_text.endswith("\n") else "")
    return new_text, changed


def apply_disney_quality_profile_to_playlists(
    profile_dir: Path,
    quality_profile: int,
    candidate_paths: Optional[list[Path]] = None,
) -> int:
    """Aplica las propiedades ISA del perfil de calidad Disney a todas las listas M3U activas."""
    playlists = candidate_paths if candidate_paths is not None else find_candidate_playlists(profile_dir)
    changed_count = 0
    for p in playlists:
        if not p.is_file():
            continue
        try:
            content = p.read_text(encoding="utf-8", errors="ignore")
            if "/disney/" not in content:
                continue
            new_content, changed = transform_m3u_disney_profile(content, quality_profile)
            if changed:
                tmp_p = p.with_name(f".{p.name}.profile-{os.getpid()}.tmp")
                tmp_p.write_text(new_content, encoding="utf-8")
                tmp_p.replace(p)
                changed_count += 1
        except Exception as exc:
            msg = f"[IPTV FlowProxy] Error aplicando perfil Disney en {p}: {exc}"
            if IN_KODI:
                xbmc.log(msg, level=xbmc.LOGWARNING)
            else:
                print(msg)

    return changed_count



if IN_KODI:
    class FlowProxyMonitor(xbmc.Monitor):
        def __init__(self, profile_dir: Path):
            super().__init__()
            self.profile_dir = profile_dir
            self.last_quality_profile = get_disney_quality_profile()

        def onSettingsChanged(self):
            cur_profile = get_disney_quality_profile()
            if cur_profile != self.last_quality_profile:
                old_profile = self.last_quality_profile
                self.last_quality_profile = cur_profile
                xbmc.log(
                    f"[IPTV FlowProxy] Ajuste disney_quality_profile cambiado ({old_profile} -> {cur_profile}). "
                    "Actualizando listas M3U...",
                    level=xbmc.LOGINFO,
                )
                changed = apply_disney_quality_profile_to_playlists(self.profile_dir, cur_profile)
                if changed > 0:
                    reload_iptv_simple()
else:
    class FlowProxyMonitor:
        def __init__(self, profile_dir: Path):
            self.profile_dir = profile_dir
            self.last_quality_profile = get_disney_quality_profile()

        def onSettingsChanged(self):
            cur_profile = get_disney_quality_profile()
            if cur_profile != self.last_quality_profile:
                self.last_quality_profile = cur_profile
                apply_disney_quality_profile_to_playlists(self.profile_dir, cur_profile)



def shutdown_server() -> None:
    global _current_httpd
    if _current_httpd:
        try:
            _current_httpd.shutdown()
            _current_httpd.server_close()
        finally:
            _current_httpd = None
    try:
        from resources.lib.local_server import close_resolvers
        close_resolvers()
    except Exception:
        pass


def run_server(port: int, ready_event: Optional[threading.Event] = None) -> None:
    global _current_httpd
    from resources.lib.local_server import FlowProxyHandler, ThreadedHTTPServer
    server_address = ("127.0.0.1", port)
    _current_httpd = ThreadedHTTPServer(server_address, FlowProxyHandler)
    if ready_event is not None:
        ready_event.set()
    msg = f"[IPTV FlowProxy] Servidor iniciado en http://127.0.0.1:{port}"
    if IN_KODI:
        xbmc.log(msg, level=xbmc.LOGINFO)
    else:
        print(msg)
    _current_httpd.serve_forever()


def _cold_start_pvr_watchdog(server_ready_event: threading.Event) -> None:
    """Garantiza sincronismo en arranque en frío y carga de EPG sin colgar CPVRManager."""
    if not IN_KODI:
        return
    # 1. Esperar hasta 10 segundos a que el servidor HTTP local esté listo
    if not server_ready_event.wait(timeout=10.0):
        xbmc.log("[IPTV FlowProxy] Advertencia: timeout esperando servidor local en arranque", level=xbmc.LOGWARNING)

    # 2. Configurar ajustes de IPTV Simple (EPG/M3U) de forma atómica
    reloaded = configure_kodi_playlist_refresh()

    profile_dir = Path(xbmcvfs.translatePath("special://profile"))
    port = get_configured_port()

    # 3. Comprobar que el endpoint EPG local responda 200
    for _ in range(6):
        try:
            import urllib.request
            req = urllib.request.Request(f"http://127.0.0.1:{port}/epg.xml.gz")
            with urllib.request.urlopen(req, timeout=2.0) as resp:
                if resp.status == 200:
                    break
        except Exception:
            xbmc.sleep(500)

    # 4. En arranque en frío, si Kodi no tiene tags de EPG vigentes en su base de datos
    # (porque intentó conectar antes de que levantara el socket HTTP),
    # limpiar lastepgscan y recargar IPTV Simple con el servidor local ya activo.
    if not reloaded:
        needs_kick = reset_epg_last_scan_if_stale(profile_dir)
        if needs_kick:
            xbmc.sleep(1500)
            reload_iptv_simple()
            xbmc.log("[IPTV FlowProxy] IPTV Simple recargado tras arranque en frío para poblar EPG inmediatamente", level=xbmc.LOGINFO)

    # 5. Descarga / actualización de EPG en segundo plano sin bloquear el arranque
    try:
        from resources.lib.local_server import (
            _find_epg_files,
            _schedule_epg_refresh,
        )
        epg_xml, epg_gz = _find_epg_files()
        needs_download = False
        if not epg_gz and not epg_xml:
            needs_download = True
        elif epg_gz and (time.time() - epg_gz.stat().st_mtime > 12 * 3600):
            needs_download = True
        if needs_download:
            # Single-flight: si el primer request HTTP ya lanzó el refresco, no
            # se duplica la descarga desde el arranque en frío.
            _schedule_epg_refresh(force=True)
    except Exception as epg_bg_err:
        xbmc.log(f"[IPTV FlowProxy] Aviso comprobando EPG de fondo: {epg_bg_err}", level=xbmc.LOGDEBUG)

    # 6. Dar tiempo a Kodi PVR para importar canales y guía de forma natural
    xbmc.sleep(2000)


def _handle_script_action(args: list[str]) -> None:
    """Maneja ejecuciones del add-on como script (ej. botón Sincronizar en Ajustes)."""
    action = args[0].strip().lower() if args else ""
    if "sync" in action:
        port = get_configured_port()
        try:
            import urllib.request
            req = urllib.request.Request(f"http://127.0.0.1:{port}/sync")
            with urllib.request.urlopen(req, timeout=30) as resp:
                pass
        except Exception as exc:
            if IN_KODI:
                xbmc.log(f"[IPTV FlowProxy] Aviso invocando /sync en servidor local: {exc}", level=xbmc.LOGDEBUG)

        if IN_KODI:
            try:
                import xbmcgui
                reload_iptv_simple()
                xbmcgui.Dialog().notification(
                    "IPTV FlowProxy",
                    "Canales y Guía EPG sincronizados",
                    xbmcgui.NOTIFICATION_INFO,
                    3500,
                )
            except Exception:
                pass


if __name__ == "__main__":
    if len(sys.argv) > 1 and any("sync" in a.lower() for a in sys.argv[1:]):
        _handle_script_action(sys.argv[1:])
        sys.exit(0)

    if IN_KODI:
        _ensure_binary_dependencies()

    if not _check_kodi_version_and_isa():
        sys.exit(0)
    port = get_configured_port()
    server_ready_event = threading.Event()
    server_thread = threading.Thread(
        target=run_server, args=(port, server_ready_event), daemon=True
    )
    server_thread.start()

    profile_dir = (
        Path(xbmcvfs.translatePath("special://profile"))
        if IN_KODI
        else Path.home() / ".kodi" / "userdata"
    )

    # 1. Aplicar perfil de calidad Disney configurado al arrancar
    initial_profile = get_disney_quality_profile()
    try:
        changed_lists = apply_disney_quality_profile_to_playlists(
            profile_dir, initial_profile
        )
        if changed_lists > 0 and IN_KODI:
            xbmc.log(
                f"[IPTV FlowProxy] Perfil Disney ({initial_profile}) aplicado a {changed_lists} lista(s) M3U al inicio",
                level=xbmc.LOGINFO,
            )
    except Exception as init_err:
        if IN_KODI:
            xbmc.log(
                f"[IPTV FlowProxy] Aviso aplicando perfil Disney al inicio: {init_err}",
                level=xbmc.LOGWARNING,
            )

    # 2. Configurar IPTV Simple y vigilar arranque en frío de forma no destructiva
    if IN_KODI:
        threading.Thread(
            target=_cold_start_pvr_watchdog, args=(server_ready_event,), daemon=True
        ).start()

    # 3. Bucle reactivo 100% Lazy: sin warmups artificiales ni encuestas periódicas
    if IN_KODI:
        monitor = FlowProxyMonitor(profile_dir)
        while not monitor.abortRequested():
            if monitor.waitForAbort(1):
                break
        try:
            shutdown_server()
        except Exception as exc:
            xbmc.log(f"[IPTV FlowProxy] Error durante cierre: {exc}", level=xbmc.LOGERROR)
        xbmc.log("[IPTV FlowProxy] Servicio detenido limpiamente", level=xbmc.LOGINFO)
    else:
        print("[IPTV FlowProxy] Ejecutando en modo standalone (presione Ctrl+C para salir)...")
        try:
            import time
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            shutdown_server()
            print("[IPTV FlowProxy] Detenido.")
            sys.exit(0)

