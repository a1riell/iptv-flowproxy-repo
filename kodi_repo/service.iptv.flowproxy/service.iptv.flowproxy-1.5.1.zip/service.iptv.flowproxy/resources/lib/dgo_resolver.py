"""
DgoSessionResolver: Resolución y caché de manifiestos DASH y proxy de licencias Widevine para DGO.
Diseñado para correr en service.iptv.flowproxy (Kodi 19+, 20+, 21+) en Python 3 puro.
"""

from __future__ import annotations

import base64
import datetime as dt
import email.utils
import hashlib
import http.client
import io
import json
import logging
import os
import re
import socket
import ssl
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("flowproxy_dgo_resolver")

USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36"

BOOTSTRAP_SECRET_KEY = "IPTV_FLOWPROXY_SECRET_2026"
DEFAULT_GIST_BOOTSTRAP_URL = (
    "https://gist.githubusercontent.com/a1riell/9c1db121510fc81709f28c132afb9c81/raw/dgo_credentials.dat"
)

LIVE_CHANNELS_ENDPOINT = "https://api.directvgo.com/contents/v2/live/channels"
# Nombres aceptados para la bóveda ClearKey publicada junto al add-on/perfil.
CLEARKEY_VAULT_FILENAMES = ("dgo_keys_vault.json", "dgo_clearkeys.json")

DASH_NAMESPACE = "urn:mpeg:dash:schema:mpd:2011"
CENC_NAMESPACE = "urn:mpeg:cenc:2013"
DEFAULT_LIVE_DELAY_SECONDS = 12
DEFAULT_DYNAMIC_MPD_CACHE_SECONDS = 1.0
MAX_DYNAMIC_MPD_CACHE_SECONDS = 1.0
MIN_DYNAMIC_MPD_CACHE_SECONDS = 0.10

def _local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _merge_url_query(url: str, extra_query: str) -> str:
    """Agrega la query de sesión y reemplaza firmas obsoletas del recurso."""
    if not extra_query:
        return url
    parsed = urllib.parse.urlsplit(url)
    existing = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
    remote = urllib.parse.parse_qsl(extra_query, keep_blank_values=True)
    remote_names = {name for name, _ in remote}
    # Una firma presente en el MPD puede pertenecer a otra sesión. La URL del
    # manifest descargado es la autoridad para estos parámetros.
    replace_names = {"hdnts", "hdntl", "da", "tokenization"}
    existing = [
        (name, value)
        for name, value in existing
        if name not in replace_names or name not in remote_names
    ]
    existing_names = {name for name, _ in existing}
    additions = [
        (name, value)
        for name, value in remote
        if name not in existing_names
    ]
    # Los identificadores DASH dentro de la query también son plantillas. Si
    # ``$Time$`` se convierte en ``%24Time%24``, ISA no lo sustituye y el CDN
    # recibe el literal, algo especialmente visible en audio y subtítulos.
    merged = urllib.parse.urlencode(existing + additions, safe="$")
    return urllib.parse.urlunsplit(
        (parsed.scheme, parsed.netloc, parsed.path, merged, parsed.fragment)
    )


def _dash_periods(root: ET.Element) -> list[ET.Element]:
    return [child for child in list(root) if _local_name(child.tag) == "Period"]


_ISO_DURATION_RE = re.compile(
    r"^P(?:(?P<days>\d+(?:\.\d+)?)D)?(?:T(?:(?P<hours>\d+(?:\.\d+)?)H)?"
    r"(?:(?P<minutes>\d+(?:\.\d+)?)M)?(?:(?P<seconds>\d+(?:\.\d+)?)S)?)?$"
)


def _parse_duration(value: Optional[str]) -> Optional[float]:
    if not value:
        return None
    match = _ISO_DURATION_RE.match(value)
    if not match:
        return None
    parts = {key: float(val or 0.0) for key, val in match.groupdict().items()}
    return (
        parts["days"] * 86400.0
        + parts["hours"] * 3600.0
        + parts["minutes"] * 60.0
        + parts["seconds"]
    )


def _manifest_cache_ttl(mpd: bytes) -> float:
    """Deriva una caché corta del ``minimumUpdatePeriod`` del MPD dinámico.

    La caché nunca ocupa todo el intervalo anunciado: así una consulta de ISA
    cerca del borde vivo no recibe una fotografía anterior durante otro ciclo.
    """
    try:
        root = ET.fromstring(mpd)
    except (ET.ParseError, TypeError, ValueError):
        return DEFAULT_DYNAMIC_MPD_CACHE_SECONDS
    if root.attrib.get("type", "").lower() != "dynamic":
        return 30.0
    val = root.attrib.get("minimumUpdatePeriod")
    if val is None:
        return DEFAULT_DYNAMIC_MPD_CACHE_SECONDS
    update_period = _parse_duration(val)
    if update_period is None:
        return DEFAULT_DYNAMIC_MPD_CACHE_SECONDS
    if update_period <= 0:
        return 0.0
    return max(
        MIN_DYNAMIC_MPD_CACHE_SECONDS,
        min(MAX_DYNAMIC_MPD_CACHE_SECONDS, update_period * 0.5),
    )


def _parse_xs_datetime(value: Optional[str]) -> Optional[dt.datetime]:
    if not value:
        return None
    try:
        parsed = dt.datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=dt.timezone.utc)
        return parsed.astimezone(dt.timezone.utc)
    except (TypeError, ValueError):
        return None


def _direct_utc(root: ET.Element) -> Optional[dt.datetime]:
    for elem in root:
        if _local_name(elem.tag) != "UTCTiming":
            continue
        if "direct" in elem.attrib.get("schemeIdUri", "").lower():
            parsed = _parse_xs_datetime(elem.attrib.get("value"))
            if parsed:
                return parsed
    return None


def _prune_to_live_period(
    root: ET.Element,
    live_delay: float = DEFAULT_LIVE_DELAY_SECONDS,
    safety_window: float = 45.0,
) -> int:
    """Conserva el Period activo, los períodos futuros y los períodos pasados
    cuyo tiempo de finalización intersecte la ventana de seguridad temporal (safety_window).

    Esto evita cortar la reproducción a usuarios pausados o con buffering / fluctuaciones
    de red dentro de la ventana de seguridad, asegurando continuidad temporal y asignando
    start explícito a los períodos conservados.
    """
    if root.attrib.get("type", "").lower() != "dynamic":
        return 0
    periods = _dash_periods(root)
    if len(periods) <= 1:
        return 0

    ast = _parse_xs_datetime(root.attrib.get("availabilityStartTime"))
    utc_now = _direct_utc(root) or _parse_xs_datetime(root.attrib.get("publishTime"))
    if ast is None or utc_now is None:
        return 0
    target = max(0.0, (utc_now - ast).total_seconds() - live_delay)
    window_start = max(0.0, target - safety_window)

    starts: List[float] = []
    previous_end: Optional[float] = 0.0
    for index, period in enumerate(periods):
        explicit = _parse_duration(period.attrib.get("start"))
        if explicit is not None:
            start = explicit
        elif index == 0:
            start = 0.0
        elif previous_end is not None:
            start = previous_end
        else:
            return 0
        starts.append(start)
        duration = _parse_duration(period.attrib.get("duration"))
        previous_end = start + duration if duration is not None else None

    active_index: Optional[int] = None
    for index, start in enumerate(starts):
        next_start = starts[index + 1] if index + 1 < len(starts) else None
        duration = _parse_duration(periods[index].attrib.get("duration"))
        end = start + duration if duration is not None else next_start
        if start <= target and (end is None or target < end):
            active_index = index
    if active_index is None:
        return 0

    to_keep = set()
    for index, period in enumerate(periods):
        if index >= active_index:
            to_keep.add(period)
        else:
            next_start = starts[index + 1] if index + 1 < len(starts) else None
            duration = _parse_duration(period.attrib.get("duration"))
            end = starts[index] + duration if duration is not None else next_start
            if end is None or end > window_start:
                to_keep.add(period)

    if len(to_keep) == len(periods):
        return 0

    for index, period in enumerate(periods):
        if period in to_keep and "start" not in period.attrib:
            period.attrib["start"] = f"PT{starts[index]:.3f}S"

    removed_count = 0
    for period in periods:
        if period not in to_keep:
            root.remove(period)
            removed_count += 1

    return removed_count


def _normalize_dash_session_url(url: str) -> str:
    """Desactiva el pre-roll personalizado de MediaTailor para iniciar en vivo."""
    parsed = urllib.parse.urlsplit(url)
    raw_pairs = parsed.query.split("&") if parsed.query else []
    found = False
    normalized = []
    for pair in raw_pairs:
        raw_name, separator, _raw_value = pair.partition("=")
        if urllib.parse.unquote_plus(raw_name) == "da":
            found = True
            normalized.append(raw_name + separator + "0" if separator else raw_name + "=0")
        else:
            normalized.append(pair)
    if not found:
        return url
    return urllib.parse.urlunsplit(
        (parsed.scheme, parsed.netloc, parsed.path, "&".join(normalized), parsed.fragment)
    )


def _enable_dash_ads(url: str) -> str:
    """Restaura da=1 sin recodificar la firma ni el resto de la query."""
    parsed = urllib.parse.urlsplit(url)
    pairs = []
    for pair in parsed.query.split("&") if parsed.query else []:
        raw_name, separator, _raw_value = pair.partition("=")
        if urllib.parse.unquote_plus(raw_name) == "da":
            pairs.append(raw_name + separator + "1" if separator else raw_name + "=1")
        else:
            pairs.append(pair)
    return urllib.parse.urlunsplit(
        (parsed.scheme, parsed.netloc, parsed.path, "&".join(pairs), parsed.fragment)
    )


def _signed_url_ttl(
    url: str, default_ttl: float, margin: float, now_epoch: Optional[float] = None
) -> float:
    """Limita la caché al vencimiento real del token ``hdnts`` de Akamai."""
    query = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
    token = (query.get("hdnts") or query.get("hdntl") or [""])[0]
    match = re.search(r"(?:^|[~&])exp=(\d+)(?:[~&]|$)", token)
    if not match:
        return default_ttl
    remaining = float(match.group(1)) - (time.time() if now_epoch is None else now_epoch) - margin
    return max(0.0, min(default_ttl, remaining))


def _deobfuscate_credentials(obfuscated_b64: str, secret_key: str = BOOTSTRAP_SECRET_KEY) -> bytes:
    """Descifra el payload ofuscado de credenciales mediante XOR con hash SHA-256."""
    cipher_bytes = base64.b64decode(obfuscated_b64.strip())
    key_bytes = hashlib.sha256(secret_key.encode("utf-8")).digest()
    out = bytearray(len(cipher_bytes))
    for i in range(len(cipher_bytes)):
        out[i] = cipher_bytes[i] ^ key_bytes[i % len(key_bytes)]
    return bytes(out)

def _get_addon_profile_dir() -> Optional[Path]:
    """Obtiene el directorio de perfil del addon de forma compatible con Kodi 19, 20 y 21."""
    try:
        import xbmcvfs
        translate_fn = getattr(xbmcvfs, "translatePath", None)
        if not translate_fn:
            import xbmc
            translate_fn = getattr(xbmc, "translatePath", None)
        if translate_fn:
            import xbmcaddon
            profile_str = translate_fn(xbmcaddon.Addon().getAddonInfo("profile"))
            if profile_str:
                return Path(profile_str)
    except Exception:
        pass
    return None

def _load_dgo_channels_catalog() -> Dict[str, Dict[str, Any]]:
    """Carga el catálogo completo de canales DGO desde dgo_channels.json."""
    catalog: Dict[str, Dict[str, Any]] = {
        "espn-premium": {
            "channel_id": "CH0100000000182",
            "drm_id": "Live_1125",
            "name": "ESPN Premium Argentina",
        },
        "tnt-sports": {
            "channel_id": "CH0100000000040",
            "drm_id": "Live_1233",
            "name": "TNT Sports Argentina",
        },
        "espn": {
            "channel_id": "CH0100000000162",
            "drm_id": "Live_1104",
            "name": "ESPN Argentina",
        },
        "espn2": {
            "channel_id": "CH0100000000016",
            "drm_id": "Live_1099",
            "name": "ESPN 2 Argentina",
        },
        "espn3": {
            "channel_id": "CH0100000000163",
            "drm_id": "Live_1103",
            "name": "ESPN 3 Sur",
        },
        "fox-sports": {
            "channel_id": "CH0100000000177",
            "drm_id": "Live_1118",
            "name": "Fox Sports Argentina",
        },
        "fox-sports2": {
            "channel_id": "CH0100000000335",
            "drm_id": "Live_1281",
            "name": "Fox Sports 2 Argentina",
        },
        "fox-sports3": {
            "channel_id": "CH0100000000336",
            "drm_id": "Live_1280",
            "name": "Fox Sports 3 Argentina",
        },
        "tyc-sports": {
            "channel_id": "CH0100000000036",
            "drm_id": "Live_1240",
            "name": "TyC Sports",
        },
    }

    candidates = [
        Path(__file__).resolve().parent / "dgo_channels.json",
    ]
    profile_dir = _get_addon_profile_dir()
    if profile_dir:
        candidates.append(profile_dir / "dgo_channels.json")

    for candidate in candidates:
        if candidate.is_file():
            try:
                data = json.loads(candidate.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    for slug, info in data.items():
                        if isinstance(info, dict) and "channel_id" in info and "drm_id" in info:
                            item = dict(info)
                            if "name" not in item and "title" in item:
                                item["name"] = item["title"]
                            catalog[slug] = item
                    break
            except Exception as e:
                logger.warning("No se pudo cargar %s: %s", candidate, e)

    return catalog


# Mapeo canónico de canales DGO
DGO_CHANNELS: Dict[str, Dict[str, Any]] = _load_dgo_channels_catalog()

# Inverso drm_id -> slug
DRM_ID_TO_SLUG: Dict[str, str] = {
    info["drm_id"].lower(): slug for slug, info in DGO_CHANNELS.items() if "drm_id" in info
}


class ChannelTemporarilyUnavailable(RuntimeError):
    """El proveedor confirmó la señal, pero su CDN no entrega segmentos."""


def _extract_jwt_payload(token: str) -> Dict[str, Any]:
    """Decodifica claims no verificados para seleccionar el contrato OAuth."""
    if not token or "." not in token:
        return {}
    try:
        parts = token.split(".")
        if len(parts) < 2:
            return {}
        payload_b64 = parts[1] + "=" * (-len(parts[1]) % 4)
        payload = json.loads(base64.urlsafe_b64decode(payload_b64))
        return payload if isinstance(payload, dict) else {}
    except Exception:
        return {}


def _extract_jwt_exp(token: str) -> Optional[int]:
    """Extrae el claim 'exp' de un JWT sin validar la firma."""
    try:
        return int(_extract_jwt_payload(token).get("exp", 0))
    except (TypeError, ValueError):
        return None


WIDEVINE_SYSTEM_ID = "edef8ba979d64acea3c827dcd51d21ed"


def _read_varint(buffer: bytes, offset: int) -> Tuple[int, int]:
    """Lee un varint protobuf; devuelve (valor, offset siguiente)."""
    value = 0
    shift = 0
    while offset < len(buffer):
        byte = buffer[offset]
        offset += 1
        value |= (byte & 0x7F) << shift
        if not byte & 0x80:
            return value, offset
        shift += 7
        if shift > 63:
            break
    raise ValueError("varint truncado")


def _kids_from_pssh(pssh_box: bytes) -> List[str]:
    """Extrae KIDs de un box ``pssh`` (ISO/IEC 23001-7) y del payload Widevine.

    Algunos manifiestos de DGO no declaran ``cenc:default_KID`` en el MPD, pero
    sí incluyen el KID dentro del PSSH de Widevine (campo protobuf 2). Sin este
    dato la bóveda ClearKey no puede emparejar la clave viva y el canal cae a
    Widevine. El parser tolera PSSH version 0 (payload protobuf) y version 1
    (lista explícita de KIDs).
    """
    if len(pssh_box) < 32 or pssh_box[4:8] != b"pssh":
        return []
    version = pssh_box[8]
    system_id = pssh_box[12:28].hex().lower()
    offset = 28
    kids: List[str] = []
    if version > 0:
        if offset + 4 > len(pssh_box):
            return []
        count = int.from_bytes(pssh_box[offset:offset + 4], "big")
        offset += 4
        for _ in range(count):
            if offset + 16 > len(pssh_box):
                return kids
            kids.append(pssh_box[offset:offset + 16].hex())
            offset += 16
    if offset + 4 > len(pssh_box):
        return kids
    data_size = int.from_bytes(pssh_box[offset:offset + 4], "big")
    offset += 4
    payload = pssh_box[offset:offset + data_size]
    if system_id != WIDEVINE_SYSTEM_ID:
        return kids
    index = 0
    while index < len(payload):
        try:
            tag, index = _read_varint(payload, index)
        except ValueError:
            break
        field, wire = tag >> 3, tag & 0x7
        if wire == 0:
            try:
                _, index = _read_varint(payload, index)
            except ValueError:
                break
        elif wire == 2:
            try:
                length, index = _read_varint(payload, index)
            except ValueError:
                break
            value = payload[index:index + length]
            index += length
            if field == 2 and len(value) == 16:
                kids.append(value.hex())
        elif wire == 5:
            index += 4
        elif wire == 1:
            index += 8
        else:
            break
    return kids


def _manifest_pssh_kids(manifest_text: str) -> List[str]:
    """Busca todos los ``<...pssh>`` del MPD y devuelve sus KIDs."""
    kids: List[str] = []
    pattern = (
        r"<(?:[A-Za-z0-9_.-]+:)?pssh\b[^>]*>(.*?)"
        r"</(?:[A-Za-z0-9_.-]+:)?pssh>"
    )
    for raw in re.findall(pattern, manifest_text, flags=re.IGNORECASE | re.DOTALL):
        try:
            box = base64.b64decode("".join(raw.split()), validate=False)
        except Exception:
            continue
        kids.extend(_kids_from_pssh(box))
    return kids


def rewrite_dgo_mpd(raw_mpd: bytes, remote_url: str) -> bytes:
    """Reescribe un manifiesto DASH de DGO para inyectar BaseURL y parámetros de query en los segmentos.

    Akamai requiere que cada petición a los segmentos (.mp4) incluya la firma hdnts=...
    presente en la URL del manifiesto. Los reproductores estándar (como Kodi) resuelven
    los segmentos relativos descartando los query parameters, provocando HTTP 403 Forbidden.
    """
    if isinstance(raw_mpd, str):
        raw_mpd = raw_mpd.encode("utf-8")

    parsed = urllib.parse.urlsplit(remote_url)
    query = parsed.query.strip()

    base_dir = parsed.path.rsplit("/", 1)[0] + "/"
    fallback_base_url = urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, base_dir, "", ""))

    try:
        ET.register_namespace("", DASH_NAMESPACE)
        root = ET.fromstring(raw_mpd)

        # 1. Mantener el live edge: eliminar sólo períodos históricos. El período
        # activo conserva su start/PTO original, por lo que la línea temporal sigue
        # siendo válida respecto de availabilityStartTime.
        pruned = _prune_to_live_period(root)
        if pruned:
            logger.info("[IPTV DGO] MPD podado: %d Period históricos eliminados", pruned)

        # 2. Un retraso estable evita solicitar segmentos que el encoder todavía no
        # publicó. MediaTailor suele anunciar PT8S, insuficiente en TV boxes lentos.
        if root.attrib.get("type", "").lower() == "dynamic":
            root.set("suggestedPresentationDelay", f"PT{DEFAULT_LIVE_DELAY_SECONDS}S")
            # DGO anuncia minBufferTime="PT2S", pero cada segmento de video dura 4s.
            # Un búfer equilibrado de 4s a 6s permite arranque ultrarrápido sin congelamientos.
            min_buf = _parse_duration(root.attrib.get("minBufferTime"))
            if min_buf is None or min_buf < 4.0:
                root.set("minBufferTime", "PT4S")

        # 3. Location apuntaría a MediaTailor y sacaría las próximas actualizaciones
        # del proxy local. UTCTiming, en cambio, se conserva: es el reloj de referencia
        # que permite a ISA calcular correctamente el borde vivo.
        for child in list(root):
            if _local_name(child.tag) == "Location":
                root.remove(child)

        # 4. Anclar sólo las BaseURL de nivel MPD. Las BaseURL de Period,
        # AdaptationSet y Representation son jerárquicas; resolver cada una contra
        # la URL del manifest destruye esa jerarquía.
        root_base_elements = [
            elem for elem in list(root) if _local_name(elem.tag) == "BaseURL"
        ]
        if not root_base_elements:
            base_elem = ET.Element(f"{{{DASH_NAMESPACE}}}BaseURL")
            base_elem.text = fallback_base_url
            insert_at = next(
                (
                    index
                    for index, child in enumerate(list(root))
                    if _local_name(child.tag) in ("Location", "Period", "Metrics")
                ),
                len(root),
            )
            root.insert(insert_at, base_elem)
        else:
            for base_elem in root_base_elements:
                if base_elem.text and base_elem.text.strip():
                    absolute = urllib.parse.urljoin(fallback_base_url, base_elem.text.strip())
                    base_elem.text = absolute

        # Una Representation con SegmentBase (o un sidecar WebVTT/TTML como
        # archivo único) descarga el medio desde su propia BaseURL. En ese caso
        # no existe SegmentTemplate donde inyectar la firma. Se firma sólo esa
        # hoja; las BaseURL que representan directorios conservan su jerarquía.
        parent_by_child = {
            child: parent for parent in root.iter() for child in list(parent)
        }
        media_extensions = (
            ".mp4", ".m4s", ".cmfv", ".cmfa", ".vtt", ".webvtt", ".ttml", ".xml"
        )
        for base_elem in root.iter():
            if _local_name(base_elem.tag) != "BaseURL" or not base_elem.text:
                continue
            text = base_elem.text.strip()
            parent = parent_by_child.get(base_elem)
            parent_tags = {_local_name(child.tag) for child in list(parent)} if parent is not None else set()
            path = urllib.parse.urlsplit(text).path.lower()
            is_media_leaf = "SegmentBase" in parent_tags or path.endswith(media_extensions)
            if is_media_leaf:
                base_elem.text = _merge_url_query(text, query)

        # 5. Propagar la firma a todos los tipos de referencia de segmentos. Si la
        # URL ya contiene parámetros (por ejemplo ``m=...``), se fusionan.
        for elem in root.iter():
            tag = _local_name(elem.tag)
            if tag == "SegmentTemplate":
                for attr in ("initialization", "media"):
                    val = elem.attrib.get(attr)
                    if val:
                        elem.attrib[attr] = _merge_url_query(val, query)
            elif tag == "SegmentURL":
                for attr in ("media", "initialization"):
                    val = elem.attrib.get(attr)
                    if val:
                        elem.attrib[attr] = _merge_url_query(val, query)
            elif tag in ("Initialization", "RepresentationIndex"):
                val = elem.attrib.get("sourceURL")
                if val:
                    elem.attrib["sourceURL"] = _merge_url_query(val, query)

        return ET.tostring(root, encoding="utf-8", xml_declaration=True)
    except Exception as e:
        logger.error("Error reescribiendo MPD de DGO: %s", e)
        raise RuntimeError(f"MPD DGO inválido o no reescribible: {e}") from e


_CLEARKEY_SCHEME_ID = "urn:uuid:1077efec-c0b2-4d02-ace3-3c1e52e2fb4b"
_DRM_SCHEME_MARKERS = (
    "edef8ba9-79d6-4ace-a3c8-27dcd51d21ed",  # Widevine
    "9a04f079-9840-4286-ab92-e65be0885f95",  # PlayReady
    "94ce86fb-07ff-4f43-adb8-93d2fa968ca2",  # FairPlay
)


def rewrite_mpd_content_protection_to_clearkey(
    mpd_bytes: bytes, default_kid: Optional[str] = None
) -> bytes:
    """Declara los AdaptationSets del MPD como ClearKey y quita Widevine/PlayReady/FairPlay.

    InputStream Adaptive con ``drm_legacy=org.w3.clearkey`` busca ContentProtection
    dentro de cada <AdaptationSet> (DASHTree.cpp). Se conserva el ContentProtection
    ``urn:mpeg:dash:mp4protection:2011`` (con su ``cenc:default_KID``) y se inyecta
    la señalización ClearKey directamente en cada <AdaptationSet> protegido.

    ``default_kid`` cubre los MPD de DGO que no declaran ``cenc:default_KID`` pero
    sí llevan el KID dentro del PSSH: sin ese atributo el manifiesto ClearKey no
    identifica la pista y algunos clientes no aplican la clave del M3U.
    """
    if isinstance(mpd_bytes, str):
        mpd_bytes = mpd_bytes.encode("utf-8")
    kid_clean = (default_kid or "").replace("-", "").strip().lower()
    if len(kid_clean) != 32:
        kid_clean = ""
    ET.register_namespace("", DASH_NAMESPACE)
    ET.register_namespace("cenc", "urn:mpeg:cenc:2013")
    root = ET.fromstring(mpd_bytes)
    removed = 0
    injected_count = 0

    # 1. Remover ContentProtection de Widevine/PlayReady/FairPlay en cualquier nivel
    for parent in list(root.iter()):
        for child in list(parent):
            if _local_name(child.tag) != "ContentProtection":
                continue
            scheme = (child.attrib.get("schemeIdUri") or "").lower()
            if any(marker in scheme for marker in _DRM_SCHEME_MARKERS):
                parent.remove(child)
                removed += 1

    # 2. Inyectar ClearKey en cada AdaptationSet que esté protegido
    if kid_clean:
        # Completar el KID que el MPD no declara pero sí viaja en el PSSH.
        for elem in root.iter():
            if _local_name(elem.tag) != "ContentProtection":
                continue
            scheme = (elem.attrib.get("schemeIdUri") or "").lower()
            if "mp4protection:2011" not in scheme:
                continue
            if elem.attrib.get(f"{{{CENC_NAMESPACE}}}default_KID") or elem.attrib.get("default_KID"):
                continue
            elem.set(f"{{{CENC_NAMESPACE}}}default_KID", kid_clean)
    for elem in root.iter():
        if _local_name(elem.tag) == "AdaptationSet":
            has_ck = False
            is_protected = False
            for child in elem:
                if _local_name(child.tag) == "ContentProtection":
                    scheme = (child.attrib.get("schemeIdUri") or "").lower()
                    if _CLEARKEY_SCHEME_ID in scheme:
                        has_ck = True
                    if "mp4protection:2011" in scheme or "cenc" in scheme:
                        is_protected = True
                elif _local_name(child.tag) == "Representation":
                    for rep_child in child:
                        if _local_name(rep_child.tag) == "ContentProtection":
                            r_scheme = (rep_child.attrib.get("schemeIdUri") or "").lower()
                            if _CLEARKEY_SCHEME_ID in r_scheme:
                                has_ck = True
                            if "mp4protection:2011" in r_scheme or "cenc" in r_scheme:
                                is_protected = True

            # Si el AdaptationSet está protegido (o tenía DRM) y no tiene ClearKey, inyectarlo
            if (is_protected or removed > 0) and not has_ck:
                ck_elem = ET.Element(f"{{{DASH_NAMESPACE}}}ContentProtection")
                ck_elem.set("schemeIdUri", _CLEARKEY_SCHEME_ID)
                ck_elem.set("value", "ClearKey")
                if kid_clean:
                    ck_elem.set(f"{{{CENC_NAMESPACE}}}default_KID", kid_clean)
                elem.insert(0, ck_elem)
                injected_count += 1

    # 3. Remover cualquier ContentProtection huérfano en la raíz <MPD>
    for child in list(root):
        if _local_name(child.tag) == "ContentProtection":
            root.remove(child)

    logger.info(
        "[IPTV DGO] MPD declarado como ClearKey (%d ContentProtection DRM removidos, %d inyectados en AdaptationSets)",
        removed,
        injected_count,
    )
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


class HTTPSKeepAlivePool:
    """Pool HTTP/1.1 acotado, concurrente por origen y sin reintentos POST."""

    def __init__(
        self,
        ssl_ctx: ssl.SSLContext,
        max_connections_per_origin: int = 2,
        idle_ttl: float = 55.0,
        max_response_bytes: int = 4 * 1024 * 1024,
    ):
        if max_connections_per_origin < 1:
            raise ValueError("max_connections_per_origin debe ser >= 1")
        self.ssl_ctx = ssl_ctx
        self._max_per_origin = max_connections_per_origin
        self._idle_ttl = idle_ttl
        self._max_response_bytes = max_response_bytes
        self._condition = threading.Condition()
        self._idle: Dict[
            Tuple[str, int], List[Tuple[http.client.HTTPSConnection, float, float]]
        ] = {}
        self._total: Dict[Tuple[str, int], int] = {}
        self._closed = False

    @staticmethod
    def _origin(url: str) -> Tuple[Tuple[str, int], str]:
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme.lower() != "https" or not parsed.hostname:
            raise ValueError(f"El pool sólo acepta URLs HTTPS válidas: {url!r}")
        if parsed.username is not None or parsed.password is not None:
            raise ValueError("No se permiten credenciales embebidas en la URL")
        port = parsed.port or 443
        path = parsed.path or "/"
        if parsed.query:
            path += "?" + parsed.query
        return (parsed.hostname, port), path

    def _new_connection(
        self, origin: Tuple[str, int], timeout: float
    ) -> http.client.HTTPSConnection:
        return http.client.HTTPSConnection(
            origin[0], origin[1], context=self.ssl_ctx, timeout=timeout
        )

    def _acquire(
        self, origin: Tuple[str, int], timeout: float
    ) -> http.client.HTTPSConnection:
        deadline = time.monotonic() + timeout
        with self._condition:
            while True:
                if self._closed:
                    raise RuntimeError("HTTPSKeepAlivePool cerrado")
                now = time.monotonic()
                idle = self._idle.setdefault(origin, [])
                while idle:
                    conn, released_mono, released_wall = idle.pop()
                    mono_age = now - released_mono
                    wall_age = time.time() - released_wall
                    # CLOCK_MONOTONIC puede no reflejar deep sleep en todos los
                    # kernels Android. El reloj civil es una segunda barrera
                    # conservadora: un salto horario sólo fuerza un TLS nuevo.
                    if (
                        0.0 <= mono_age <= self._idle_ttl
                        and 0.0 <= wall_age <= self._idle_ttl
                    ):
                        return conn
                    try:
                        conn.close()
                    finally:
                        self._total[origin] -= 1

                if self._total.get(origin, 0) < self._max_per_origin:
                    self._total[origin] = self._total.get(origin, 0) + 1
                    try:
                        return self._new_connection(origin, timeout)
                    except Exception:
                        self._total[origin] -= 1
                        if self._total[origin] == 0:
                            self._total.pop(origin, None)
                            self._idle.pop(origin, None)
                        self._condition.notify()
                        raise

                remaining = deadline - now
                if remaining <= 0:
                    raise TimeoutError(f"Timeout esperando conexión HTTPS para {origin[0]}")
                self._condition.wait(remaining)

    def _release(
        self,
        origin: Tuple[str, int],
        conn: http.client.HTTPSConnection,
        reusable: bool,
    ) -> None:
        close_conn = False
        with self._condition:
            if self._closed or not reusable:
                self._total[origin] = max(0, self._total.get(origin, 1) - 1)
                if self._total[origin] == 0:
                    self._total.pop(origin, None)
                    self._idle.pop(origin, None)
                close_conn = True
            else:
                self._idle.setdefault(origin, []).append(
                    (conn, time.monotonic(), time.time())
                )
            self._condition.notify()
        if close_conn:
            try:
                conn.close()
            except Exception:
                pass

    def _read_limited(self, response: http.client.HTTPResponse) -> bytes:
        chunks: List[bytes] = []
        total = 0
        while True:
            chunk = response.read(min(65536, self._max_response_bytes + 1 - total))
            if not chunk:
                return b"".join(chunks)
            chunks.append(chunk)
            total += len(chunk)
            if total > self._max_response_bytes:
                raise ValueError("Respuesta HTTPS excede el límite configurado")

    def request(
        self,
        method: str,
        url: str,
        data: Optional[bytes] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: float = 8.0,
        retry_stale: Optional[bool] = None,
    ) -> Tuple[int, bytes, Dict[str, str]]:
        origin, path = self._origin(url)
        method = method.upper()
        req_headers = dict(headers or {})
        # Repetir un POST después de RemoteDisconnected puede duplicar una sesión,
        # rotación OAuth o licencia ya procesada por el servidor.
        may_retry = method in ("GET", "HEAD", "OPTIONS") if retry_stale is None else retry_stale
        attempts = 2 if may_retry else 1
        deadline = time.monotonic() + timeout

        attempt = 0
        while attempt < attempts:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError(f"Timeout HTTPS total para {origin[0]}")
            conn = self._acquire(origin, remaining)
            response: Optional[http.client.HTTPResponse] = None
            reusable = False
            try:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError(f"Timeout HTTPS total para {origin[0]}")
                conn.timeout = remaining
                if conn.sock is not None:
                    conn.sock.settimeout(remaining)
                conn.request(method, path, body=data, headers=req_headers)
                response = conn.getresponse()
                resp_data = self._read_limited(response)
                resp_headers = {k.lower(): v for k, v in response.getheaders()}
                reusable = not response.will_close and resp_headers.get(
                    "connection", ""
                ).lower() != "close"
                status = response.status
            except Exception as error:
                self._release(origin, conn, False)
                # Un gaierror ocurre antes de abrir el socket: repetir una vez
                # también es seguro para POST. Fallas ambiguas posteriores al
                # envío siguen sin repetirse para evitar duplicar sesiones.
                if isinstance(error, socket.gaierror) and attempts == 1:
                    attempts = 2
                attempt += 1
                if attempt >= attempts:
                    raise
                backoff = min(0.20 * (2 ** (attempt - 1)), max(0.0, deadline - time.monotonic()))
                if backoff > 0:
                    time.sleep(backoff)
                continue
            finally:
                if response is not None:
                    response.close()

            self._release(origin, conn, reusable)
            if status >= 400:
                raise urllib.error.HTTPError(
                    url, status, f"HTTP {status}", resp_headers, io.BytesIO(resp_data)
                )
            return status, resp_data, resp_headers

        raise RuntimeError(f"Fallo de conexión persistente a {origin[0]}")

    def close(self):
        with self._condition:
            self._closed = True
            connections = [conn for values in self._idle.values() for conn, _, _ in values]
            self._idle.clear()
            self._total.clear()
            self._condition.notify_all()
        for conn in connections:
            try:
                conn.close()
            except Exception:
                pass


class DgoSessionResolver:
    """Resuelve URLs DASH firmadas de DGO y gestiona el proxy local de licencias Widevine CPIX."""

    AUTHORIZER_ENDPOINT = "https://api.directvgo.com/entitlement/v3/playback/token/authorizer"
    CPIX_LICENSE_ENDPOINT = "https://cpix.tbxdrm.com/v1/license/dtvgo/widevine"
    TBX_TOKEN_ENDPOINT = "https://dtv-oidc.tbxapis.com/v2/oauth2/token"
    MSO_TOKEN_ENDPOINT = "https://sm-dgo.vrioservices.com/v3/oauth2/token"
    TBX_BASIC_AUTH = "Basic ZHR2Z286TmQza1lhaUVHOA=="
    TBX_API_KEY = "WcXcCsd4ytXMUss28BUG9GTglAjT"
    SAFETY_MARGIN_SECONDS = 120.0
    DEFAULT_DRM_TTL = 3000.0
    DEFAULT_STREAM_TTL = 1800.0
    DRM_REFRESH_AHEAD_SECONDS = 300.0
    # Renovación proactiva del id_token aunque no haya reproducción: mantiene
    # viva la sesión de un dispositivo encendido sin zapping.
    SESSION_RENEW_AHEAD_SECONDS = 2 * 3600.0
    SESSION_RENEW_MIN_INTERVAL_SECONDS = 900.0
    DRM_ACTIVITY_WINDOW_SECONDS = 2 * 3600.0
    MAX_MANIFEST_CACHE_ENTRIES = 8
    AUTHORIZER_TIMEOUT_SECONDS = 7.0
    CPIX_TIMEOUT_SECONDS = 5.0
    MANIFEST_TIMEOUT_SECONDS = 4.0

    def __init__(self, credentials_path: Optional[str] = None):
        self._credentials_path = credentials_path
        # ``slug:manifest_type`` -> (manifest_url, monotonic_deadline)
        self._stream_cache: Dict[str, Tuple[str, float]] = {}
        # slug -> (signed_stream_url, rewritten_mpd_bytes, monotonic_deadline)
        self._manifest_cache: Dict[str, Tuple[str, bytes, float]] = {}
        # drm_id (lower) -> (bearer_token, monotonic_deadline)
        self._drm_token_cache: Dict[str, Tuple[str, float]] = {}
        # drm_id -> último uso; sólo estos tokens se renuevan anticipadamente.
        self._drm_activity: Dict[str, float] = {}
        self._cache_lock = threading.RLock()
        self._renew_lock = threading.RLock()
        self._credentials_lock = threading.RLock()
        self._flight_guard = threading.Lock()
        self._flight_locks: Dict[str, threading.Lock] = {}
        self._server_clock_offset = 0.0
        self._maintenance_guard = threading.Lock()
        self._maintenance_thread: Optional[threading.Thread] = None
        self._closed = False

        self.ssl_ctx = ssl.create_default_context()
        self._http_pool = HTTPSKeepAlivePool(self.ssl_ctx)
        self._last_bootstrap_attempt: float = 0.0
        self._last_remote_adoption_attempt: float = 0.0
        self._pending_post_bootstrap_renew = False
        # Estado de sesión: si el refresh token muere, el dispositivo requiere
        # un re-enrolamiento (device-code) y hay que avisarlo una sola vez.
        self._reauth_required = False
        self._reauth_reason = ""
        self._reauth_since = 0.0
        self._reauth_notified_at = 0.0
        self._last_session_renew_attempt = 0.0
        # Bóveda ClearKey: se lee del disco una sola vez por versión de archivo.
        # Antes se parseaba el JSON en cada request (y en cada chequeo de DRM).
        self._vault_lock = threading.Lock()
        self._vault_cache: Optional[Tuple[Tuple[str, int, int], Dict[str, str]]] = None

    def close(self) -> None:
        self._closed = True
        self._http_pool.close()

    def _flight_lock(self, key: str) -> threading.Lock:
        with self._flight_guard:
            return self._flight_locks.setdefault(key, threading.Lock())

    def _set_reauth_required(self, reason: str, quiet: bool = False) -> None:
        """Marca la sesión como irrecuperable localmente y avisa una sola vez.

        ``quiet`` lo usa el publicador cuando ya tiene un re-enrolamiento listo:
        evita el error rojo y la notificación por un rechazo que se resuelve
        inmediatamente después con la sesión web.
        """
        first = not self._reauth_required
        self._reauth_required = True
        self._reauth_reason = reason
        if first:
            self._reauth_since = self._server_time()
            if quiet:
                return
            logger.error("[IPTV DGO] Sesión requiere re-enrolamiento: %s", reason)
            try:
                import xbmc
                xbmc.executebuiltin(
                    "Notification(DGO,Sesión DGO vencida: re-enrolar dispositivo,8000)"
                )
            except Exception:
                pass

    def _clear_reauth_required(self) -> None:
        if self._reauth_required:
            logger.info("[IPTV DGO] Sesión recuperada: se limpia el estado REAUTH_REQUIRED.")
        self._reauth_required = False
        self._reauth_reason = ""
        self._reauth_since = 0.0

    def session_status(self) -> Dict[str, Any]:
        """Estado de sesión sin exponer tokens (para health/diagnóstico)."""
        exp: Optional[int] = None
        has_refresh = False
        issuer = ""
        device_id = ""
        try:
            creds = self.load_credentials()
            token = str(creds.get("id_token") or "")
            exp = _extract_jwt_exp(token)
            has_refresh = bool(str(creds.get("refresh_token") or "").strip())
            issuer = str(_extract_jwt_payload(token).get("iss") or "")
            device_id = str(creds.get("device_id") or "")
        except Exception as error:  # noqa: BLE001
            logger.debug("[IPTV DGO] No se pudo leer el estado de sesión: %s", error)
        now = self._server_time()
        remaining = max(0, int(exp - now)) if exp else None
        return {
            "provider": "dgo",
            "reauth_required": self._reauth_required,
            "reauth_reason": self._reauth_reason,
            "reauth_since": self._reauth_since or None,
            "authenticated": bool(exp and exp > now),
            "expires_in": remaining,
            "has_refresh_token": has_refresh,
            "issuer": issuer,
            "device_id_prefix": device_id[:16],
        }

    def warmup(self) -> None:
        """Carga credenciales y renueva el id_token antes del primer zapping."""
        if self._credentials_path is None:
            self._bootstrap_remote_credentials(only_if_newer=True)
        creds = self.load_credentials()
        exp = _extract_jwt_exp(creds.get("id_token", ""))
        if exp and (exp - self._server_time()) < 15 * 60 and self._is_session_owner():
            self.renew_session()

    def maintenance(self) -> None:
        """Agenda mantenimiento sin bloquear el hilo principal del servicio Kodi."""
        if self._closed:
            return
        with self._maintenance_guard:
            if self._maintenance_thread and self._maintenance_thread.is_alive():
                return
            worker = threading.Thread(
                target=self._run_maintenance,
                name="flowproxy-dgo-maintenance",
                daemon=True,
            )
            self._maintenance_thread = worker
            worker.start()

    def _run_maintenance(self) -> None:
        """Renueva tokens DRM activos antes de que ISA solicite otra licencia."""
        now = time.monotonic()
        if (
            self._credentials_path is None
            and now - self._last_remote_adoption_attempt >= 15 * 60
        ):
            self._last_remote_adoption_attempt = now
            self._bootstrap_remote_credentials(only_if_newer=True)
        with self._cache_lock:
            active = [
                drm_id
                for drm_id, last_used in self._drm_activity.items()
                if now - last_used <= self.DRM_ACTIVITY_WINDOW_SECONDS
                and (
                    drm_id not in self._drm_token_cache
                    or self._drm_token_cache[drm_id][1] - now
                    <= self.DRM_REFRESH_AHEAD_SECONDS
                )
            ]
            self._drm_activity = {
                drm_id: last_used
                for drm_id, last_used in self._drm_activity.items()
                if now - last_used <= self.DRM_ACTIVITY_WINDOW_SECONDS
            }

        # Renovación proactiva SIEMPRE (haya o no actividad): un dispositivo
        # encendido pero sin zapping no debe perder la sesión por inanición.
        if not self._closed:
            try:
                creds = self.load_credentials()
                exp = _extract_jwt_exp(creds.get("id_token", ""))
                remaining = (exp - self._server_time()) if exp else None
                if (
                    remaining is not None
                    and remaining < self.SESSION_RENEW_AHEAD_SECONDS
                    and self._is_session_owner()
                ):
                    if (
                        now - self._last_session_renew_attempt
                        >= self.SESSION_RENEW_MIN_INTERVAL_SECONDS
                    ):
                        self._last_session_renew_attempt = now
                        logger.info(
                            "[IPTV DGO] id_token vence en %.1f h. Renovación proactiva en background.",
                            remaining / 3600.0,
                        )
                        self.renew_session()
            except Exception as error:
                logger.warning("[IPTV DGO] Sesión pendiente de renovación: %s", error)

        for drm_id in active:
            if self._closed:
                return
            slug = DRM_ID_TO_SLUG.get(drm_id)
            if not slug:
                continue
            try:
                self._refresh_drm_authorization(slug)
                logger.info("[IPTV DGO] Token DRM renovado anticipadamente para %s", drm_id)
            except Exception as error:
                # La entrada anterior no se elimina: la reproducción conserva
                # su última autorización y se reintentará en el próximo ciclo.
                logger.warning(
                    "[IPTV DGO] Renovación DRM anticipada pendiente para %s: %s",
                    drm_id,
                    error,
                )

    def _refresh_drm_authorization(self, slug: str) -> None:
        """Actualiza el Bearer DRM sin cambiar una sesión MPD aún utilizable."""
        cache_key = f"{slug}:dash"
        # Mantener el single-flight hasta restaurar la URL anterior evita que un
        # get_manifest concurrente observe por un instante la sesión de refresh.
        with self._flight_lock("stream:" + cache_key):
            with self._cache_lock:
                previous_stream = self._stream_cache.get(cache_key)
            refreshed_url = self._get_stream_url_serialized(slug, "dash", True)
            if previous_stream and time.monotonic() < previous_stream[1]:
                with self._cache_lock:
                    current = self._stream_cache.get(cache_key)
                    if current and current[0] == refreshed_url:
                        self._stream_cache[cache_key] = previous_stream

    def _server_time(self) -> float:
        with self._cache_lock:
            return time.time() + self._server_clock_offset

    def _update_server_time(self, headers: Dict[str, str]) -> None:
        date_value = headers.get("date")
        if not date_value:
            return
        try:
            server_dt = email.utils.parsedate_to_datetime(date_value)
            offset = server_dt.timestamp() - time.time()
        except (TypeError, ValueError, OverflowError):
            return
        # Evita aceptar una cabecera corrupta como fuente horaria.
        if abs(offset) <= 24 * 3600:
            with self._cache_lock:
                self._server_clock_offset = offset

    @staticmethod
    def _write_credentials_atomic(path: Path, creds: Dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, temp_name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
        try:
            try:
                os.fchmod(fd, 0o600)
            except (AttributeError, OSError):
                pass
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                fd = -1
                json.dump(creds, handle, indent=2)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_name, path)
        finally:
            if fd >= 0:
                os.close(fd)
            try:
                if os.path.exists(temp_name):
                    os.unlink(temp_name)
            except OSError:
                pass

    def _provision_tv_session_from_web(self, web_creds: Dict[str, Any]) -> Dict[str, Any]:
        """Canjea una sesión web por una sesión TV renovable y única para este Kodi."""
        device_id = f"kodi-{uuid.uuid4().hex[:16]}"
        headers = {
            "Authorization": self.TBX_BASIC_AUTH,
            "Content-Type": "application/json",
            "x-device-id": device_id,
            "x-client-id": web_creds.get("client_id", "web"),
            "x-client-version": web_creds.get("client_version", "3.69.0"),
            "x-environment": web_creds.get("environment", "prd"),
            "x-app": web_creds.get("app", "dgo"),
            "Origin": "https://www.directvgo.com",
            "Referer": "https://www.directvgo.com/",
            "User-Agent": USER_AGENT,
        }
        profile_token = str(web_creds.get("profile_token") or "").strip()
        if profile_token:
            headers["x-profile-token"] = profile_token

        def post(path: str, payload: Dict[str, Any], extra_headers=None) -> Dict[str, Any]:
            request_headers = dict(headers)
            request_headers.update(extra_headers or {})
            request = urllib.request.Request(
                "https://dtv-oidc.tbxapis.com" + path,
                data=json.dumps(payload).encode("utf-8"),
                headers=request_headers,
                method="POST",
            )
            with urllib.request.urlopen(request, timeout=12.0, context=self.ssl_ctx) as response:
                result = json.loads(response.read().decode("utf-8"))
            if not isinstance(result, dict):
                raise RuntimeError(f"Respuesta DGO TV inválida para {path}")
            return result

        device = post(
            "/v2/tv/device/code",
            {"responseType": "deviceCode", "region": "ssla"},
        )
        device_code = device.get("device_code") or device.get("deviceCode")
        user_code = device.get("user_code") or device.get("userCode")
        if not device_code or not user_code:
            raise RuntimeError("DGO no devolvió los códigos de activación TV")

        web_id_token = str(web_creds.get("id_token") or "").strip()
        if not web_id_token:
            raise RuntimeError("La credencial web de DGO no contiene id_token")
        post(
            "/v2/tv/activation",
            {"userCode": user_code},
            {"ssoToken": web_id_token},
        )
        tv_tokens = post(
            "/v2/oauth2/token",
            {"grantType": "deviceToken", "code": device_code},
        )
        if not tv_tokens.get("id_token") or not tv_tokens.get("refresh_token"):
            raise RuntimeError("DGO no devolvió una sesión TV renovable")

        provisioned = dict(web_creds)
        provisioned.update(tv_tokens)
        provisioned["device_id"] = device_id
        provisioned["provenance"] = "dgo_tv_device_activation"
        exp = _extract_jwt_exp(str(tv_tokens.get("id_token") or ""))
        if exp:
            provisioned["exp"] = exp
        return provisioned

    def _bootstrap_remote_credentials(self, only_if_newer: bool = False) -> Optional[Path]:
        with self._credentials_lock:
            result = self._bootstrap_remote_credentials_unlocked(only_if_newer=only_if_newer)
            pending_renew = self._pending_post_bootstrap_renew
            self._pending_post_bootstrap_renew = False
        # La renovación corre fuera de _credentials_lock para no invertir el
        # orden de locks con renew_session() (renew_lock -> credentials_lock).
        # Solo el propietario de la sesión renueva; un consumidor jamás rota el token compartido.
        if pending_renew and self._is_session_owner():
            logger.info("[IPTV DGO] Token bootstrap próximo a expirar o expirado. Renovando inmediatamente...")
            try:
                self.renew_session()
            except Exception as ren_err:
                logger.warning("[IPTV DGO] Renovación inmediata post-bootstrap falló: %s", ren_err)
        return result

    def _bootstrap_remote_credentials_unlocked(
        self, only_if_newer: bool = False
    ) -> Optional[Path]:
        """Descarga credenciales remotas y, opcionalmente, adopta sólo una sesión más nueva."""
        now = time.monotonic()
        if (now - self._last_bootstrap_attempt) < 30.0:
            return None
        self._last_bootstrap_attempt = now

        try:
            logger.info("[IPTV DGO] No se encontraron credenciales locales. Intentando bootstrap seguro desde Secret Gist...")
            req = urllib.request.Request(
                DEFAULT_GIST_BOOTSTRAP_URL,
                headers={"User-Agent": USER_AGENT},
            )
            with urllib.request.urlopen(req, timeout=12.0, context=self.ssl_ctx) as resp:
                data = resp.read().decode("utf-8").strip()

            raw_bytes = _deobfuscate_credentials(data)
            creds = json.loads(raw_bytes.decode("utf-8"))
            if not isinstance(creds, dict) or not creds.get("refresh_token"):
                logger.error("[IPTV DGO] Payload remoto de credenciales inválido (falta refresh_token).")
                return None

            # Determinar carpeta de destino con permisos de escritura
            target_file: Optional[Path] = None
            profile_dir = _get_addon_profile_dir()
            if profile_dir:
                try:
                    profile_dir.mkdir(parents=True, exist_ok=True)
                    target_file = profile_dir / "dgo_credentials.json"
                except Exception as e:
                    logger.warning("[IPTV DGO] No se pudo crear profile_dir %s: %s", profile_dir, e)

            if not target_file:
                for candidate_dir in [
                    Path.home() / ".flow_cache",
                    Path("/storage/emulated/0/Download"),
                    Path("/sdcard/Download"),
                ]:
                    try:
                        if candidate_dir.is_dir() or candidate_dir.parent.is_dir():
                            candidate_dir.mkdir(parents=True, exist_ok=True)
                            target_file = candidate_dir / "dgo_credentials.json"
                            break
                    except Exception:
                        pass

            if not target_file:
                target_file = Path("/tmp") / "dgo_credentials.json"

            if only_if_newer and target_file.is_file():
                try:
                    local_creds = json.loads(target_file.read_text(encoding="utf-8"))
                    remote_claims = _extract_jwt_payload(creds.get("id_token", ""))
                    local_claims = _extract_jwt_payload(local_creds.get("id_token", ""))
                    remote_rank = (
                        int(remote_claims.get("exp") or 0),
                        int(remote_claims.get("iat") or 0),
                    )
                    local_rank = (
                        int(local_claims.get("exp") or 0),
                        int(local_claims.get("iat") or 0),
                    )
                    if remote_rank <= local_rank:
                        logger.debug(
                            "[IPTV DGO] La sesión remota no es más nueva; se conserva la copia local."
                        )
                        return target_file
                except Exception as compare_error:
                    logger.warning(
                        "[IPTV DGO] No se pudo comparar la sesión local con la remota: %s",
                        compare_error,
                    )

            remote_issuer = str(
                _extract_jwt_payload(creds.get("id_token", "")).get("iss") or ""
            ).lower()
            if "sm-dgo.vrioservices.com" in remote_issuer:
                try:
                    creds = self._provision_tv_session_from_web(creds)
                    logger.info(
                        "[IPTV DGO] Sesión web convertida automáticamente en sesión TV independiente."
                    )
                except Exception as provision_error:
                    logger.warning(
                        "[IPTV DGO] No se pudo crear la sesión TV independiente; se conserva el bootstrap web: %s",
                        provision_error,
                    )

            # Asignar un device_id único persistente para este dispositivo.
            if not creds.get("device_id") or creds.get("device_id") == "kodi-flowproxy-primary":
                creds["device_id"] = f"kodi-{uuid.uuid4().hex[:16]}"

            self._write_credentials_atomic(target_file, creds)

            logger.info("[IPTV DGO] ¡Credenciales DGO configuradas automáticamente desde Secret Gist en %s!", target_file)
            try:
                import xbmc
                xbmc.executebuiltin('Notification(DGO,Credenciales DGO configuradas automáticamente,3500)')
            except Exception:
                pass

            # Si el token descargado está próximo a expirar (<2h) o expiró, se
            # agenda la renovación. No se ejecuta aquí para no tomar _renew_lock
            # mientras se retiene _credentials_lock.
            exp = _extract_jwt_exp(creds.get("id_token", ""))
            if not exp or (exp - time.time()) < 7200.0:
                self._pending_post_bootstrap_renew = True

            return target_file
        except Exception as e:
            logger.warning("[IPTV DGO] No se pudo descargar las credenciales remotas: %s", e)
            return None

    def _is_session_owner(self) -> bool:
        """True si este resolver es dueño de la sesión (PC única escritora).

        El device se construye sin ``credentials_path`` y es consumidor: adopta
        la sesión publicada pero NUNCA rota el refresh_token compartido.
        """
        return self._credentials_path is not None

    def _adopt_newer_remote_session(self) -> bool:
        """Adopta la sesión publicada más reciente sin rotar el refresh_token.

        La PC es el único escritor del refresh_token rotativo. Los dispositivos
        adoptan la sesión publicada (Gist) bajo demanda para no invalidar el
        token de la PC con una rotación propia.
        """
        try:
            path = self._bootstrap_remote_credentials(only_if_newer=True)
        except Exception as error:  # noqa: BLE001
            logger.debug("[IPTV DGO] Adopción remota de sesión no disponible: %s", error)
            return False
        if not path:
            return False
        try:
            creds = json.loads(Path(path).read_text(encoding="utf-8"))
        except Exception:
            return False
        exp = _extract_jwt_exp(creds.get("id_token", ""))
        if exp and (exp - self._server_time()) > 300:
            self._clear_reauth_required()
            logger.info(
                "[IPTV DGO] Sesión adoptada desde el Gist (vence en %.1f h).",
                (exp - self._server_time()) / 3600.0,
            )
            return True
        return False

    def _find_credentials_file(self) -> Optional[Path]:
        """Localiza el archivo de credenciales en orden de prioridad."""
        if self._credentials_path:
            p = Path(self._credentials_path)
            if p.is_file():
                return p

        # 1. En Kodi userdata si está disponible
        profile_dir = _get_addon_profile_dir()
        if profile_dir:
            kodi_creds = profile_dir / "dgo_credentials.json"
            if kodi_creds.is_file():
                return kodi_creds

        # 2. En ~/.flow_cache/dgo_credentials.json (Linux / sistema)
        flow_cache_creds = Path.home() / ".flow_cache" / "dgo_credentials.json"
        if flow_cache_creds.is_file():
            return flow_cache_creds

        # 3. En Android: buscar en carpetas compartidas de almacenamiento (Download / sdcard)
        for android_candidate in [
            Path("/storage/emulated/0/Download/dgo_credentials.json"),
            Path("/sdcard/Download/dgo_credentials.json"),
            Path("/storage/emulated/0/dgo_credentials.json"),
            Path("/sdcard/dgo_credentials.json"),
        ]:
            if android_candidate.is_file():
                # Auto-migrar hacia el perfil de Kodi si no existe aún
                if profile_dir:
                    try:
                        import shutil
                        profile_dir.mkdir(parents=True, exist_ok=True)
                        kodi_target = profile_dir / "dgo_credentials.json"
                        if not kodi_target.is_file():
                            shutil.copy2(android_candidate, kodi_target)
                            logger.info("[IPTV DGO] Credenciales auto-importadas desde %s a %s", android_candidate, kodi_target)
                            return kodi_target
                    except Exception as e:
                        logger.warning("[IPTV DGO] No se pudo auto-migrar credenciales a %s: %s", profile_dir, e)
                return android_candidate

        # 4. En la propia carpeta del addon (desarrollo local)
        local_creds = Path(__file__).resolve().parent / "dgo_credentials.local.json"
        if local_creds.is_file():
            return local_creds

        # 5. Bootstrap remoto automático desde Secret Gist si no existen localmente
        return self._bootstrap_remote_credentials()

    def _ensure_device_id(self, creds: Dict[str, Any], creds_file: Optional[Path] = None) -> str:
        """Asegura un device_id único y persistente por dispositivo/perfil, previniendo colisiones de sesión."""
        current_id = creds.get("device_id")
        if current_id and current_id != "kodi-flowproxy-primary" and str(current_id).strip():
            return str(current_id).strip()

        with self._credentials_lock:
            current_id = creds.get("device_id")
            if current_id and current_id != "kodi-flowproxy-primary" and str(current_id).strip():
                return str(current_id).strip()

            unique_id = f"kodi-{uuid.uuid4().hex[:16]}"
            creds["device_id"] = unique_id
            if creds_file and creds_file.is_file():
                try:
                    # Volver a leer bajo el mismo lock evita pisar una rotación de
                    # refresh_token realizada por otro hilo.
                    latest = json.loads(creds_file.read_text(encoding="utf-8"))
                    disk_id = str(latest.get("device_id") or "").strip()
                    if disk_id and disk_id != "kodi-flowproxy-primary":
                        creds["device_id"] = disk_id
                        return disk_id
                    latest.update(creds)
                    self._write_credentials_atomic(creds_file, latest)
                    logger.info("[IPTV DGO] Generado y persistido nuevo device_id único para este dispositivo: %s", unique_id)
                except Exception as e:
                    logger.warning("[IPTV DGO] No se pudo persistir el device_id en %s: %s", creds_file, e)
            return unique_id

    def load_credentials(self) -> Dict[str, str]:
        """Carga las credenciales activas de DGO."""
        creds_file = self._find_credentials_file()
        if not creds_file:
            raise FileNotFoundError(
                "No se encontró el archivo de credenciales de DGO (dgo_credentials.json)"
            )
        with self._credentials_lock:
            try:
                creds = json.loads(creds_file.read_text(encoding="utf-8"))
            except Exception as e:
                raise RuntimeError(f"Error leyendo credenciales de DGO desde {creds_file}: {e}")
            self._ensure_device_id(creds, creds_file)
            return creds

    def renew_session(self, quiet: bool = False) -> bool:
        """Serializa la rotación del refresh token entre hilos del servidor.

        ``quiet`` evita registrar como error un rechazo que el llamador ya sabe
        resolver con un re-enrolamiento (publicador de credenciales).
        """
        with self._renew_lock:
            return self._renew_session_unlocked(quiet=quiet)

    def _renew_session_unlocked(self, quiet: bool = False) -> bool:
        """Renueva de forma autónoma el id_token usando el refresh_token almacenado."""
        creds_file = self._find_credentials_file()
        if not creds_file:
            logger.error("[IPTV DGO] No se puede renovar sesión: archivo de credenciales no encontrado.")
            self._set_reauth_required("credenciales_no_encontradas")
            return False

        try:
            creds = json.loads(creds_file.read_text(encoding="utf-8"))
        except Exception as e:
            logger.error("[IPTV DGO] Error leyendo credenciales para renovación: %s", e)
            return False

        refresh_token = creds.get("refresh_token", "").strip()
        if not refresh_token:
            logger.warning("[IPTV DGO] No hay 'refresh_token' disponible en las credenciales.")
            self._set_reauth_required("refresh_token_ausente")
            return False

        device_id = creds.get("device_id") or "kodi-flowproxy-primary"
        id_claims = _extract_jwt_payload(creds.get("id_token", ""))
        token_issuer = str(id_claims.get("iss") or "").lower()
        uses_mso_v3 = "sm-dgo.vrioservices.com" in token_issuer
        if uses_mso_v3 and id_claims.get("deviceId"):
            # El Login Service de MSO v3 exige el deviceId registrado en id_token
            # (y no el tbxDeviceId del refresh_token).
            device_id = str(id_claims["deviceId"]).strip()

        req_headers = {
            "Content-Type": "application/json",
            "x-device-id": device_id,
            "x-client-type": "web",
            "x-client-id": creds.get("client_id", "web"),
            "x-client-version": creds.get("client_version", "3.69.0"),
            "x-environment": creds.get("environment", "prd"),
            "x-app": creds.get("app", "dgo"),
            "User-Agent": USER_AGENT,
        }
        token_endpoint = self.TBX_TOKEN_ENDPOINT
        if uses_mso_v3:
            token_endpoint = self.MSO_TOKEN_ENDPOINT
            req_headers["Origin"] = "https://www.directvgo.com"
            req_headers["Referer"] = "https://www.directvgo.com/"
            business_unit = str(id_claims.get("businessUnit") or "").strip()
            mso_provider = str(id_claims.get("msoProvider") or "").strip()
            if business_unit:
                req_headers["x-business-unit-type"] = business_unit
            if mso_provider and "mso" in business_unit.lower():
                req_headers["x-mso-provider"] = mso_provider
            profile_token = str(creds.get("profile_token") or "").strip()
            if profile_token:
                req_headers["x-profile-token"] = profile_token
        else:
            req_headers["Authorization"] = self.TBX_BASIC_AUTH
            req_headers["x-api-key"] = self.TBX_API_KEY

        payload = json.dumps({
            "grantType": "refreshToken",
            "refreshToken": refresh_token,
            "region": "ssla",
        }).encode("utf-8")

        req = urllib.request.Request(
            token_endpoint,
            data=payload,
            headers=req_headers,
            method="POST",
        )

        try:
            with urllib.request.urlopen(req, timeout=12.0, context=self.ssl_ctx) as resp:
                response_headers = {
                    key.lower(): value for key, value in getattr(resp, "headers", {}).items()
                }
                data = json.loads(resp.read().decode("utf-8"))
            self._update_server_time(response_headers)
        except urllib.error.HTTPError as e:
            e.read()
            e.close()
            # Nunca registrar el cuerpo de la respuesta de autenticación: puede
            # contener tokens. Solo se expone el código HTTP.
            if not quiet:
                logger.error("[IPTV DGO] Error HTTP al renovar token (%s). Cuerpo omitido.", e.code)
            # 400/401/403 = refresh token revocado o inválido -> irreversible
            # sin re-enrolamiento. 429/5xx son transitorios.
            if e.code in (400, 401, 403):
                self._set_reauth_required(f"refresh_rechazado_http_{e.code}", quiet=quiet)
            return False
        except Exception as e:
            logger.error("[IPTV DGO] Excepción de red al renovar token: %s", e)
            return False

        new_access_token = data.get("access_token")
        new_id_token = data.get("id_token")
        new_refresh_token = data.get("refresh_token")
        if not new_id_token:
            # No volcar el objeto completo: puede incluir access/refresh tokens.
            if not quiet:
                logger.error(
                    "[IPTV DGO] Respuesta de renovación sin 'id_token'. Claves: %s",
                    sorted(data.keys()),
                )
            self._set_reauth_required("respuesta_sin_id_token", quiet=quiet)
            return False

        creds["id_token"] = new_id_token
        if new_access_token:
            creds["access_token"] = new_access_token
        if new_refresh_token:
            creds["refresh_token"] = new_refresh_token
        if data.get("expires_in"):
            creds["expires_in"] = data["expires_in"]

        new_exp = _extract_jwt_exp(new_id_token)
        if new_exp:
            creds["exp"] = new_exp

        try:
            with self._credentials_lock:
                # Preservar campos que pudieron cambiar mientras la red estaba en vuelo.
                latest = json.loads(creds_file.read_text(encoding="utf-8"))
                latest["id_token"] = new_id_token
                if new_access_token:
                    latest["access_token"] = new_access_token
                if new_refresh_token:
                    latest["refresh_token"] = new_refresh_token
                if data.get("expires_in"):
                    latest["expires_in"] = data["expires_in"]
                if new_exp:
                    latest["exp"] = new_exp
                creds = latest
                self._write_credentials_atomic(creds_file, creds)

                if self._credentials_path is None:
                    flow_cache_creds = Path.home() / ".flow_cache" / "dgo_credentials.json"
                    if creds_file.resolve() != flow_cache_creds.resolve() and flow_cache_creds.parent.is_dir():
                        self._write_credentials_atomic(flow_cache_creds, creds)

            self._clear_reauth_required()
            logger.info("[IPTV DGO] ¡Sesión renovada con éxito! Nuevo id_token guardado atómicamente.")
            try:
                import xbmc
                xbmc.executebuiltin('Notification(DGO,Sesión renovada automáticamente,3000)')
            except Exception:
                pass
            return True
        except Exception as e:
            logger.error("[IPTV DGO] Error guardando credenciales renovadas: %s", e)
            return False

    def _build_request_headers(self, creds: Dict[str, str], auto_renew: bool = True) -> Dict[str, str]:
        """Construye las cabeceras exactas para la API de DGO, renovando proactivamente si expira pronto."""
        id_token = creds.get("id_token", "").strip()
        profile_token = creds.get("profile_token", "").strip()
        if not id_token:
            raise ValueError("Falta 'id_token' en las credenciales de DGO")

        exp = _extract_jwt_exp(id_token)
        if exp:
            rem_hours = (exp - self._server_time()) / 3600.0
            if rem_hours <= 0 or rem_hours < 2.0:
                if rem_hours <= 0:
                    logger.error("[IPTV DGO] ¡id_token ha EXPIRADO! Adoptando sesión publicada...")
                else:
                    logger.info("[IPTV DGO] id_token vence en %.1f h. Adoptando sesión publicada...", rem_hours)
                if auto_renew:
                    if self._adopt_newer_remote_session():
                        creds = self.load_credentials()
                        id_token = creds.get("id_token", "").strip()
                    elif self._is_session_owner() and self.renew_session():
                        creds = self.load_credentials()
                        id_token = creds.get("id_token", "").strip()
                    elif not self._is_session_owner() and rem_hours <= 0:
                        # Consumidor: nunca rota la sesión compartida; fallo limpio.
                        self._set_reauth_required("sesion_compartida_sin_publicacion_vigente")
            elif rem_hours < 6.0:
                logger.info("[IPTV DGO] id_token expira en %.1f horas. Sesión protegida por auto-renovación.", rem_hours)

        headers = {
            "authorization": f"Bearer {id_token}",
            "x-environment": creds.get("environment", "prd"),
            "x-app": creds.get("app", "dgo"),
            "x-client-id": creds.get("client_id", "web"),
            "x-client-version": creds.get("client_version", "3.69.0"),
            "content-type": "application/json",
            "origin": "https://www.directvgo.com",
            "referer": "https://www.directvgo.com/",
            "user-agent": USER_AGENT,
        }
        device_id = creds.get("device_id")
        if device_id:
            headers["x-device-id"] = device_id
        if profile_token:
            headers["x-profile-token"] = profile_token
        return headers

    def get_stream_url(
        self,
        slug: str,
        manifest_type: Optional[str] = None,
        force_refresh: bool = False,
    ) -> str:
        norm_slug = re.sub(r"\.(mpd|m3u8)$", "", slug, flags=re.IGNORECASE).strip().lower()
        ch_info = DGO_CHANNELS.get(norm_slug)
        if not ch_info:
            raise ValueError(f"Canal DGO no mapeado: '{norm_slug}'")
        if ch_info.get("enabled") is False:
            reason = str(ch_info.get("unavailable_reason") or "señal caída en origen")
            raise ChannelTemporarilyUnavailable(
                f"{ch_info.get('name') or ch_info.get('title') or norm_slug}: {reason}"
            )
        requested_type = (
            manifest_type
            or str(ch_info.get("manifest_type") or "dash")
        ).lower()
        if requested_type not in ("dash", "hls"):
            raise ValueError(f"Tipo de manifiesto DGO inválido: {requested_type}")
        cache_key = f"{norm_slug}:{requested_type}"
        with self._flight_lock("stream:" + cache_key):
            # El primer hilo llena la caché; los siguientes la releen dentro del lock.
            return self._get_stream_url_serialized(
                norm_slug, requested_type, force_refresh
            )

    def _get_stream_url_serialized(
        self,
        slug: str,
        manifest_type: Optional[str] = None,
        force_refresh: bool = False,
    ) -> str:
        """Obtiene una URL firmada DASH o HLS y cachea sólo hasta ``hdnts.exp``."""
        norm_slug = re.sub(r"\.(mpd|m3u8)$", "", slug, flags=re.IGNORECASE).strip().lower()
        ch_info = DGO_CHANNELS.get(norm_slug)
        if not ch_info:
            raise ValueError(f"Canal DGO no mapeado: '{norm_slug}'")

        requested_type = (manifest_type or str(ch_info.get("manifest_type") or "dash")).lower()
        if requested_type not in ("dash", "hls"):
            raise ValueError(f"Tipo de manifiesto DGO inválido: {requested_type}")
        cache_key = f"{norm_slug}:{requested_type}"

        mono_now = time.monotonic()
        with self._cache_lock:
            cached = self._stream_cache.get(cache_key)
            if cached and not force_refresh:
                url, deadline = cached
                if mono_now < deadline:
                    return url
                self._stream_cache.pop(cache_key, None)

        creds = self.load_credentials()
        headers = self._build_request_headers(creds)
        payload = json.dumps(
            {
                "delay": 0,
                "mobileNetwork": False,
                "isLive": True,
                "contentId": ch_info["channel_id"],
            }
        ).encode("utf-8")

        def _call_authorizer(auth_headers: Dict[str, str]) -> Dict[str, Any]:
            _st, resp_data, response_headers = self._http_pool.request(
                "POST",
                self.AUTHORIZER_ENDPOINT,
                data=payload,
                headers=auth_headers,
                timeout=self.AUTHORIZER_TIMEOUT_SECONDS,
            )
            self._update_server_time(response_headers)
            return json.loads(resp_data.decode("utf-8"))

        try:
            data = _call_authorizer(headers)
        except urllib.error.HTTPError as e:
            e.read()
            e.close()
            # El cuerpo del authorizer puede traer tokens: no va a logs ni a
            # mensajes de excepción.
            logger.error("DGO Authorizer HTTP %s. Cuerpo omitido.", e.code)
            # Reintento reactivo con auto-renovación si el token fue rechazado por expiración o permisos
            if e.code in (401, 403):
                logger.warning("[IPTV DGO] Acceso denegado (HTTP %s). Intentando adoptar sesión publicada...", e.code)
                recovered = self._adopt_newer_remote_session()
                if not recovered and self._is_session_owner():
                    recovered = self.renew_session()
                if recovered:
                    try:
                        fresh_creds = self.load_credentials()
                        fresh_headers = self._build_request_headers(fresh_creds, auto_renew=False)
                        data = _call_authorizer(fresh_headers)
                    except Exception as retry_err:
                        raise RuntimeError(f"Error DGO Authorizer tras adopción de sesión: {retry_err}") from retry_err
                else:
                    raise RuntimeError(f"Error DGO Authorizer ({e.code}) para {norm_slug}") from e
            else:
                raise RuntimeError(f"Error DGO Authorizer ({e.code}) para {norm_slug}") from e
        except Exception as e:
            logger.error("Error conectando con DGO Authorizer: %s", e)
            raise RuntimeError(f"Fallo de conexión con DGO Authorizer para {norm_slug}: {e}") from e

        manifests = data.get("manifest") or {}
        dash_url = (manifests.get("dash") or {}).get("primary")
        hls_url = (manifests.get("hls") or {}).get("primary")
        stream_url = dash_url if requested_type == "dash" else hls_url
        actual_type = requested_type
        if not stream_url and manifest_type is None:
            stream_url = hls_url if requested_type == "dash" else dash_url
            actual_type = "hls" if requested_type == "dash" else "dash"
        if not stream_url:
            raise RuntimeError(
                f"DGO no devolvió URL {requested_type.upper()} para el canal {norm_slug}"
            )
        if actual_type == "dash":
            stream_url = _normalize_dash_session_url(stream_url)

        drm_id = data.get("drmId") or ch_info["drm_id"]
        auth_token = data.get("authorization")

        # Guardar en caché el token de DRM Widevine
        if auth_token and drm_id:
            exp = _extract_jwt_exp(auth_token)
            if exp:
                remaining = exp - self._server_time() - self.SAFETY_MARGIN_SECONDS
                ttl = max(0.0, min(self.DEFAULT_DRM_TTL, remaining))
            else:
                ttl = self.DEFAULT_DRM_TTL
            if ttl > 0:
                with self._cache_lock:
                    self._drm_token_cache[drm_id.lower()] = (
                        auth_token,
                        time.monotonic() + ttl,
                    )

        stream_ttl = _signed_url_ttl(
            stream_url,
            self.DEFAULT_STREAM_TTL,
            self.SAFETY_MARGIN_SECONDS,
            now_epoch=self._server_time(),
        )
        with self._cache_lock:
            self._stream_cache[f"{norm_slug}:{actual_type}"] = (
                stream_url,
                time.monotonic() + stream_ttl,
            )
        return stream_url

    def get_manifest(self, slug: str, prefer_clearkey: bool = False) -> bytes:
        norm_slug = re.sub(r"\.(mpd|m3u8)$", "", slug, flags=re.IGNORECASE).strip().lower()
        ch_info = DGO_CHANNELS.get(norm_slug)
        if not ch_info:
            raise ValueError(f"Canal DGO no mapeado: '{norm_slug}'")
        if str(ch_info.get("manifest_type") or "dash").lower() != "dash":
            raise ValueError(f"El canal DGO '{norm_slug}' no ofrece DASH")
        mode = "ck" if prefer_clearkey else "wv"
        with self._flight_lock(f"manifest:{norm_slug}:{mode}"):
            return self._get_manifest_serialized(norm_slug, prefer_clearkey=prefer_clearkey)

    def _get_manifest_serialized(self, slug: str, prefer_clearkey: bool = False) -> bytes:
        """Descarga el MPD firmado desde Akamai y lo reescribe con BaseURL y query params en segmentos."""
        norm_slug = re.sub(r"\.(mpd|m3u8)$", "", slug, flags=re.IGNORECASE).strip().lower()
        cache_key = f"{norm_slug}:{'ck' if prefer_clearkey else 'wv'}"
        stream_url = self.get_stream_url(norm_slug, manifest_type="dash")

        mono_now = time.monotonic()
        with self._cache_lock:
            cached = self._manifest_cache.get(cache_key)
            if cached:
                cached_url, body, deadline = cached
                if cached_url == stream_url and mono_now < deadline:
                    return body
                self._manifest_cache.pop(cache_key, None)

        headers = {
            "User-Agent": USER_AGENT,
            "Origin": "https://www.directvgo.com",
            "Referer": "https://www.directvgo.com/",
        }
        def download(candidate: str) -> Tuple[bytes, str]:
            deadline = time.monotonic() + self.MANIFEST_TIMEOUT_SECONDS
            current_url = candidate
            for attempt in range(2):
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError("Timeout total descargando MPD DGO")
                try:
                    status, resp_data, resp_headers = self._http_pool.request(
                        "GET", current_url, headers=headers, timeout=remaining
                    )
                    if status in (301, 302, 303, 307, 308) and "location" in resp_headers:
                        loc = resp_headers["location"]
                        current_url = urllib.parse.urljoin(current_url, loc)
                        remaining = deadline - time.monotonic()
                        if remaining <= 0:
                            raise TimeoutError("Timeout total descargando MPD DGO tras redirección")
                        status, resp_data, resp_headers = self._http_pool.request(
                            "GET", current_url, headers=headers, timeout=remaining
                        )
                    if status == 200 and resp_data:
                        return resp_data, current_url
                    if status >= 400:
                        raise urllib.error.HTTPError(
                            current_url, status, f"HTTP {status}", resp_headers, io.BytesIO(resp_data)
                        )
                except urllib.error.HTTPError as error:
                    if error.code not in (429, 502, 503, 504) or attempt > 0:
                        error.close()
                        raise
                    error.close()
                except Exception:
                    req = urllib.request.Request(current_url, headers=headers)
                    try:
                        remaining = deadline - time.monotonic()
                        if remaining <= 0:
                            raise TimeoutError("Timeout total descargando MPD DGO")
                        with urllib.request.urlopen(
                            req, timeout=remaining, context=self.ssl_ctx
                        ) as resp:
                            final_url = (
                                getattr(resp, "geturl", lambda: None)()
                                or getattr(resp, "url", None)
                                or current_url
                            )
                            return resp.read(), final_url
                    except urllib.error.HTTPError as error:
                        if error.code not in (429, 502, 503, 504) or attempt > 0:
                            error.close()
                            raise
                        error.close()
                    except (urllib.error.URLError, socket.gaierror, TimeoutError, OSError):
                        if attempt > 0:
                            raise
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError("Timeout total descargando MPD DGO")
                time.sleep(min(0.20, remaining))
            raise RuntimeError("Fallo persistente descargando MPD DGO")

        raw_mpd: Optional[bytes] = None
        last_auth_error: Optional[urllib.error.HTTPError] = None
        fetch_start = time.monotonic()
        for authorization_round in range(2):
            candidates = [stream_url]
            ad_fallback = _enable_dash_ads(stream_url)
            if ad_fallback != stream_url:
                candidates.append(ad_fallback)
            for candidate in candidates:
                try:
                    raw_mpd, final_candidate = download(candidate)
                    if final_candidate != stream_url:
                        if candidate != stream_url:
                            logger.warning(
                                "Akamai rechazó da=0 para %s; usando da=1 como fallback de disponibilidad",
                                norm_slug,
                            )
                        stream_url = final_candidate
                        ttl = _signed_url_ttl(
                            stream_url,
                            self.DEFAULT_STREAM_TTL,
                            self.SAFETY_MARGIN_SECONDS,
                            now_epoch=self._server_time(),
                        )
                        with self._cache_lock:
                            self._stream_cache[f"{norm_slug}:dash"] = (
                                stream_url,
                                time.monotonic() + ttl,
                            )
                    break
                except urllib.error.HTTPError as error:
                    if error.code not in (401, 403):
                        raise
                    last_auth_error = error
                    error.close()
            if raw_mpd is not None:
                break
            if authorization_round == 0:
                logger.warning(
                    "Akamai rechazó ambas variantes para %s; renovando autorización DGO",
                    norm_slug,
                )
                stream_url = self.get_stream_url(
                    norm_slug, manifest_type="dash", force_refresh=True
                )
        if raw_mpd is None:
            assert last_auth_error is not None
            raise last_auth_error

        rewritten = rewrite_dgo_mpd(raw_mpd, stream_url)
        if prefer_clearkey:
            # Exigir cobertura 100% de KIDs vivos. Si falta algún KID, fallo limpio (503)
            # sin fallback silencioso a Widevine para evitar desestabilizar a InputStream Adaptive.
            kids = self.extract_kids(rewritten)
            keys = self.load_clearkeys()
            if kids and all(kid in keys for kid in kids):
                rewritten = rewrite_mpd_content_protection_to_clearkey(
                    rewritten, kids[0] if kids else None
                )
            else:
                missing = [kid for kid in kids if kid not in keys] if kids else ["NO_KIDS"]
                logger.error(
                    "[IPTV DGO] %s pidió ClearKey pero la cobertura de KIDs está incompleta "
                    "(faltan: %s); fallo limpio fail-closed",
                    norm_slug,
                    missing,
                )
                raise ChannelTemporarilyUnavailable(
                    f"Claves ClearKey incompletas para {norm_slug} (faltan {len(missing)} KIDs)"
                )
        with self._cache_lock:
            # Una sola sesión de zapping no debe retener el último MPD de los 91
            # canales. Primero se purgan vencidos y luego se aplica un límite.
            now = time.monotonic()
            expired = [
                key for key, (_url, _body, deadline) in self._manifest_cache.items()
                if deadline <= now
            ]
            for key in expired:
                self._manifest_cache.pop(key, None)
            while len(self._manifest_cache) >= self.MAX_MANIFEST_CACHE_ENTRIES:
                oldest = min(
                    self._manifest_cache,
                    key=lambda key: self._manifest_cache[key][2],
                )
                self._manifest_cache.pop(oldest, None)
            elapsed = time.monotonic() - fetch_start
            ttl = _manifest_cache_ttl(rewritten)
            effective_ttl = max(0.0, ttl - elapsed)
            sig_ttl = _signed_url_ttl(
                stream_url,
                self.DEFAULT_STREAM_TTL,
                margin=10.0,
                now_epoch=self._server_time(),
            )
            effective_ttl = min(effective_ttl, max(0.0, sig_ttl))
            if effective_ttl > 0:
                self._manifest_cache[cache_key] = (
                    stream_url,
                    rewritten,
                    time.monotonic() + effective_ttl,
                )
        return rewritten

    def get_hls_url(self, slug: str) -> str:
        """Obtiene la variante HLS firmada para señales FAST sin DASH."""
        return self.get_stream_url(slug, manifest_type="hls")

    # ── Catálogo dinámico y ClearKey ─────────────────────────────────────────
    def fetch_live_channels(self) -> List[Dict[str, Any]]:
        """Devuelve el lineup real de DGO desde ``/contents/v2/live/channels``.

        La respuesta trae ``channelId``, ``drmId``, ``isEntitled``, ``manifest``
        y ``drms`` autoritativos, sin heurísticas de numeración satelital.
        """
        creds = self.load_credentials()
        headers = self._build_request_headers(creds)
        _status, resp_data, resp_headers = self._http_pool.request(
            "GET",
            LIVE_CHANNELS_ENDPOINT,
            headers=headers,
            timeout=12.0,
        )
        self._update_server_time(resp_headers)
        payload = json.loads(resp_data.decode("utf-8"))
        channels = payload.get("channels") if isinstance(payload, dict) else None
        if not isinstance(channels, list) or not channels:
            raise RuntimeError("Respuesta de lineup DGO vacía o inválida")
        return channels

    def _clearkey_vault_paths(self) -> List[Path]:
        candidates: List[Path] = []
        env_path = os.environ.get("IPTV_DGO_CLEARKEY_VAULT", "").strip()
        if env_path:
            candidates.append(Path(env_path))
        profile_dir = _get_addon_profile_dir()
        if profile_dir:
            candidates.extend(profile_dir / name for name in CLEARKEY_VAULT_FILENAMES)
            candidates.extend(
                (profile_dir / "addon_data" / "service.iptv.flowproxy" / name)
                for name in CLEARKEY_VAULT_FILENAMES
            )
        lib_dir = Path(__file__).resolve().parent
        candidates.append(lib_dir / "dgo_keys_vault.json")
        candidates.append(lib_dir.parent / "data" / "dgo_keys_vault.json")
        candidates.append(Path.home() / ".flow_cache" / "dgo_keys_vault.json")
        candidates.append(Path("/home/fer/dgo_keys_vault.json"))
        return candidates

    def load_clearkeys(self) -> Dict[str, str]:
        """Carga las bóvedas ClearKey (KID -> key) publicadas en el dispositivo.

        Se combinan **todas** las bóvedas encontradas (perfil del add-on,
        ``resources/data`` empaquetada, caché y la global). Antes se devolvía la
        primera no vacía: la bóveda empaquetada quedaba primero y ocultaba para
        siempre la bóveda fresca del cosechador, por lo que la validación veía
        un "KID rotado" aunque la clave nueva ya estuviera publicada.

        El resultado se cachea por la firma (ruta, mtime, tamaño) de todas las
        candidatas: parsear el JSON en cada request era trabajo repetido.
        """
        candidates = self._clearkey_vault_paths()
        signature: List[Tuple[str, int, int]] = []
        available: List[Path] = []
        for candidate in candidates:
            try:
                if not candidate.is_file():
                    continue
                stat = candidate.stat()
                signature.append((str(candidate), stat.st_mtime_ns, stat.st_size))
                available.append(candidate)
            except OSError:
                continue
        if not available:
            return {}
        signature_key = tuple(signature)
        with self._vault_lock:
            cached = self._vault_cache
            if cached is not None and cached[0] == signature_key:
                return cached[1]
        result: Dict[str, str] = {}
        for candidate in available:
            try:
                data = json.loads(candidate.read_text(encoding="utf-8"))
                keys = data.get("keys") if isinstance(data, dict) else None
                if not isinstance(keys, dict):
                    continue
                for kid, entry in keys.items():
                    key = str((entry or {}).get("key") or "").strip().lower()
                    kid_clean = str(kid).strip().lower().replace("-", "")
                    if len(kid_clean) == 32 and len(key) == 32:
                        # La bóveda global (más nueva) se lee al final y gana
                        # ante un KID repetido con distinta clave.
                        result[kid_clean] = key
            except Exception as error:  # noqa: BLE001
                logger.debug("Bóveda ClearKey inválida en %s: %s", candidate, error)
        if result:
            with self._vault_lock:
                self._vault_cache = (signature_key, result)
        return result

    def has_clearkeys(self) -> bool:
        """``True`` sólo si hay al menos una clave ClearKey publicada.

        Chequeo barato para evitar consultar el manifest cuando la bóveda está
        vacía (el caso normal mientras el cosechador no se ejecute).
        """
        return bool(self.load_clearkeys())

    @staticmethod
    def extract_kids(manifest_bytes: bytes) -> List[str]:
        """KIDs únicos declarados por el MPD, en orden de aparición.

        Se leen tanto ``cenc:default_KID`` como los PSSH de Widevine/PlayReady
        embebidos. DGO publica varios canales sin ``default_KID`` pero con el
        KID dentro del PSSH; ignorarlo hacía que la bóveda ClearKey nunca
        emparejara y el canal cayera a Widevine.
        """
        text = manifest_bytes.decode("utf-8", errors="replace")
        kids: List[str] = []
        for raw in re.findall(
            r'(?:cenc:)?default_KID="([^"]+)"',
            text,
            flags=re.IGNORECASE,
        ):
            kid = raw.replace("-", "").strip().lower()
            if len(kid) == 32 and kid not in kids:
                kids.append(kid)
        for raw in _manifest_pssh_kids(text):
            kid = raw.replace("-", "").strip().lower()
            if len(kid) == 32 and kid not in kids:
                kids.append(kid)
        return kids

    def clearkey_status(self, slug: str) -> Dict[str, Any]:
        """Compara el KID vivo del manifest con la clave ClearKey cosechada.

        Si coinciden, el add-on puede servirlo como ClearKey. Si no, la
        publicación debe caer a Widevine para ese canal.
        """
        norm_slug = re.sub(r"\.(mpd|m3u8)$", "", slug, flags=re.IGNORECASE).strip().lower()
        keys = self.load_clearkeys()
        kids: List[str] = []
        # Un MPD en plena transición de Period puede no exponer el KID por un
        # instante: se reintenta una vez antes de declarar fallback a Widevine.
        # Sin bóveda publicada no hay nada que reintentar: se hace una sola
        # lectura y se evita el sleep de 0.4 s en cada zapping.
        attempts = 2 if keys else 1
        for attempt in range(attempts):
            manifest = self.get_manifest(norm_slug)
            kids = self.extract_kids(manifest)
            pairs = [f"{kid}:{keys[kid]}" for kid in kids if kid in keys]
            for kid in kids:
                if kid in keys:
                    return {
                        "slug": norm_slug,
                        "mode": "clearkey",
                        "kid": kid,
                        "key": keys[kid],
                        "keys": pairs,
                    }
            if attempt + 1 < attempts:
                with self._cache_lock:
                    self._manifest_cache.pop(f"{norm_slug}:wv", None)
                    self._manifest_cache.pop(f"{norm_slug}:ck", None)
                time.sleep(0.4)
        return {
            "slug": norm_slug,
            "mode": "widevine",
            "reason": "no_clearkey_for_current_kid" if kids else "manifest_without_kid",
            "kids": kids,
        }

    def get_drm_token(self, content_id: str, force_refresh: bool = False) -> str:
        """Obtiene el Bearer token válido para el contentId / drmId solicitado."""
        norm_id = content_id.strip().lower()
        mono_now = time.monotonic()
        with self._cache_lock:
            self._drm_activity[norm_id] = mono_now
            cached = self._drm_token_cache.get(norm_id)
            if cached and not force_refresh:
                token, deadline = cached
                if mono_now < deadline:
                    return token
                self._drm_token_cache.pop(norm_id, None)

        # Si no está en caché, refrescar invocando authorizer para el canal asociado
        slug = DRM_ID_TO_SLUG.get(norm_id)
        if slug:
            # Si el token falta o expiró, la URL firmada aún puede seguir en
            # caché. El Authorizer debe ejecutarse igualmente para obtener DRM.
            self._refresh_drm_authorization(slug)
            with self._cache_lock:
                cached = self._drm_token_cache.get(norm_id)
                if cached and time.monotonic() < cached[1]:
                    return cached[0]

        raise RuntimeError(f"No hay token de DRM disponible ni recuperable para {content_id}")

    def proxy_license(
        self, content_id: str, challenge_data: bytes
    ) -> Tuple[int, bytes, Dict[str, str]]:
        """Envía el challenge binario de Widevine al CPIX de DGO inyectando el token Bearer."""
        if not challenge_data:
            raise ValueError("Challenge Widevine vacío")

        target_url = (
            f"{self.CPIX_LICENSE_ENDPOINT}?"
            + urllib.parse.urlencode({"contentId": content_id})
        )
        creds = self.load_credentials()

        for attempt in range(2):
            bearer_token = self.get_drm_token(content_id, force_refresh=attempt > 0)
            headers = {
                "Authorization": f"Bearer {bearer_token}",
                "Content-Type": "application/octet-stream",
                "x-device-id": creds.get("device_id") or "kodi-flowproxy-primary",
                "x-client-id": creds.get("client_id", "web"),
                "x-client-version": creds.get("client_version", "3.69.0"),
                "x-app": creds.get("app", "dgo"),
                "Origin": "https://www.directvgo.com",
                "Referer": "https://www.directvgo.com/",
                "User-Agent": USER_AGENT,
            }
            started = time.monotonic()
            try:
                status, resp_bytes, _hdrs = self._http_pool.request(
                    "POST",
                    target_url,
                    data=challenge_data,
                    headers=headers,
                    timeout=self.CPIX_TIMEOUT_SECONDS,
                )
                logger.info(
                    "[IPTV DGO] Licencia CPIX %s resuelta en %.0f ms (Keep-Alive)",
                    content_id,
                    (time.monotonic() - started) * 1000.0,
                )
                return status, resp_bytes, {"Content-Type": "application/octet-stream"}
            except urllib.error.HTTPError as e:
                err_body = e.read()
                e.close()
                if e.code in (401, 403) and attempt == 0:
                    logger.warning(
                        "CPIX DRM HTTP %s para %s; renovando autorización del canal",
                        e.code,
                        content_id,
                    )
                    continue
                logger.error(
                    "CPIX DRM HTTP %s para contentId=%s: %s",
                    e.code,
                    content_id,
                    err_body[:200],
                )
                return e.code, err_body, {"Content-Type": "application/octet-stream"}
            except Exception as network_error:
                logger.error("Error conectando con CPIX DRM para %s: %s", content_id, network_error)
                raise RuntimeError(
                    f"Fallo de proxy CPIX DRM para {content_id}: {network_error}"
                ) from network_error

        raise RuntimeError(f"No se pudo resolver la licencia CPIX para {content_id}")
