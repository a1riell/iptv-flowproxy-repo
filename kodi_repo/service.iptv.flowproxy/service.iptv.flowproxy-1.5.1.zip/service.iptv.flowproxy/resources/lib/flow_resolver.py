"""
FlowSessionResolver: Obtención y caché local de tokens y URLs directas para nodos CDN de Flow.

Endurecimiento seguro para Android/Android TV (2026-09-26):
  * Acepta 301, 302, 307 y 308 (antes solo 302: si el CDN cambiaba de código, fallaba).
  * Extrae el claim ``exp`` del JWT, rechaza tokens ya vencidos y calcula el TTL efectivo
    con margen de seguridad, controlando el vencimiento local con ``time.monotonic()``
    (inmune a saltos del reloj de pared / NTP).
  * ELIMINADA la fuga de privacidad: ya NO se registra el header ``Location``, que contiene
    el token de sesión, y el token lleva el claim ``sip`` = IP pública del cliente.
  * TLS: se mantiene SIN verificación de forma CONSCIENTE y documentada.
"""

from __future__ import annotations

import base64
import json
import logging
import re
import ssl
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Dict, Optional, Tuple

logger = logging.getLogger("flowproxy_resolver")

USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36"

# Códigos de redirección que el CDN puede devolver legítimamente.
REDIRECT_CODES = (301, 302, 307, 308)

_TOKEN_RX = re.compile(r"(tok_[A-Za-z0-9_\-\.]+)")


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _safe_host(url: str) -> str:
    """Devuelve solo el host de una URL: nunca la ruta ni la query (pueden llevar el token)."""
    try:
        return urllib.parse.urlsplit(url).netloc or "<host-desconocido>"
    except Exception:  # noqa: BLE001
        return "<host-desconocido>"


class FlowSessionResolver:
    """Resuelve en caliente la URL con token de sesión de Flow desde la IP pública del dispositivo."""

    #: Margen de gracia antes del vencimiento real del token.
    SAFETY_MARGIN_SECONDS = 180.0
    #: Vida máxima aceptable de un token; por encima se considera fuera de política.
    MAX_TOKEN_LIFETIME_SECONDS = 7 * 24 * 3600
    #: TTL conservador cuando el token no expone ``exp``.
    FALLBACK_TTL_SECONDS = 900.0
    #: Cuánto se recuerda que un canal NO tiene variante FHD (evita re-sondear
    #: en cada renovación de token). Un falso negativo dura media hora.
    FHD_NEGATIVE_TTL_SECONDS = 1800.0
    #: Cuánto se recuerda que un canal SÍ tiene variante FHD.
    FHD_POSITIVE_TTL_SECONDS = 6 * 3600.0
    #: Tope de lectura de la variante ``_wl``. Se pide con ``Range`` para que el
    #: CDN no envíe más que el manifiesto, y el resultado se cachea por canal: la
    #: sonda corre una vez cada 6 h (o 30 min si el canal no tiene FHD) en lugar
    #: de en cada zapping.
    FHD_PROBE_MAX_BYTES = 262144

    def __init__(self, cache_ttl_seconds: float = 3600.0):
        self.cache_ttl = float(cache_ttl_seconds)
        # slug -> (target_url, deadline_monotonic)
        self._channel_cache: Dict[str, Tuple[str, float]] = {}
        # path de la variante _wl -> (es_fhd, deadline_monotonic)
        self._fhd_cache: Dict[str, Tuple[bool, float]] = {}
        self._fhd_lock = threading.Lock()
        # Un lock por slug: si dos clientes piden el mismo canal a la vez, la
        # resolución (y la sonda FHD) se hace una sola vez.
        self._slug_locks: Dict[str, threading.Lock] = {}
        self._slug_locks_guard = threading.Lock()

        self.ssl_ctx = ssl.create_default_context()
        # DECISIÓN CONSCIENTE (compatibilidad Android / TV Box):
        # Kodi en Android no siempre dispone del almacén de CAs del sistema. Con verificación
        # estricta el addon dejaría de resolver en esos dispositivos. Se mantiene sin verificar
        # hasta poder empaquetar un bundle de CAs dentro del add-on y validarlo en un
        # dispositivo real. NO cambiar a CERT_REQUIRED sin ese bundle.
        self.ssl_ctx.check_hostname = False
        self.ssl_ctx.verify_mode = ssl.CERT_NONE
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPSHandler(context=self.ssl_ctx),
            NoRedirect,
        )

    # ── Análisis del token ────────────────────────────────────────────────────
    @staticmethod
    def extract_exp(location: str) -> Optional[int]:
        """Extrae el claim ``exp`` del JWT del Location SIN validar la firma.

        Devuelve ``None`` si no hay token o no es interpretable.
        """
        m = _TOKEN_RX.search(location or "")
        if not m:
            return None
        raw = m.group(1)[4:]  # quita el prefijo 'tok_'
        parts = raw.split(".")
        if len(parts) < 2:
            return None
        try:
            payload_b64 = parts[1] + "=" * (-len(parts[1]) % 4)
            payload = json.loads(base64.urlsafe_b64decode(payload_b64))
        except Exception:  # noqa: BLE001
            return None
        try:
            return int(str(payload.get("exp", 0)))
        except (TypeError, ValueError):
            return None

    def effective_ttl(self, location: str, wall_now: Optional[float] = None) -> Optional[float]:
        """TTL efectivo en segundos para cachear una resolución.

        Devuelve ``None`` cuando el token ya está vencido (o vence dentro del margen) y por
        tanto NO debe cachearse: se fuerza una renovación inmediata.
        """
        now = time.time() if wall_now is None else float(wall_now)
        exp = self.extract_exp(location)
        if exp is None:
            # Sin metadatos de expiración: TTL conservador, nunca el largo por defecto.
            return min(self.cache_ttl, self.FALLBACK_TTL_SECONDS)
        if exp <= now:
            logger.warning("Token descartado: ya vencido (exp en el pasado).")
            return None
        if exp > now + self.MAX_TOKEN_LIFETIME_SECONDS:
            logger.warning("Token marcado EXP_OUT_OF_POLICY: vida superior al máximo aceptado.")
            return min(self.cache_ttl, self.FALLBACK_TTL_SECONDS)
        remaining = exp - now - self.SAFETY_MARGIN_SECONDS
        if remaining <= 0:
            logger.warning("Token descartado: vence dentro del margen de seguridad.")
            return None
        return float(min(self.cache_ttl, remaining))

    # ── Resolución ────────────────────────────────────────────────────────────
    @staticmethod
    def _fhd_cache_key(url: str) -> str:
        """Clave estable de la sonda: ruta sin host ni token.

        El token viaja como segmento de ruta (``/tok_xxx/live/...``) y cambia en
        cada renovación; el host del edge también rota. Lo que define si hay
        Full HD es el perfil (``.../SA_Live_dash_enc_wl/...``).
        """
        try:
            segments = [
                segment
                for segment in urllib.parse.urlsplit(url).path.split("/")
                if segment and not segment.startswith("tok_")
            ]
            return "/".join(segments) or url
        except Exception:  # noqa: BLE001
            return url

    def _probe_fhd_variant(self, fhd_url: str) -> bool:
        """Comprueba una sola vez si la variante ``_wl`` entrega 1080p o más.

        El resultado se cachea por perfil de canal (el token y el host del edge
        cambian en cada renovación, la ruta no). Antes se repetía la sonda (un
        request HTTPS completo) en cada resolución de canal; ahora corre una vez
        cada 6 h, o 30 min cuando el canal no tiene variante FHD.
        """
        path_key = self._fhd_cache_key(fhd_url)
        now = time.monotonic()
        with self._fhd_lock:
            cached = self._fhd_cache.get(path_key)
        if cached is not None and now < cached[1]:
            return cached[0]

        is_fhd = False
        try:
            request = urllib.request.Request(
                fhd_url,
                headers={
                    "User-Agent": USER_AGENT,
                    "Range": f"bytes=0-{self.FHD_PROBE_MAX_BYTES - 1}",
                },
            )
            with self.opener.open(request, timeout=3.0) as probe:
                body = probe.read(self.FHD_PROBE_MAX_BYTES)
            # Sólo se promueve si la variante FHD entrega un MPD que realmente
            # declare 1080p o superior.
            is_fhd = b"<MPD" in body and (
                b'height="1080"' in body
                or b'height="2160"' in body
                or b'width="1920"' in body
                or b'width="3840"' in body
            )
        except Exception:  # noqa: BLE001
            # Si la variante _wl no existe o falla, se conserva el perfil normal.
            is_fhd = False

        ttl = (
            self.FHD_POSITIVE_TTL_SECONDS if is_fhd else self.FHD_NEGATIVE_TTL_SECONDS
        )
        with self._fhd_lock:
            # Cota simple de memoria: el catálogo ronda los 1.700 canales.
            if len(self._fhd_cache) >= 4096:
                self._fhd_cache.clear()
            self._fhd_cache[path_key] = (is_fhd, time.monotonic() + ttl)
        return is_fhd

    @staticmethod
    def _restore_playback_profile(location: str, seed_rel: str, playback_rel: str) -> str:
        """Conserva el perfil de reproducción original tras negociar el token.

        El CDN exige consultar ``*_cenc`` para emitir el JWT, pero perfiles
        como ``*_enc_C`` y ``*_enc_wl`` sólo reproducen correctamente si el
        cliente vuelve a pedir el MPD original.  La sustitución se limita al
        sufijo de ruta, preserva token/query sin registrarlos y no altera los
        mappings que ya usan CENC como perfil de reproducción.
        """
        source = seed_rel.strip("/")
        target = playback_rel.strip("/")
        if not source or source == target:
            return location
        try:
            parsed = urllib.parse.urlsplit(location)
            candidates = [source]
            if "SA_Live_dash_cenc" in source:
                candidates.append(source.replace("SA_Live_dash_cenc", "SA_Live_dash_enc"))
            for cand in candidates:
                suffix = "/" + cand
                if parsed.path.endswith(suffix):
                    restored_path = parsed.path[:-len(cand)] + target
                    return urllib.parse.urlunsplit(parsed._replace(path=restored_path))
            return location
        except Exception:  # noqa: BLE001
            # Un Location inusual no debe impedir una redirección que antes era
            # válida; se conserva tal cual y sin escribirlo en logs.
            return location

    def _slug_lock(self, slug: str) -> threading.Lock:
        with self._slug_locks_guard:
            return self._slug_locks.setdefault(slug, threading.Lock())

    def resolve_stream(self, slug: str, rel_path: str) -> str:
        cached = self._channel_cache.get(slug)
        if cached is not None:
            url, deadline = cached
            if time.monotonic() < deadline:
                return url
            self._channel_cache.pop(slug, None)

        # Single-flight por canal: el segundo cliente espera la resolución en
        # curso en vez de repetir la consulta al CDN (y la sonda FHD).
        with self._slug_lock(slug):
            cached = self._channel_cache.get(slug)
            if cached is not None:
                url, deadline = cached
                if time.monotonic() < deadline:
                    return url
                self._channel_cache.pop(slug, None)
            return self._resolve_stream_uncached(slug, rel_path)

    def _resolve_stream_uncached(self, slug: str, rel_path: str) -> str:
        # Telecom Flow requiere consultar con el perfil SA_Live_dash_cenc
        playback_rel = rel_path.lstrip("/")
        # ``enc_C`` y demás sufijos experimentales de listas históricas no
        # son perfiles reproducibles del edge final. El actualizador ya los
        # normaliza a ``enc`` tras obtener el JWT; el proxy debe aplicar la
        # misma regla para que ambos caminos reproduzcan el mismo MPD.
        playback_rel = re.sub(
            r"SA_Live_dash_enc_(?!wl(?:/|$))[^/]+",
            "SA_Live_dash_enc",
            playback_rel,
        )
        seed_rel = re.sub(
            r"SA_Live_dash_enc(?:_[^/]+)?",
            "SA_Live_dash_cenc",
            playback_rel,
        )
        seed_url = f"https://cdn.cvattv.com.ar/{seed_rel}"

        req = urllib.request.Request(seed_url, headers={"User-Agent": USER_AGENT})
        for attempt in range(2):
            try:
                self.opener.open(req, timeout=4.0)
            except urllib.error.HTTPError as err:
                if err.code in REDIRECT_CODES:
                    loc = err.headers.get("Location")
                    if loc:
                        ttl = self.effective_ttl(loc)
                        if ttl is None:
                            raise RuntimeError(
                                f"Token no utilizable para el canal {slug} (vencido o fuera de política)"
                            )
                        playback_url = self._restore_playback_profile(loc, seed_rel, playback_rel)
                        # Promoción a FHD: los canales que ofrecen 1080p publican la
                        # variante ``SA_Live_dash_enc_wl`` bajo el mismo token. Si está
                        # disponible, se usa; si no, se conserva el perfil estándar.
                        if "SA_Live_dash_enc_wl" not in playback_url and "SA_Live_dash_enc/" in playback_url:
                            fhd_url = playback_url.replace(
                                "/SA_Live_dash_enc/", "/SA_Live_dash_enc_wl/"
                            )
                            if self._probe_fhd_variant(fhd_url):
                                playback_url = fhd_url
                        self._channel_cache[slug] = (playback_url, time.monotonic() + ttl)
                        return playback_url
                # NO se registra el Location: contiene el token, y el token lleva el claim
                # 'sip' con la IP pública del cliente. Solo código y host.
                logger.warning("Seed %s devolvió HTTP %s", _safe_host(seed_url), err.code)
                break
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                if attempt == 0:
                    logger.debug(
                        "Reintento por latencia de red al resolver seed en %s: %s",
                        _safe_host(seed_url),
                        type(exc).__name__,
                    )
                    time.sleep(1.0)
                    continue
                logger.warning("Error consultando seed en %s: %s", _safe_host(seed_url), type(exc).__name__)
                break
            except Exception as exc:  # noqa: BLE001
                logger.warning("Error consultando seed en %s: %s", _safe_host(seed_url), type(exc).__name__)
                break

        raise RuntimeError(
            f"No se pudo resolver una redirección {REDIRECT_CODES} para el canal {slug}"
        )
