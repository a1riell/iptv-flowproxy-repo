"""
Generador e inyector de guía EPG XMLTV en tiempo real para eventos en vivo de Disney+ (BAMGrid).
Calcula ventanas exactas de inicio/fin (barra de progreso en Kodi), liga/torneo y sinopsis oficial.
"""
from __future__ import annotations

import datetime
from datetime import timedelta, timezone
import html
import re
from typing import Any, Dict, Iterable, List, Mapping, Optional, Tuple, Union

from .models import BindingRecord

TZ_AR = timezone(timedelta(hours=-3))

_RE_DISNEY_LIVE_CHANNEL = re.compile(
    r'[ \t]*<channel id="disney-live-[^"]*">.*?</channel>[ \t]*\r?\n?',
    re.DOTALL,
)
_RE_DISNEY_LIVE_PROGRAMME = re.compile(
    r'[ \t]*<programme [^>]*channel="disney-live-[^"]*"[^>]*>.*?</programme>[ \t]*\r?\n?',
    re.DOTALL,
)


def format_xmltv_utc(dt_obj: datetime.datetime) -> str:
    """Formatea un datetime aware en el estándar XMLTV UTC: YYYYMMDDHHMMSS +0000."""
    utc_dt = dt_obj.astimezone(timezone.utc)
    return utc_dt.strftime("%Y%m%d%H%M%S +0000")


def parse_iso_utc(iso_str: Optional[str]) -> Optional[datetime.datetime]:
    """Convierte un timestamp ISO 8601 de BAMGrid (ej. 2026-10-17T18:27:39Z) a datetime UTC."""
    if not iso_str or not isinstance(iso_str, str):
        return None
    cleaned = iso_str.strip()
    if not cleaned:
        return None
    try:
        dt = datetime.datetime.fromisoformat(cleaned.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except Exception:
        return None


def _extract_meta(item: Union[BindingRecord, Mapping[str, Any]]) -> Dict[str, Optional[str]]:
    if isinstance(item, BindingRecord):
        return {
            "binding": item.binding,
            "title": item.title,
            "league": item.league,
            "description": item.description,
            "start_time": item.start_time,
            "end_time": item.end_time,
        }
    if isinstance(item, Mapping):
        return {
            "binding": str(item.get("binding") or "") or None,
            "title": str(item.get("title")).strip() if item.get("title") else None,
            "league": str(item.get("league")).strip() if item.get("league") else None,
            "description": str(item.get("description")).strip() if item.get("description") else None,
            "start_time": str(item.get("start_time")).strip() if item.get("start_time") else None,
            "end_time": str(item.get("end_time")).strip() if item.get("end_time") else None,
        }
    return {
        "binding": None,
        "title": None,
        "league": None,
        "description": None,
        "start_time": None,
        "end_time": None,
    }


def build_disney_live_programmes(
    item: Union[BindingRecord, Mapping[str, Any]],
    fallback_title: Optional[str] = None,
    now_utc: Optional[datetime.datetime] = None,
    logo: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    Construye la lista cronológica de bloques de programación EPG para un evento disney-live-*.
    Incluye:
    - Bloque de previa (12h antes del inicio real)
    - Bloque principal en vivo con start_time y end_time exactos de BAMGrid (habilita barra de progreso real en Kodi)
    - Bloque post-evento (12h después del cierre)
    """
    if now_utc is None:
        now_utc = datetime.datetime.now(timezone.utc)

    meta = _extract_meta(item)
    clean_title = (meta.get("title") or fallback_title or "Evento Disney+").strip()
    league = meta.get("league")
    raw_desc = meta.get("description")
    base_desc = (
        raw_desc
        if raw_desc
        else "Transmisión en directo del evento deportivo exclusivo por Disney+ / ESPN."
    )

    if league and league.lower() not in clean_title.lower():
        main_title = f"{league}: {clean_title}"
    else:
        main_title = clean_title

    start_dt = parse_iso_utc(meta.get("start_time"))
    end_dt = parse_iso_utc(meta.get("end_time"))

    if start_dt is not None and end_dt is None:
        end_dt = start_dt + timedelta(hours=3)
    elif start_dt is not None and end_dt is not None and end_dt <= start_dt:
        end_dt = start_dt + timedelta(hours=3)

    if start_dt is not None and end_dt is not None:
        start_ar = start_dt.astimezone(TZ_AR).strftime("%H:%M")
        end_ar = end_dt.astimezone(TZ_AR).strftime("%H:%M")

        live_subtitle = (
            f"{league} • {start_ar} - {end_ar} hs"
            if league
            else f"En Vivo • {start_ar} - {end_ar} hs"
        )
        live_desc = (
            f"[{league}] Horario: {start_ar} a {end_ar} hs (ARG). {base_desc}"
            if league
            else f"Horario: {start_ar} a {end_ar} hs (ARG). {base_desc}"
        )

        pre_start = start_dt - timedelta(hours=12)
        post_end = end_dt + timedelta(hours=12)

        return [
            {
                "start": pre_start,
                "stop": start_dt,
                "title": f"Previa: {main_title}",
                "subtitle": f"{league} • Inicia {start_ar} hs" if league else f"Inicia {start_ar} hs",
                "description": f"Inicio programado a las {start_ar} hs (ARG). {base_desc}",
                "category": "Deportes",
                "icon": logo,
            },
            {
                "start": start_dt,
                "stop": end_dt,
                "title": main_title,
                "subtitle": live_subtitle,
                "description": live_desc,
                "category": "Deportes",
                "icon": logo,
            },
            {
                "start": end_dt,
                "stop": post_end,
                "title": f"Finalizado: {clean_title}",
                "subtitle": f"{league} • Finalizó {end_ar} hs" if league else f"Finalizó {end_ar} hs",
                "description": f"Transmisión finalizada a las {end_ar} hs (ARG). {base_desc}",
                "category": "Deportes",
                "icon": logo,
            },
        ]

    # Fallback si BAMGrid no informó timeline para este ítem
    day_start = datetime.datetime(
        now_utc.year, now_utc.month, now_utc.day, 0, 0, 0, tzinfo=timezone.utc
    )
    max_cutoff = now_utc + timedelta(hours=36)
    progs: List[Dict[str, Any]] = []
    cursor = day_start
    while cursor < max_cutoff:
        nxt = cursor + timedelta(hours=4)
        progs.append(
            {
                "start": cursor,
                "stop": nxt,
                "title": f"{main_title} - En Vivo",
                "subtitle": league or "Disney+ / ESPN",
                "description": base_desc,
                "category": "Deportes",
                "icon": logo,
            }
        )
        cursor = nxt
    return progs


def _normalize_bindings_map(
    bindings: Union[Mapping[str, Any], Iterable[Mapping[str, Any]]]
) -> Dict[str, Union[BindingRecord, Mapping[str, Any]]]:
    normalized: Dict[str, Union[BindingRecord, Mapping[str, Any]]] = {}
    if isinstance(bindings, Mapping):
        for k, v in bindings.items():
            b_id = str(k).strip()
            if b_id.startswith("disney-live-"):
                normalized[b_id] = v
    elif isinstance(bindings, Iterable):
        for item in bindings:
            if isinstance(item, Mapping):
                b_id = str(item.get("binding") or "").strip()
                if b_id.startswith("disney-live-"):
                    normalized[b_id] = item
    return normalized


def render_disney_live_xmltv_fragments(
    bindings: Union[Mapping[str, Any], Iterable[Mapping[str, Any]]],
    now_utc: Optional[datetime.datetime] = None,
) -> Tuple[str, str]:
    """
    Genera los fragmentos XMLTV (<channel> y <programme>) para todos los eventos disney-live-* activos.
    """
    if now_utc is None:
        now_utc = datetime.datetime.now(timezone.utc)

    live_map = _normalize_bindings_map(bindings)
    if not live_map:
        return "", ""

    channel_blocks: List[str] = []
    programme_blocks: List[str] = []

    for binding_id in sorted(live_map.keys()):
        item = live_map[binding_id]
        meta = _extract_meta(item)
        display_name = (meta.get("title") or "Evento Disney+").strip()
        esc_id = html.escape(binding_id, quote=True)
        esc_name = html.escape(display_name)

        channel_blocks.append(
            f'  <channel id="{esc_id}">\n'
            f'    <display-name lang="es">{esc_name}</display-name>\n'
            f'  </channel>'
        )

        progs = build_disney_live_programmes(item, fallback_title=display_name, now_utc=now_utc)
        for p in progs:
            st_str = format_xmltv_utc(p["start"])
            sp_str = format_xmltv_utc(p["stop"])
            lines = [
                f'  <programme start="{st_str}" stop="{sp_str}" channel="{esc_id}">',
                f'    <title lang="es">{html.escape(str(p["title"]))}</title>',
            ]
            if p.get("subtitle"):
                lines.append(f'    <sub-title lang="es">{html.escape(str(p["subtitle"]))}</sub-title>')
            if p.get("description"):
                lines.append(f'    <desc lang="es">{html.escape(str(p["description"]))}</desc>')
            if p.get("category"):
                lines.append(f'    <category lang="es">{html.escape(str(p["category"]))}</category>')
            if p.get("icon"):
                lines.append(f'    <icon src="{html.escape(str(p["icon"]), quote=True)}" />')
            lines.append("  </programme>")
            programme_blocks.append("\n".join(lines))

    channels_xml = ("\n".join(channel_blocks) + "\n") if channel_blocks else ""
    programmes_xml = ("\n".join(programme_blocks) + "\n") if programme_blocks else ""
    return channels_xml, programmes_xml


def inject_disney_live_epg(
    xml_text: str,
    bindings: Union[Mapping[str, Any], Iterable[Mapping[str, Any]]],
    now_utc: Optional[datetime.datetime] = None,
) -> str:
    """
    Reemplaza en memoria todos los bloques <channel> y <programme> de disney-live-*
    dentro de un documento XMLTV completo con los metadatos reales en vivo de BAMGrid.
    """
    if not xml_text or "</tv>" not in xml_text:
        return xml_text

    cleaned = _RE_DISNEY_LIVE_CHANNEL.sub("", xml_text)
    cleaned = _RE_DISNEY_LIVE_PROGRAMME.sub("", cleaned)

    channels_xml, programmes_xml = render_disney_live_xmltv_fragments(bindings, now_utc=now_utc)
    if not channels_xml and not programmes_xml:
        return cleaned

    first_prog_idx = cleaned.find("<programme ")
    if first_prog_idx != -1 and channels_xml:
        line_start = cleaned.rfind("\n", 0, first_prog_idx)
        insert_pos = (line_start + 1) if line_start != -1 else first_prog_idx
        cleaned = cleaned[:insert_pos] + channels_xml + cleaned[insert_pos:]
        close_tv_idx = cleaned.rfind("</tv>")
        if close_tv_idx != -1 and programmes_xml:
            cleaned = cleaned[:close_tv_idx] + programmes_xml + cleaned[close_tv_idx:]
    else:
        close_tv_idx = cleaned.rfind("</tv>")
        if close_tv_idx != -1:
            cleaned = cleaned[:close_tv_idx] + channels_xml + programmes_xml + cleaned[close_tv_idx:]

    return cleaned


def update_epg_files_with_disney_live(
    epg_xml_path: Optional[Union[str, "os.PathLike[str]"]],
    epg_gz_path: Optional[Union[str, "os.PathLike[str]"]],
    bindings: Union[Mapping[str, Any], Iterable[Mapping[str, Any]]],
    now_utc: Optional[datetime.datetime] = None,
) -> bool:
    """
    Actualiza de forma atómica los archivos epg.xml y/o epg.xml.gz en disco
    inyectando los canales y programas en tiempo real de disney-live-*.
    """
    import gzip
    import os
    from pathlib import Path
    import tempfile

    xml_p = Path(epg_xml_path) if epg_xml_path else None
    gz_p = Path(epg_gz_path) if epg_gz_path else None

    raw_xml: Optional[str] = None
    if xml_p and xml_p.is_file():
        try:
            raw_xml = xml_p.read_text(encoding="utf-8")
        except Exception:
            raw_xml = None
    if raw_xml is None and gz_p and gz_p.is_file():
        try:
            raw_xml = gzip.decompress(gz_p.read_bytes()).decode("utf-8")
        except Exception:
            raw_xml = None

    if not raw_xml or "</tv>" not in raw_xml:
        return False

    updated_xml = inject_disney_live_epg(raw_xml, bindings, now_utc=now_utc)
    updated_bytes = updated_xml.encode("utf-8")

    wrote_any = False
    if xml_p:
        xml_p.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp_xml = tempfile.mkstemp(prefix=".epg_disney_", suffix=".xml.tmp", dir=str(xml_p.parent))
        try:
            os.fchmod(fd, 0o644)
            with os.fdopen(fd, "wb") as f_out:
                fd = -1
                f_out.write(updated_bytes)
            os.replace(tmp_xml, xml_p)
            wrote_any = True
        finally:
            if fd >= 0:
                os.close(fd)
            if os.path.exists(tmp_xml):
                try:
                    os.unlink(tmp_xml)
                except OSError:
                    pass

    if gz_p:
        gz_p.parent.mkdir(parents=True, exist_ok=True)
        compressed = gzip.compress(updated_bytes, compresslevel=6)
        fd, tmp_gz = tempfile.mkstemp(prefix=".epg_disney_", suffix=".xml.gz.tmp", dir=str(gz_p.parent))
        try:
            os.fchmod(fd, 0o644)
            with os.fdopen(fd, "wb") as f_out:
                fd = -1
                f_out.write(compressed)
            os.replace(tmp_gz, gz_p)
            wrote_any = True
        finally:
            if fd >= 0:
                os.close(fd)
            if os.path.exists(tmp_gz):
                try:
                    os.unlink(tmp_gz)
                except OSError:
                    pass

    return wrote_any

