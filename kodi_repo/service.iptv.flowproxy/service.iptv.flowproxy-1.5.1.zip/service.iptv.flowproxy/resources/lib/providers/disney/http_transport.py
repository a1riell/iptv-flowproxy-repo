"""
Capa de transporte HTTP para Disney+ con soporte para pool de conexiones persistentes (HTTP/1.1 Keep-Alive),
límites estrictos de conexiones activas, garantías de idempotencia y tests unitarios.
"""
from __future__ import annotations

import http.client
import logging
import ssl
import threading
import time
import urllib.parse
from typing import Dict, List, Optional, Protocol, Tuple, Union

logger = logging.getLogger("flowproxy_disney_transport")


class HttpTransportError(Exception):
    """Error base de transporte HTTP."""
    pass


class UpstreamHttpError(HttpTransportError):
    def __init__(self, status: int, body: bytes, headers: Dict[str, str]):
        super().__init__(f"Upstream HTTP error {status}")
        self.status = status
        self.body = body
        self.headers = headers


class HttpTransport(Protocol):
    def request(
        self,
        method: str,
        url: str,
        headers: Dict[str, str],
        body: Optional[bytes] = None,
        timeout: float = 12.0,
    ) -> Tuple[int, bytes, Dict[str, str]]:
        ...


class DefaultHttpTransport:
    """Transporte HTTP con pool persistente y concurrencia estrictamente limitada.

    Garantías:
    1. Límites estrictos de conexiones activas y en reposo (máximo 2 por host, 4 totales).
    2. Idempotencia: NO reintenta solicitudes no idempotentes (como POST) tras una desconexión.
    3. Deadline compartido entre esperas de pool y ejecución de la solicitud.
    4. Actualización del timeout en el socket subyacente para conexiones reutilizadas.
    """

    MAX_PER_HOST = 2
    MAX_TOTAL = 4

    def __init__(self, ssl_context: Optional[ssl.SSLContext] = None) -> None:
        if ssl_context is None:
            self._ssl_ctx = ssl.create_default_context()
        else:
            self._ssl_ctx = ssl_context
        self._pool_lock = threading.Lock()
        self._pool_cond = threading.Condition(self._pool_lock)
        self._active_per_host: Dict[Tuple[str, str], int] = {}
        self._total_active: int = 0
        self._idle_pool: Dict[Tuple[str, str], List[Union[http.client.HTTPConnection, http.client.HTTPSConnection]]] = {}

    def _total_open(self) -> int:
        """Contabiliza todas las conexiones abiertas (activas + ociosas)."""
        return self._total_active + sum(len(conns) for conns in self._idle_pool.values())

    def _evict_one_idle(self, exclude_key: Optional[Tuple[str, str]] = None) -> None:
        """Cierra una conexión ociosa para liberar un descriptor de socket antes de crear una nueva."""
        for k, conns in list(self._idle_pool.items()):
            if k == exclude_key and len(self._idle_pool) > 1:
                continue
            if conns:
                evicted = conns.pop()
                try:
                    evicted.close()
                except Exception:
                    pass
                if not conns:
                    self._idle_pool.pop(k, None)
                return

    def _acquire_connection(
        self, scheme: str, netloc: str, deadline: float
    ) -> Union[http.client.HTTPConnection, http.client.HTTPSConnection]:
        key = (scheme, netloc)
        with self._pool_cond:
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise HttpTransportError(f"Timeout agotado esperando conexión disponible en el pool para {netloc}")
                cur_host = self._active_per_host.get(key, 0)
                if cur_host < self.MAX_PER_HOST and self._total_active < self.MAX_TOTAL:
                    # Si no hay conexión ociosa para este host pero el total de sockets abiertos
                    # (activos + ociosos) alcanzaría MAX_TOTAL, desalojar una conexión ociosa de otro host.
                    idle_for_host = self._idle_pool.get(key, [])
                    if not idle_for_host and self._total_open() >= self.MAX_TOTAL:
                        self._evict_one_idle(exclude_key=key)

                    self._active_per_host[key] = cur_host + 1
                    self._total_active += 1
                    break
                self._pool_cond.wait(timeout=min(remaining, 0.2))

            conns = self._idle_pool.get(key)
            if conns:
                conn = conns.pop()
                if not conns:
                    self._idle_pool.pop(key, None)
                rem = max(0.1, deadline - time.monotonic())
                conn.timeout = rem
                if getattr(conn, "sock", None) is not None:
                    try:
                        conn.sock.settimeout(rem)
                    except Exception:
                        pass
                return conn

        # Si no había conexión inactiva en pool, crear una nueva con el tiempo remanente
        rem = max(0.1, deadline - time.monotonic())
        if scheme == "https":
            return http.client.HTTPSConnection(netloc, timeout=rem, context=self._ssl_ctx)
        return http.client.HTTPConnection(netloc, timeout=rem)

    def _release_connection(
        self,
        scheme: str,
        netloc: str,
        conn: Union[http.client.HTTPConnection, http.client.HTTPSConnection],
        reusable: bool,
    ) -> None:
        key = (scheme, netloc)
        with self._pool_cond:
            self._active_per_host[key] = max(0, self._active_per_host.get(key, 1) - 1)
            self._total_active = max(0, self._total_active - 1)

            # Se reutiliza sólo si no excede el límite por host Y el total global abierto (activas + ociosas < MAX_TOTAL)
            host_idle = len(self._idle_pool.get(key, []))
            if reusable and host_idle < self.MAX_PER_HOST and self._total_open() < self.MAX_TOTAL:
                self._idle_pool.setdefault(key, []).append(conn)
            else:
                try:
                    conn.close()
                except Exception:
                    pass
            self._pool_cond.notify_all()

    def close(self) -> None:
        """Cierra todas las conexiones del pool y notifica a posibles hilos en espera."""
        with self._pool_cond:
            for conns in self._idle_pool.values():
                for conn in conns:
                    try:
                        conn.close()
                    except Exception:
                        pass
            self._idle_pool.clear()
            self._pool_cond.notify_all()

    def request(
        self,
        method: str,
        url: str,
        headers: Dict[str, str],
        body: Optional[bytes] = None,
        timeout: float = 12.0,
    ) -> Tuple[int, bytes, Dict[str, str]]:
        parsed = urllib.parse.urlsplit(url)
        path = parsed.path or "/"
        if parsed.query:
            path = f"{path}?{parsed.query}"

        req_headers = dict(headers)
        if body is not None and "Content-Length" not in req_headers:
            req_headers["Content-Length"] = str(len(body))

        # Idempotencia estricta: sólo GET, HEAD y OPTIONS pueden reintentarse automáticamente ante fallas de transporte
        is_idempotent = method.upper() in ("GET", "HEAD", "OPTIONS")
        max_attempts = 2 if is_idempotent else 1

        deadline = time.monotonic() + timeout
        last_error = None

        for attempt in range(max_attempts):
            rem = deadline - time.monotonic()
            if rem <= 0:
                raise HttpTransportError(f"Timeout total ({timeout}s) agotado antes de iniciar intento {attempt + 1}")

            conn = self._acquire_connection(parsed.scheme, parsed.netloc, deadline)
            reusable = False
            try:
                conn.request(method, path, body=body, headers=req_headers)
                resp = conn.getresponse()
                status = resp.status
                max_bytes = 10 * 1024 * 1024
                resp_body = resp.read(max_bytes + 1)
                if len(resp_body) > max_bytes:
                    raise HttpTransportError(f"Respuesta upstream desde {url} excede el límite de 10 MB")
                resp_headers = {k.lower(): v for k, v in resp.getheaders()}

                if resp_headers.get("connection", "").lower() != "close":
                    reusable = True

                self._release_connection(parsed.scheme, parsed.netloc, conn, reusable)
                return status, resp_body, resp_headers
            except (http.client.RemoteDisconnected, http.client.CannotSendRequest, BrokenPipeError, ConnectionResetError) as e:
                self._release_connection(parsed.scheme, parsed.netloc, conn, False)
                last_error = e
                if is_idempotent and attempt < max_attempts - 1:
                    logger.debug("Conexión persistente hacia %s cerrada por upstream; reintentando método idempotente %s...", url, method)
                    continue
                logger.error("Error en conexión hacia %s (%s): %s", url, method, e)
                raise HttpTransportError(f"Fallo de conexión hacia {url}: {e}") from e
            except Exception as e:
                self._release_connection(parsed.scheme, parsed.netloc, conn, False)
                logger.error("Error en conexión hacia %s (%s): %s", url, method, e)
                raise HttpTransportError(f"Fallo de conexión hacia {url}: {e}") from e

        assert last_error is not None
        raise HttpTransportError(f"Fallo de conexión hacia {url}: {last_error}") from last_error
