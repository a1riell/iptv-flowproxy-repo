"""
Servidor HTTP Local Zero-CPU para redirecciones de Flow en Kodi.
"""

from __future__ import annotations

import datetime
import email.utils
import gzip
import hashlib
import http.server
import json
import logging
import os
import re
import shutil
import socket
import socketserver
import ssl
import tempfile
import threading
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from urllib.parse import urljoin
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, Union

from .flow_resolver import FlowSessionResolver
from .flow_auth import FlowAuthManager
from .dgo_resolver import (
    DRM_ID_TO_SLUG,
    ChannelTemporarilyUnavailable,
    DgoSessionResolver,
)
from .providers.disney import (
    BindingRecord,
    ChromeWebContract,
    DefaultHttpTransport,
    DisneyLicenseProxy,
    DisneyPlaybackEngine,
    DisneySessionManager,
    PlaybackRegistry,
    update_epg_files_with_disney_live,
)
from .providers.disney.http_transport import UpstreamHttpError
from .providers.disney.models import PlaybackContext
from .providers.sensa import (
    SensaChannelUnavailable,
    SensaPlaybackEngine,
    SensaPlaybackError,
    SensaSessionError,
    SensaSessionManager,
)

logger = logging.getLogger("flowproxy_server")

USER_AGENT = "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 Kodi/21"
MAX_WIDEVINE_CHALLENGE_BYTES = 1024 * 1024
MAX_LOCAL_WORKERS = 16
CLIENT_DISCONNECT_ERRORS = (
    BrokenPipeError,
    ConnectionResetError,
    ConnectionAbortedError,
    socket.timeout,
)

MAPPINGS_FILE = Path(__file__).resolve().parent / "slug_mappings.json"
SLUG_MAPPINGS: Dict[str, str] = {}
DISNEY_BINDINGS_URL = (
    "https://gist.githubusercontent.com/a1riell/"
    "9c1db121510fc81709f28c132afb9c81/raw/disney_bindings.json"
)
_bindings_download_lock = threading.Lock()
_last_bindings_download_attempt = 0.0

_last_disney_notify_time = 0.0
_disney_notify_lock = threading.Lock()


def _notify_kodi_throttled(
    title: str, message: str, is_error: bool = False, cooldown_seconds: float = 30.0
) -> None:
    """Envía una notificación nativa en Kodi con control de frecuencia (antispam)."""
    global _last_disney_notify_time
    with _disney_notify_lock:
        now = time.time()
        if now - _last_disney_notify_time < cooldown_seconds:
            return
        _last_disney_notify_time = now
    try:
        import xbmcgui

        icon = xbmcgui.NOTIFICATION_ERROR if is_error else xbmcgui.NOTIFICATION_WARNING
        xbmcgui.Dialog().notification(title, message, icon, 6000)
    except Exception:
        pass


if MAPPINGS_FILE.is_file():
    try:
        SLUG_MAPPINGS = json.loads(MAPPINGS_FILE.read_text(encoding="utf-8"))
    except Exception as e:
        logger.warning(f"No se pudo cargar slug_mappings.json: {e}")


def _find_disney_bindings_file() -> Optional[Path]:
    """Busca el archivo de bindings persistidos de Disney+."""
    try:
        import xbmcaddon
        import xbmcvfs
        addon = xbmcaddon.Addon("service.iptv.flowproxy")
        profile_dir = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        p = Path(profile_dir) / "disney_bindings.json"
        if p.is_file():
            return p
    except Exception:
        pass

    candidates = [
        Path.home() / ".kodi" / "userdata" / "addon_data" / "service.iptv.flowproxy" / "disney_bindings.json",
        Path.home() / ".flow_cache" / "disney_bindings.json",
        Path(__file__).resolve().parent / "disney_bindings.json",
    ]
    for c in candidates:
        if c.is_file():
            return c
    return None


def _find_epg_files() -> Tuple[Optional[Path], Optional[Path]]:
    """Busca archivos epg.xml y epg.xml.gz en ubicaciones estándar garantizando coherencia de generación."""
    candidates = []
    try:
        candidates.append(_disney_bindings_target().parent)
    except Exception:
        pass
    try:
        import xbmcaddon
        import xbmcvfs
        addon = xbmcaddon.Addon("service.iptv.flowproxy")
        profile = Path(xbmcvfs.translatePath(addon.getAddonInfo("profile")))
        candidates.append(profile)
    except Exception:
        pass

    lib_dir = Path(__file__).resolve().parent
    candidates.extend([
        Path.home() / ".kodi" / "userdata" / "addon_data" / "service.iptv.flowproxy",
        lib_dir.parent / "data",
        lib_dir,
        Path.home() / "listas_gist",
        Path.home() / ".flow_cache",
        Path.home() / ".flow_cache" / "epg",
        Path.home(),
        Path("/storage/emulated/0/Download"),
    ])

    # 1. Prioridad: Verificar referencia atómica unificada (current_generation.json)
    for folder in candidates:
        if not folder.is_dir():
            continue
        gen_meta = folder / "current_generation.json"
        if gen_meta.is_file():
            try:
                data = json.loads(gen_meta.read_text(encoding="utf-8"))
                xml_raw = data.get("xml", "")
                gz_raw = data.get("gz", "")
                if xml_raw and gz_raw:
                    xml_p = Path(xml_raw) if Path(xml_raw).is_absolute() else folder / xml_raw
                    gz_p = Path(gz_raw) if Path(gz_raw).is_absolute() else folder / gz_raw
                    if xml_p.is_file() and gz_p.is_file():
                        return xml_p, gz_p
            except Exception as e:
                logger.debug("Aviso leyendo current_generation.json en %s: %s", folder, e)

    # 2. Segunda prioridad: Ambos archivos epg.xml y epg.xml.gz presentes juntos en la misma carpeta
    for folder in candidates:
        if not folder.is_dir():
            continue
        cand_xml = folder / "epg.xml"
        cand_gz = folder / "epg.xml.gz"
        if cand_xml.is_file() and cand_gz.is_file():
            return cand_xml, cand_gz

    # 3. Fallback: Archivo individual disponible si no existen ambos
    for folder in candidates:
        if not folder.is_dir():
            continue
        cand_xml = folder / "epg.xml"
        cand_gz = folder / "epg.xml.gz"
        if cand_xml.is_file() or cand_gz.is_file():
            return (cand_xml if cand_xml.is_file() else None, cand_gz if cand_gz.is_file() else None)

    return None, None


def _disney_bindings_target() -> Path:
    """Devuelve una ruta escribible y privada dentro del perfil del add-on."""
    try:
        import xbmcaddon
        import xbmcvfs
        addon = xbmcaddon.Addon("service.iptv.flowproxy")
        profile = Path(xbmcvfs.translatePath(addon.getAddonInfo("profile")))
    except Exception:
        profile = (
            Path.home()
            / ".kodi"
            / "userdata"
            / "addon_data"
            / "service.iptv.flowproxy"
        )
    profile.mkdir(parents=True, exist_ok=True)
    return profile / "disney_bindings.json"


REMOTE_EPG_FALLBACK_URL = (
    "https://gist.githubusercontent.com/a1riell/9c1db121510fc81709f28c132afb9c81/raw/epg.xml"
)
_epg_download_lock = threading.Lock()
_last_epg_download_attempt: float = 0.0
_last_epg_download_success: float = 0.0

#: Ventana mínima entre descargas exitosas de la guía. Con varios clientes
#: (TV, tablet, teléfono) pidiendo el EPG a la vez, sólo el primero descarga;
#: el resto reutiliza la generación recién promovida en lugar de bajarla de nuevo.
EPG_MIN_REFRESH_INTERVAL_SECONDS = 300.0

#: Un único hilo de refresco en segundo plano. Sin esto, cada request con la
#: guía vencida abría su propia descarga y se producía una "tormenta" de EPG.
_epg_refresh_lock = threading.Lock()
_epg_refresh_thread: Optional[threading.Thread] = None


def _schedule_epg_refresh(force: bool = False) -> bool:
    """Lanza como máximo un refresco de EPG en segundo plano.

    Devuelve ``True`` si arrancó un hilo nuevo y ``False`` si ya había uno en
    curso (en ese caso el llamador no debe esperar ni duplicar la descarga).
    """
    global _epg_refresh_thread
    with _epg_refresh_lock:
        if _epg_refresh_thread is not None and _epg_refresh_thread.is_alive():
            return False

        def _worker() -> None:
            global _epg_refresh_thread
            try:
                _download_epg_fallback(force=force)
            finally:
                with _epg_refresh_lock:
                    if _epg_refresh_thread is threading.current_thread():
                        _epg_refresh_thread = None

        thread = threading.Thread(target=_worker, name="epg-refresh", daemon=True)
        _epg_refresh_thread = thread
        thread.start()
        return True


REMOTE_M3U_FALLBACK_URL = (
    "https://gist.githubusercontent.com/a1riell/9c1db121510fc81709f28c132afb9c81/raw/kodi_canales_funcionales.m3u"
)
_m3u_download_lock = threading.Lock()
_last_m3u_download_attempt: float = 0.0

REMOTE_DGO_VAULT_FALLBACK_URL = (
    "https://gist.githubusercontent.com/a1riell/9c1db121510fc81709f28c132afb9c81/raw/dgo_keys_vault.json"
)
_vault_download_lock = threading.Lock()
_last_vault_download_attempt: float = 0.0


def _download_dgo_vault_fallback(force: bool = False) -> Optional[Path]:
    """Descarga de respaldo la bóveda ClearKey de DGO publicada en el Gist."""
    global _last_vault_download_attempt
    with _vault_download_lock:
        now = time.monotonic()
        if not force and (now - _last_vault_download_attempt < 120):
            return None
        _last_vault_download_attempt = now
        try:
            profile = _disney_bindings_target().parent
            profile.mkdir(parents=True, exist_ok=True)
            target = profile / "dgo_keys_vault.json"
            req = urllib.request.Request(
                REMOTE_DGO_VAULT_FALLBACK_URL,
                headers={"User-Agent": USER_AGENT},
            )
            ctx = ssl.create_default_context()
            with urllib.request.urlopen(req, timeout=15, context=ctx) as resp:
                if resp.status == 200:
                    data = resp.read()
                    if data and b"keys" in data:
                        pid = os.getpid()
                        tmp_f = profile / f".vault_tmp_{pid}.json"
                        tmp_f.write_bytes(data)
                        tmp_f.replace(target)
                        logger.info("Bóveda ClearKey de DGO sincronizada desde respaldo remoto")
                        return target
        except Exception as exc:
            logger.debug("Aviso descargando bóveda DGO desde Gist: %s", exc)
    return None



def _download_epg_fallback(force: bool = False) -> Optional[Path]:
    """Descarga de respaldo la guía EPG publicada en el Gist y promueve una generación atómica."""
    global _last_epg_download_attempt, _last_epg_download_success
    with _epg_download_lock:
        now = time.monotonic()
        # Single-flight: si otra petición acaba de refrescar la guía, se reutiliza
        # esa generación en vez de volver a descargarla (antes cada cliente que
        # llegaba con la guía vencida disparaba su propia descarga).
        if (
            _last_epg_download_success > 0.0
            and now - _last_epg_download_success < EPG_MIN_REFRESH_INTERVAL_SECONDS
        ):
            existing_xml, existing_gz = _find_epg_files()
            for existing in (existing_xml, existing_gz):
                if existing and existing.is_file():
                    return existing
        if not force and (now - _last_epg_download_attempt < 120):
            return None
        _last_epg_download_attempt = now
        try:
            profile = _disney_bindings_target().parent
            profile.mkdir(parents=True, exist_ok=True)
            target = profile / "epg.xml"
            target_gz = profile / "epg.xml.gz"

            req = urllib.request.Request(
                REMOTE_EPG_FALLBACK_URL,
                headers={"User-Agent": USER_AGENT, "Accept-Encoding": "gzip"},
            )

            data: Optional[bytes] = None
            ctx = ssl.create_default_context()
            for attempt in range(2):
                try:
                    with urllib.request.urlopen(req, timeout=25, context=ctx) as resp:
                        if resp.status == 200:
                            raw = resp.read()
                            enc = (resp.headers.get("Content-Encoding") or "").lower()
                            if "gzip" in enc or raw.startswith(b"\x1f\x8b"):
                                import gzip
                                data = gzip.decompress(raw)
                            else:
                                data = raw
                    break
                except (urllib.error.URLError, TimeoutError, OSError) as net_err:
                    if attempt == 0:
                        logger.debug("Reintento Wi-Fi descargando EPG tras %s: %s", type(net_err).__name__, net_err)
                        time.sleep(1.5)
                        continue
                    logger.warning("Fallo descargando respaldo remoto de EPG tras reintento: %s", net_err)
                    break
                except ssl.SSLError as ssl_err:
                    logger.warning("Fallo de verificación TLS al descargar respaldo remoto de EPG: %s", ssl_err)
                    break

            if data and len(data) > 50000 and b"<tv" in data and b"</tv>" in data:
                import gzip

                gen_id = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%d_%H%M%S")
                generations_dir = profile / "generations"
                generations_dir.mkdir(parents=True, exist_ok=True)
                gen_dir = generations_dir / gen_id
                gen_dir.mkdir(parents=True, exist_ok=True)

                gen_xml = gen_dir / "epg.xml"
                gen_gz = gen_dir / "epg.xml.gz"

                tmp_xml = gen_dir / f".epg_tmp_{gen_id}.xml"
                tmp_gz = gen_dir / f".epg_tmp_{gen_id}.xml.gz"

                tmp_xml.write_bytes(data)
                with gzip.open(tmp_gz, "wb", compresslevel=9) as gz_out:
                    gz_out.write(data)

                tmp_xml.replace(gen_xml)
                tmp_gz.replace(gen_gz)

                # Promoción atómica mediante referencia única: current_generation.json
                gen_meta = {
                    "generation_id": gen_id,
                    "created_at": time.time(),
                    "xml": str(gen_xml.resolve()),
                    "gz": str(gen_gz.resolve()),
                    "source": "remote_fallback",
                }
                meta_tmp = profile / f".current_gen_{gen_id}.json.tmp"
                meta_tmp.write_text(json.dumps(gen_meta, indent=2), encoding="utf-8")
                meta_file = profile / "current_generation.json"
                meta_tmp.replace(meta_file)

                # Actualizar epg.xml y epg.xml.gz en la raíz de profile para retrocompatibilidad
                pid = os.getpid()
                root_xml_tmp = profile / f".epg_fallback_{pid}.xml.tmp"
                root_gz_tmp = profile / f".epg_fallback_{pid}.xml.gz.tmp"
                root_xml_tmp.write_bytes(data)
                with gzip.open(root_gz_tmp, "wb", compresslevel=9) as gz_out:
                    gz_out.write(data)
                root_xml_tmp.replace(target)
                root_gz_tmp.replace(target_gz)

                # Limpieza de generaciones antiguas (retener 3 más recientes)
                try:
                    all_gens = sorted(
                        [d for d in generations_dir.iterdir() if d.is_dir()],
                        key=lambda p: p.stat().st_mtime,
                        reverse=True,
                    )
                    for old_gen in all_gens[3:]:
                        for f in old_gen.iterdir():
                            try:
                                f.unlink()
                            except OSError:
                                pass
                        try:
                            old_gen.rmdir()
                        except OSError:
                            pass
                except Exception as clean_err:
                    logger.debug("Aviso limpiando generaciones antiguas de fallback: %s", clean_err)

                logger.info(
                    "Guía EPG de respaldo descargada y promovida a generación %s (%s, %s)",
                    gen_id, gen_xml, gen_gz,
                )
                _last_epg_download_success = time.monotonic()
                return gen_xml
            elif data:
                logger.warning("Guía EPG descargada no superó la validación estructural XMLTV")
        except Exception as exc:
            logger.warning("No se pudo descargar guía EPG desde respaldo remoto: %s", exc)
    return None


def _find_m3u_file(requested_name: str = "") -> Optional[Path]:
    """Busca una lista M3U local válida en los directorios estándar."""
    candidates = []
    try:
        candidates.append(_disney_bindings_target().parent)
    except Exception:
        pass
    try:
        import xbmcaddon
        import xbmcvfs
        addon = xbmcaddon.Addon("service.iptv.flowproxy")
        profile = Path(xbmcvfs.translatePath(addon.getAddonInfo("profile")))
        candidates.append(profile)
    except Exception:
        pass

    lib_dir = Path(__file__).resolve().parent
    candidates.extend([
        Path.home() / ".kodi" / "userdata" / "addon_data" / "service.iptv.flowproxy",
        lib_dir.parent / "data",
        lib_dir,
        Path.home() / "listas_gist",
        Path("/home/fer/listas_gist"),
        Path.home() / ".flow_cache",
        Path.home(),
        Path("/storage/emulated/0/Download"),
    ])

    search_names = []
    clean_name = requested_name.strip("/").strip()
    if clean_name and clean_name not in ("playlist.m3u", "channels.m3u"):
        search_names = [clean_name]
    elif clean_name == "channels.m3u":
        search_names = [
            "channels.m3u",
            "playlist.m3u",
            "kodi_canales_funcionales.m3u",
            "kodi_flowproxy_local.m3u",
        ]
    else:
        search_names = [
            "playlist.m3u",
            "kodi_canales_funcionales.m3u",
            "kodi_flowproxy_local.m3u",
            "channels.m3u",
        ]

    for folder in candidates:
        if not folder.is_dir():
            continue
        for sname in search_names:
            p = folder / sname
            if p.is_file() and p.stat().st_size > 0:
                return p

    return None


def get_m3u_slug_for_url(url: str, default_stem: str = "playlist") -> str:
    """Genera un nombre de archivo M3U único y determinista a partir de la URL completa.

    Evita que dos listas distintas con el mismo nombre de archivo (ej. dos canales.m3u)
    colisionen en el registro o compartan el mismo archivo de caché local.
    """
    if not url or not isinstance(url, str):
        return f"{default_stem}.m3u"
    clean_url = url.strip()
    parsed = urllib.parse.urlsplit(clean_url)
    path = parsed.path
    raw_name = path.rsplit("/", 1)[-1] if "/" in path else ""
    if raw_name.endswith(".m3u"):
        stem = raw_name[:-4]
    else:
        stem = default_stem
    clean_stem = re.sub(r"[^A-Za-z0-9_-]", "_", stem) or default_stem
    url_hash = hashlib.sha256(clean_url.encode("utf-8")).hexdigest()[:8]
    return f"{clean_stem}_{url_hash}.m3u"


M3U_SOURCES_FILE_NAME = "m3u_sources.json"
_m3u_sources_lock = threading.Lock()
_last_m3u_failure: Dict[str, float] = {}
M3U_CACHE_TTL = 300.0  # 5 minutos de validez de caché local
M3U_RETRY_INTERVAL = 15.0  # Cooldown tras fallo de red


def get_m3u_sources_file(profile_dir: Optional[Path] = None) -> Path:
    if profile_dir is not None:
        p = Path(profile_dir)
        if (p / "addon_data" / "service.iptv.flowproxy").is_dir():
            target_dir = p / "addon_data" / "service.iptv.flowproxy"
        else:
            target_dir = p
        target_dir.mkdir(parents=True, exist_ok=True)
        return target_dir / M3U_SOURCES_FILE_NAME

    try:
        profile = _disney_bindings_target().parent
    except Exception:
        profile = Path.home() / ".flow_cache"
    profile.mkdir(parents=True, exist_ok=True)
    return profile / M3U_SOURCES_FILE_NAME


def get_registered_m3u_sources(profile_dir: Optional[Path] = None) -> Dict[str, str]:
    target = get_m3u_sources_file(profile_dir)
    if not target.is_file():
        candidates = [
            Path.home() / ".kodi" / "userdata" / "addon_data" / "service.iptv.flowproxy" / M3U_SOURCES_FILE_NAME,
            Path.home() / ".flow_cache" / M3U_SOURCES_FILE_NAME,
        ]
        for c in candidates:
            if c.is_file():
                target = c
                break
    if not target.is_file():
        return {}
    try:
        data = json.loads(target.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return {str(k): str(v) for k, v in data.items()}
    except Exception as exc:
        logger.warning("Error leyendo %s: %s", target, exc)
    return {}


def register_m3u_source(name: str, url: str, profile_dir: Optional[Path] = None) -> None:
    if not name or not url:
        return
    clean_name = name.strip("/").strip()
    with _m3u_sources_lock:
        sources = get_registered_m3u_sources(profile_dir)
        sources[clean_name] = url.strip()
        target = get_m3u_sources_file(profile_dir)
        pid = os.getpid()
        tmp = target.with_name(f".{target.name}.{pid}.tmp")
        try:
            tmp.write_text(json.dumps(sources, indent=2), encoding="utf-8")
            tmp.replace(target)
        finally:
            if tmp.exists():
                try:
                    tmp.unlink()
                except OSError:
                    pass


def get_m3u_source(name: str, profile_dir: Optional[Path] = None) -> Optional[str]:
    clean = name.strip("/").strip()
    sources = get_registered_m3u_sources(profile_dir)
    if clean in sources:
        return sources[clean]
    if clean in ("playlist.m3u", "channels.m3u", "kodi_canales_funcionales.m3u"):
        return (
            sources.get(clean)
            or sources.get("playlist.m3u")
            or sources.get("kodi_canales_funcionales.m3u")
        )
    return None


def _sync_m3u_from_remote(
    requested_name: str, remote_url: str, force: bool = False
) -> Optional[Path]:
    """Descarga o revalida la lista M3U desde su fuente remota de forma atómica y sincronizada."""
    global _last_m3u_failure
    clean_name = requested_name.strip("/").strip()
    if not clean_name or not clean_name.endswith(".m3u"):
        clean_name = "playlist.m3u"

    profile = _disney_bindings_target().parent
    profile.mkdir(parents=True, exist_ok=True)
    target = profile / clean_name

    with _m3u_download_lock:
        now_mono = time.monotonic()
        now_epoch = time.time()
        last_failure = _last_m3u_failure.get(clean_name, 0.0)

        if not force:
            if target.is_file() and (now_epoch - target.stat().st_mtime < M3U_CACHE_TTL):
                return target
            if now_mono - last_failure < M3U_RETRY_INTERVAL:
                return target if target.is_file() else _find_m3u_file(clean_name)

        try:
            req = urllib.request.Request(
                remote_url,
                headers={
                    "User-Agent": USER_AGENT,
                    "Accept-Encoding": "gzip, deflate",
                    "Cache-Control": "no-cache",
                    "Pragma": "no-cache",
                },
            )
            ctx = ssl.create_default_context()
            try:
                resp = urllib.request.urlopen(req, timeout=20, context=ctx)
            except ssl.SSLError:
                ctx_unverified = ssl._create_unverified_context()
                resp = urllib.request.urlopen(req, timeout=20, context=ctx_unverified)
            with resp:
                if resp.status == 200:
                    raw_data = resp.read()
                    content_encoding = resp.headers.get("Content-Encoding", "").lower()
                    if "gzip" in content_encoding or raw_data.startswith(b"\x1f\x8b"):
                        try:
                            raw_data = gzip.decompress(raw_data)
                        except Exception as gz_err:
                            logger.warning("Error descomprimiendo gzip de M3U: %s", gz_err)
                    if raw_data and b"#EXTM3U" in raw_data:
                        pid = os.getpid()
                        tmp_p = profile / f".m3u_sync_{clean_name}_{pid}.tmp"
                        tmp_p.write_bytes(raw_data)
                        tmp_p.replace(target)
                        _last_m3u_failure.pop(clean_name, None)
                        logger.info(
                            "Lista M3U sincronizada exitosamente desde %s hacia %s",
                            remote_url,
                            target,
                        )
                        return target
            # Status != 200 o sin cabecera #EXTM3U: contar cooldown desde la finalización del fallo
            _last_m3u_failure[clean_name] = time.monotonic()
        except Exception as exc:
            # Contar cooldown desde la finalización del fallo
            _last_m3u_failure[clean_name] = time.monotonic()
            logger.warning("No se pudo sincronizar lista M3U desde %s: %s", remote_url, exc)

    return target if (target.is_file() and target.stat().st_size > 0) else _find_m3u_file(clean_name)


def _download_m3u_fallback(force: bool = False) -> Optional[Path]:
    """Descarga de respaldo la lista M3U del Gist remoto si no existe en disco local."""
    return _sync_m3u_from_remote(
        "kodi_canales_funcionales.m3u", REMOTE_M3U_FALLBACK_URL, force=force
    )


DISNEY_PROP_0 = [
    "#KODIPROP:inputstream.adaptive.stream_selection_type=adaptive",
    "#KODIPROP:inputstream.adaptive.chooser_bandwidth_max=4500000",
    "#KODIPROP:inputstream.adaptive.chooser_resolution_max=720p",
    "#KODIPROP:inputstream.adaptive.chooser_resolution_secure_max=720p",
]
DISNEY_PROP_1 = [
    "#KODIPROP:inputstream.adaptive.stream_selection_type=adaptive",
    "#KODIPROP:inputstream.adaptive.chooser_bandwidth_max=6000000",
    "#KODIPROP:inputstream.adaptive.chooser_resolution_max=1080p",
    "#KODIPROP:inputstream.adaptive.chooser_resolution_secure_max=1080p",
]
DISNEY_PROP_2 = [
    "#KODIPROP:inputstream.adaptive.stream_selection_type=adaptive",
]
DISNEY_PROP_3 = [
    "#KODIPROP:inputstream.adaptive.stream_selection_type=manual-osd",
]


def get_disney_quality_profile() -> int:
    """Retorna el perfil de calidad Disney+ configurado en el add-on (0..3)."""
    try:
        import xbmcaddon
        try:
            addon = xbmcaddon.Addon("service.iptv.flowproxy")
        except Exception:
            addon = xbmcaddon.Addon()
        val = addon.getSetting("disney_quality_profile")
        if val is not None and str(val).strip().isdigit():
            return int(val)
    except Exception:
        pass
    return 0


def transform_m3u_disney_profile(m3u_text: str, quality_profile: int) -> tuple[str, bool]:
    """Transforma las propiedades ISA de los streams Disney según el perfil configurado."""
    lines = m3u_text.splitlines()
    new_lines: list[str] = []
    current_block: list[str] = []
    changed = False

    target_props = (
        DISNEY_PROP_0
        if quality_profile == 0
        else DISNEY_PROP_1
        if quality_profile == 1
        else DISNEY_PROP_2
        if quality_profile == 2
        else DISNEY_PROP_3
    )

    prop_prefixes = (
        "#KODIPROP:inputstream.adaptive.stream_selection_type=",
        "#KODIPROP:inputstream.adaptive.chooser_bandwidth_max=",
        "#KODIPROP:inputstream.adaptive.chooser_resolution_max=",
        "#KODIPROP:inputstream.adaptive.chooser_resolution_secure_max=",
    )

    def process_block(block: list[str]) -> list[str]:
        nonlocal changed
        if not block:
            return []
        url_line = block[-1].strip()
        is_disney = (
            "/disney/" in url_line
            or any("/disney/" in l for l in block if l.startswith("#KODIPROP:"))
        )
        if not is_disney:
            return block

        filtered = []
        for l in block[:-1]:
            if any(l.strip().startswith(prefix) for prefix in prop_prefixes):
                continue
            filtered.append(l)

        insert_idx = len(filtered)
        for i, l in enumerate(filtered):
            if l.strip().startswith("#KODIPROP:inputstream.adaptive.manifest_type"):
                insert_idx = i + 1
                break

        reconstructed = filtered[:insert_idx] + target_props + filtered[insert_idx:] + [block[-1]]
        if reconstructed != block:
            changed = True
        return reconstructed

    for line in lines:
        if line.startswith("#EXTINF:"):
            if current_block:
                new_lines.extend(process_block(current_block))
                current_block = []
            current_block.append(line)
        elif current_block:
            current_block.append(line)
            if not line.startswith("#") and line.strip():
                new_lines.extend(process_block(current_block))
                current_block = []
        else:
            new_lines.append(line)

    if current_block:
        new_lines.extend(process_block(current_block))

    new_text = "\n".join(new_lines) + ("\n" if m3u_text.endswith("\n") else "")
    return new_text, changed


def sync_disney_bindings_from_remote(force: bool = False) -> Optional[Path]:
    """Descarga y valida el mapa de eventos Disney publicado por el radar."""
    global _last_bindings_download_attempt
    with _bindings_download_lock:
        now = time.monotonic()
        if not force and now - _last_bindings_download_attempt < 5 * 60:
            return _find_disney_bindings_file()
        _last_bindings_download_attempt = now
        try:
            separator = "&" if "?" in DISNEY_BINDINGS_URL else "?"
            bindings_url = (
                DISNEY_BINDINGS_URL
                + separator
                + urllib.parse.urlencode({"generation_check": int(time.time() // 60)})
            )
            request = urllib.request.Request(
                bindings_url,
                headers={
                    "User-Agent": USER_AGENT,
                    "Cache-Control": "no-cache",
                    "Pragma": "no-cache",
                },
            )
            with urllib.request.urlopen(
                request, timeout=12.0, context=ssl.create_default_context()
            ) as response:
                raw = response.read(2 * 1024 * 1024 + 1)
            if len(raw) > 2 * 1024 * 1024:
                raise ValueError("mapa Disney remoto demasiado grande")
            payload = json.loads(raw.decode("utf-8"))
            if not isinstance(payload, dict) or not payload or len(payload) > 2000:
                raise ValueError("mapa Disney remoto vacío o inválido")
            for binding, item in payload.items():
                if not re.fullmatch(r"disney-(?:linear|live)-[A-Za-z0-9_-]+", binding):
                    raise ValueError(f"binding Disney inválido: {binding}")
                if not isinstance(item, dict) or not isinstance(item.get("resource_id"), str) or not item["resource_id"]:
                    raise ValueError(f"resource_id ausente para {binding}")

            target = _disney_bindings_target()
            fd, temporary = tempfile.mkstemp(
                prefix="disney_bindings_", suffix=".tmp", dir=str(target.parent)
            )
            try:
                os.fchmod(fd, 0o600)
                with os.fdopen(fd, "wb") as handle:
                    fd = -1
                    handle.write(raw)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(temporary, target)
            finally:
                if fd >= 0:
                    os.close(fd)
                try:
                    os.unlink(temporary)
                except FileNotFoundError:
                    pass
            try:
                loc_xml = target.parent / "epg.xml"
                loc_gz = target.parent / "epg.xml.gz"
                if loc_xml.is_file() or loc_gz.is_file():
                    update_epg_files_with_disney_live(
                        loc_xml if loc_xml.is_file() else None,
                        loc_gz if loc_gz.is_file() else None,
                        payload,
                    )
            except Exception as epg_err:
                logger.debug("Aviso actualizando EPG local con bindings Disney: %s", epg_err)
            return target
        except Exception as error:
            logger.warning("No se pudo actualizar el mapa remoto Disney: %s", error)
            return None



def extract_seed_rel(entry: Any) -> Tuple[Optional[str], Optional[str]]:
    """Extrae y valida la ruta relativa del seed desde una entrada de mapping.

    Retorna (seed_rel, error_reason). Si es válida, error_reason es None.
    """
    if entry is None:
        return None, "slug_not_found"

    if isinstance(entry, dict):
        seed = entry.get("seed_rel")
    elif isinstance(entry, str):
        seed = entry
    else:
        return None, "invalid_type"

    if not isinstance(seed, str) or not seed.strip():
        return None, "empty_seed_rel"

    seed = seed.strip()
    if ".." in seed:
        return None, "path_traversal"
    if seed.startswith("/"):
        return None, "absolute_path"
    if "://" in seed:
        return None, "external_host"

    return seed, None


def strip_content_protection(mpd_bytes: bytes, remote_url: str) -> bytes:
    """Quita el <ContentProtection> y hace absolutas las URLs del MPD.

    Varios CDN (PlayMe) DECLARAN Widevine + FairPlay + cenc en el manifiesto pero sirven
    el video EN CLARO. Si ese manifiesto llega tal cual a InputStream Adaptive, el addon
    de Kodi intenta inicializar DRM, no encuentra licencia ni clave, y el canal FALLA
    aunque el stream funcione. Se elimina la declaración de cifrado y se reescribe el
    BaseURL para que los segmentos se pidan al CDN real y no a 127.0.0.1.
    """
    try:
        root = ET.fromstring(mpd_bytes)
    except ET.ParseError:
        return mpd_bytes
    for parent in root.iter():
        for child in list(parent):
            if child.tag.rsplit("}", 1)[-1] == "ContentProtection":
                parent.remove(child)
    namespace_uri = "urn:mpeg:dash:schema:mpd:2011"
    namespace = f"{{{namespace_uri}}}"
    has_base_url = False
    for elem in root.iter():
        if elem.tag.rsplit("}", 1)[-1] != "BaseURL":
            continue
        has_base_url = True
        if elem.text and elem.text.strip():
            elem.text = urljoin(remote_url, elem.text.strip())
    if not has_base_url:
        base = ET.Element(f"{namespace}BaseURL")
        base.text = urljoin(remote_url, ".")
        root.insert(0, base)
    # ElementTree usa el prefijo artificial ``ns0`` si no se registra el
    # namespace por defecto. Aunque XML válido, InputStream Adaptive/Kodi puede
    # rechazar ese MPD DASH. Mantener el namespace DASH por defecto conserva el
    # formato que entrega el CDN.
    ET.register_namespace("", namespace_uri)
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def fetch_clear_manifest(url: str) -> Tuple[bytes, str]:
    """Descarga el manifiesto siguiendo redirecciones y devuelve (cuerpo, url_final)."""
    ctx = ssl.create_default_context()
    # Mismo criterio que el resolver: Kodi en Android no siempre tiene el almacén de CAs.
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=15, context=ctx) as response:
        return response.read(), response.geturl()


class FlowProxyHandler(http.server.BaseHTTPRequestHandler):
    resolver = FlowSessionResolver()
    dgo_resolver = DgoSessionResolver()
    flow_auth = FlowAuthManager()

    # Proveedor Disney+ (BAMGrid)
    disney_registry = PlaybackRegistry()
    disney_transport = DefaultHttpTransport()
    disney_contract = ChromeWebContract()
    disney_playback = DisneyPlaybackEngine(transport=disney_transport, contract=disney_contract)
    disney_license = DisneyLicenseProxy(
        registry=disney_registry, transport=disney_transport, contract=disney_contract
    )
    disney_session = DisneySessionManager()
    _last_bindings_mtime: float = 0.0

    # Proveedor Sensa (Pontis PRM)
    sensa_session = SensaSessionManager()
    sensa_playback = SensaPlaybackEngine(session_manager=sensa_session)

    BINDINGS_RETRY_INTERVAL = 10.0
    BINDINGS_FRESHNESS_TTL = 300.0
    _bindings_sync_lock = threading.Lock()
    _last_bindings_sync_attempt: float = 0.0

    @classmethod
    def _sync_bindings_if_modified(cls) -> None:
        """Sincroniza bindings desde disco si el archivo fue actualizado por el radar o si la memoria está vacía."""
        bfile = _find_disney_bindings_file()
        if not bfile:
            return
        try:
            mtime = bfile.stat().st_mtime
            if mtime > cls._last_bindings_mtime or not getattr(cls.disney_registry, "_records", None):
                cls.disney_registry.load_from_file(bfile)
                cls._last_bindings_mtime = mtime
        except Exception as e:
            logger.debug("Error comprobando mtime de bindings Disney: %s", e)

    @classmethod
    def _ensure_disney_binding(cls, binding: str) -> Optional[BindingRecord]:
        """Asegura que el binding esté disponible en memoria, cargando de disco o sincronizando bajo demanda."""
        cls._sync_bindings_if_modified()
        record = cls.disney_registry.get_binding(binding)
        bfile = _find_disney_bindings_file()

        now_mono = time.monotonic()
        now_epoch = time.time()

        is_stale = (
            bfile is not None
            and (now_epoch - bfile.stat().st_mtime >= cls.BINDINGS_FRESHNESS_TTL)
        )

        # Si tenemos un registro en memoria y no está stale, devolver inmediatamente
        if record is not None and not is_stale:
            return record

        # Si estamos dentro de la ventana de cooldown de reintentos, no intentar red
        if now_mono - cls._last_bindings_sync_attempt < cls.BINDINGS_RETRY_INTERVAL:
            return record

        # Sincronización protegida por lock de un solo vuelo (single-flight)
        with cls._bindings_sync_lock:
            # Doble comprobación tras adquirir el cerrojo
            now_mono = time.monotonic()
            if now_mono - cls._last_bindings_sync_attempt < cls.BINDINGS_RETRY_INTERVAL:
                cls._sync_bindings_if_modified()
                return cls.disney_registry.get_binding(binding) or record

            # Comprobar si otra solicitud concurrente ya actualizó el mapa mientras esperábamos el cerrojo
            cls._sync_bindings_if_modified()
            record = cls.disney_registry.get_binding(binding)
            bfile = _find_disney_bindings_file()
            now_epoch = time.time()
            if record is not None and (
                bfile is not None
                and now_epoch - bfile.stat().st_mtime < cls.BINDINGS_FRESHNESS_TTL
            ):
                return record

            prior_mtime = bfile.stat().st_mtime if bfile and bfile.is_file() else 0.0
            try:
                updated_file = sync_disney_bindings_from_remote(force=True)
                is_fresh_download = (
                    updated_file is not None
                    and updated_file.is_file()
                    and updated_file.stat().st_mtime > prior_mtime
                )
                if is_fresh_download:
                    cls.disney_registry.load_from_file(updated_file)
                    cls._last_bindings_mtime = updated_file.stat().st_mtime
                    fresh_record = cls.disney_registry.get_binding(binding)
                    if fresh_record:
                        return fresh_record
                else:
                    # La descarga remota falló: registrar cooldown desde la finalización del fallo
                    cls._last_bindings_sync_attempt = time.monotonic()
            except Exception as e:
                # Si ocurrió una excepción, registrar cooldown desde la finalización del fallo
                cls._last_bindings_sync_attempt = time.monotonic()
                logger.warning(
                    "Error recargando bindings Disney tras sincronización bajo demanda: %s",
                    e,
                )

        return cls.disney_registry.get_binding(binding) or record

    _notification_lock = threading.Lock()
    _last_notification: Dict[str, float] = {}

    @classmethod
    def _notify_once(cls, key: str, message: str, interval: float = 60.0) -> None:
        import time

        now = time.monotonic()
        with cls._notification_lock:
            if now - cls._last_notification.get(key, 0.0) < interval:
                return
            cls._last_notification[key] = now
        try:
            import xbmc
            safe_message = message.replace(",", " ").replace(")", " ")[:120]
            xbmc.executebuiltin(
                f"Notification(DGO,Canal temporalmente no disponible: {safe_message},5000)"
            )
        except Exception:
            pass

    def handle_one_request(self) -> None:
        """Trata el abandono de Kodi como cancelación normal, sin traceback."""
        try:
            super().handle_one_request()
        except CLIENT_DISCONNECT_ERRORS as error:
            self.close_connection = True
            logger.debug("Cliente local canceló la petición: %s", error)

    def send_error(self, code: int, message=None, explain=None) -> None:
        try:
            super().send_error(code, message, explain)
        except CLIENT_DISCONNECT_ERRORS as error:
            self.close_connection = True
            logger.debug("Cliente local se desconectó antes del error HTTP: %s", error)

    def _write_body(self, body: bytes) -> bool:
        try:
            self.wfile.write(body)
            return True
        except CLIENT_DISCONNECT_ERRORS as error:
            self.close_connection = True
            logger.debug("Cliente local canceló la respuesta: %s", error)
            return False

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS, HEAD")
        self.send_header("Access-Control-Allow-Headers", "authorization, content-type, range, x-playback-rights-authorization")
        self.end_headers()

    def _prefer_clearkey_for(self, slug: str, drm_param: str) -> bool:
        """Decide el modo DRM de un canal DASH con una sola descarga de manifest.

        - ``?drm=widevine`` / ``?drm=clearkey`` respetan lo pedido por la lista.
        - Sin parámetro sólo se consulta la bóveda si hay claves publicadas; con
          la bóveda vacía (caso actual) se sirve Widevine directo, sin descargar
          el manifest dos veces ni dormir 0.4 s en cada zapping.
        """
        if drm_param == "widevine":
            return False
        if drm_param == "clearkey":
            return True
        try:
            if not self.dgo_resolver.has_clearkeys():
                return False
            return self.dgo_resolver.clearkey_status(slug).get("mode") == "clearkey"
        except Exception:
            return False

    def _serve_epg(self, path: str, is_head: bool = False) -> None:
        """Sirve el archivo XMLTV EPG generado localmente para Kodi IPTV Simple Client."""
        epg_xml, epg_gz = _find_epg_files()
        want_gz = path.endswith(".gz")

        target_file = None
        content_type = "application/xml; charset=utf-8"
        need_compress = False
        need_decompress = False

        if want_gz:
            if epg_gz and epg_gz.is_file():
                target_file = epg_gz
                content_type = "application/gzip"
            elif epg_xml and epg_xml.is_file():
                target_file = epg_xml
                content_type = "application/gzip"
                need_compress = True
        else:
            if epg_xml and epg_xml.is_file():
                target_file = epg_xml
                content_type = "application/xml; charset=utf-8"
            elif epg_gz and epg_gz.is_file():
                target_file = epg_gz
                content_type = "application/xml; charset=utf-8"
                need_decompress = True

        if not target_file or not target_file.is_file():
            fallback = _download_epg_fallback()
            if fallback and fallback.is_file():
                target_file = fallback
                if want_gz:
                    need_compress = True
                    content_type = "application/gzip"
                else:
                    content_type = "application/xml; charset=utf-8"
        elif (time.time() - target_file.stat().st_mtime > 12 * 3600):
            # Un solo hilo de refresco: antes cada request con la guía vencida
            # abría su propia descarga (tormenta de EPG con varios clientes).
            _schedule_epg_refresh(force=True)

        if not target_file or not target_file.is_file():
            self.send_error(404, "Guía EPG local no encontrada")
            return

        # Si existe un disney_bindings.json más reciente en el mismo directorio, sincronizar el EPG antes de servir
        try:
            sibling_bindings = target_file.parent / "disney_bindings.json"
            if (
                sibling_bindings.is_file()
                and sibling_bindings.stat().st_mtime > target_file.stat().st_mtime
            ):
                b_data = json.loads(sibling_bindings.read_text(encoding="utf-8"))
                if isinstance(b_data, dict) and b_data:
                    sib_xml = target_file.parent / "epg.xml"
                    sib_gz = target_file.parent / "epg.xml.gz"
                    update_epg_files_with_disney_live(
                        sib_xml if sib_xml.is_file() else None,
                        sib_gz if sib_gz.is_file() else None,
                        b_data,
                    )
        except Exception as epg_sync_err:
            logger.debug("Aviso sincronizando EPG bajo demanda con bindings Disney: %s", epg_sync_err)

        f = None
        try:
            try:
                f = open(target_file, "rb")
            except OSError:
                self.send_error(404, "Guía EPG local no encontrada")
                return

            st = os.fstat(f.fileno())
            size = st.st_size
            mtime = st.st_mtime
            mtime_ns = getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9))
            last_modified = email.utils.formatdate(mtime, usegmt=True)
            # ETag fuerte basado en inodo, nanosegundos y tamaño para evitar colisiones
            etag = f'"{st.st_ino:x}-{mtime_ns:x}-{size:x}"'

            # Revalidación condicional HTTP 304 Not Modified (RFC 9110)
            inm = self.headers.get("If-None-Match")
            ims = self.headers.get("If-Modified-Since")
            not_modified = False

            if inm:
                client_etags = [t.strip() for t in inm.split(",")]
                if etag in client_etags or "*" in client_etags:
                    not_modified = True
            elif ims:
                try:
                    parsed_ims = email.utils.parsedate_to_datetime(ims)
                    if mtime <= parsed_ims.timestamp():
                        not_modified = True
                except Exception:
                    pass

            if not_modified:
                self.send_response(304)
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "public, max-age=3600")
                self.send_header("Last-Modified", last_modified)
                self.send_header("ETag", etag)
                # RFC 9110: Omitir Content-Length en 304 para evitar inconsistencias
                self.end_headers()
                return

            if not need_compress and not need_decompress:
                self.send_response(200)
                self.send_header("Content-Type", content_type)
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "public, max-age=3600")
                self.send_header("Last-Modified", last_modified)
                self.send_header("ETag", etag)
                self.send_header("Content-Length", str(size))
                self.end_headers()
                if not is_head:
                    while chunk := f.read(65536):
                        if not self._write_body(chunk):
                            break
                return

            raw_bytes = target_file.read_bytes()
            if need_compress:
                import gzip
                raw_bytes = gzip.compress(raw_bytes, compresslevel=6)
            elif need_decompress:
                import gzip
                raw_bytes = gzip.decompress(raw_bytes)

            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Cache-Control", "public, max-age=3600")
            self.send_header("Last-Modified", last_modified)
            self.send_header("ETag", etag)
            self.send_header("Content-Length", str(len(raw_bytes)))
            self.end_headers()
            if not is_head:
                for offset in range(0, len(raw_bytes), 65536):
                    chunk = raw_bytes[offset : offset + 65536]
                    if not self._write_body(chunk):
                        break
        except CLIENT_DISCONNECT_ERRORS as error:
            self.close_connection = True
            logger.debug("Kodi canceló la descarga de EPG: %s", error)
        except Exception as e:
            logger.error("Error sirviendo EPG local: %s", e)
            self.send_error(500, f"Error sirviendo EPG: {e}")
        finally:
            if f:
                try:
                    f.close()
                except Exception:
                    pass

    def _serve_m3u(self, path: str, is_head: bool = False) -> None:
        """Sirve la lista M3U transformando dinámicamente las propiedades Disney según el perfil configurado."""
        parsed_url = urllib.parse.urlsplit(path)
        clean_path = urllib.parse.unquote(parsed_url.path)
        req_name = clean_path.split("/")[-1]
        if not req_name or not req_name.endswith(".m3u"):
            req_name = "playlist.m3u"

        query_params = urllib.parse.parse_qs(parsed_url.query)
        custom_src = (
            (query_params.get("src") or [None])[0]
            or (query_params.get("url") or [None])[0]
        )
        if custom_src:
            register_m3u_source(req_name, custom_src)

        remote_url = custom_src or get_m3u_source(req_name)
        if not remote_url and req_name in ("playlist.m3u", "channels.m3u", "kodi_canales_funcionales.m3u"):
            remote_url = REMOTE_M3U_FALLBACK_URL

        # Buscar archivo local existente
        m3u_file = _find_m3u_file(req_name)

        # Si existe archivo local, servirlo de inmediato (0 ms); revalidar en segundo plano si expiró el TTL
        now_epoch = time.time()
        if remote_url:
            if not m3u_file or not m3u_file.is_file():
                synced_file = _sync_m3u_from_remote(req_name, remote_url)
                if synced_file and synced_file.is_file():
                    m3u_file = synced_file
            else:
                file_age = now_epoch - m3u_file.stat().st_mtime
                if file_age >= M3U_CACHE_TTL:
                    threading.Thread(
                        target=lambda: _sync_m3u_from_remote(req_name, remote_url),
                        daemon=True,
                    ).start()

        if not m3u_file or not m3u_file.is_file():
            self.send_error(404, "Lista M3U no encontrada")
            return

        try:
            raw_text = m3u_file.read_text(encoding="utf-8", errors="ignore")
        except Exception as err:
            logger.error("Error leyendo archivo M3U %s: %s", m3u_file, err)
            self.send_error(500, f"Error leyendo M3U: {err}")
            return

        quality_profile = get_disney_quality_profile()
        transformed, _ = transform_m3u_disney_profile(raw_text, quality_profile)
        body = transformed.encode("utf-8")

        # Generar ETag fuerte basado en el contenido efectivo (cambia sólo cuando hay nuevos eventos/canales o cambia el perfil)
        mtime = m3u_file.stat().st_mtime
        content_hash = hashlib.sha256(body).hexdigest()[:16]
        etag = f'"{content_hash}"'
        last_modified = email.utils.formatdate(mtime, usegmt=True)

        if_none_match = (self.headers.get("If-None-Match") or "").strip()
        if if_none_match == etag:
            self.send_response(304)
            self.send_header("ETag", etag)
            self.send_header("Last-Modified", last_modified)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            return

        self.send_response(200)
        self.send_header("Content-Type", "application/vnd.apple.mpegurl; charset=utf-8")
        self.send_header("ETag", etag)
        self.send_header("Last-Modified", last_modified)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()

        if not is_head:
            self._write_body(body)

    def do_HEAD(self) -> None:
        path = urllib.parse.unquote(urllib.parse.urlsplit(self.path).path)
        if path in ("/epg.xml", "/epg.xml.gz", "/epg"):
            self._serve_epg(path, is_head=True)
            return
        if path.endswith(".m3u"):
            self._serve_m3u(path, is_head=True)
            return
        if "/disney/live/" in path:
            raw_slug = path.split("/disney/live/")[-1]
            binding = re.sub(r"\.(mpd|m3u8)$", "", raw_slug, flags=re.IGNORECASE).strip()
            if not binding or not re.match(r"^[a-zA-Z0-9_\-]+$", binding):
                self.send_error(400, f"Identificador de binding inválido: {binding}")
                return
            record = self._ensure_disney_binding(binding)
            if not record:
                self.send_error(404, f"Binding Disney desconocido: {binding}")
                return
            self.send_response(200)
            self.send_header("Content-Type", "application/vnd.apple.mpegurl")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Cache-Control", "no-cache, no-store")
            self.end_headers()
        else:
            self.send_error(404, "Endpoint HEAD no reconocido")

    def do_POST(self) -> None:
        path = urllib.parse.unquote(self.path)
        if urllib.parse.urlsplit(path).path.startswith("/dgo/license/"):
            raw_id = path.split("/dgo/license/")[-1].split("?")[0].strip()
            if not raw_id:
                self.send_error(400, "Falta contentId en la ruta de licencia")
                return
            if raw_id.lower() not in DRM_ID_TO_SLUG:
                self.send_error(404, "contentId DGO desconocido")
                return

            try:
                length = int(self.headers.get("Content-Length", 0))
            except (ValueError, TypeError):
                length = 0

            if length <= 0:
                self.send_error(400, "Challenge Widevine vacío")
                return
            if length > MAX_WIDEVINE_CHALLENGE_BYTES:
                self.send_error(413, "Challenge Widevine demasiado grande")
                return

            challenge_data = self.rfile.read(length)
            if len(challenge_data) != length:
                self.send_error(400, "Challenge Widevine truncado")
                return
            try:
                status, license_bytes, _ = self.dgo_resolver.proxy_license(raw_id, challenge_data)
                self.send_response(status)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "no-cache, no-store")
                self.send_header("Content-Length", str(len(license_bytes)))
                self.end_headers()
                self._write_body(license_bytes)
            except CLIENT_DISCONNECT_ERRORS as error:
                self.close_connection = True
                logger.debug("Kodi canceló una licencia DGO en vuelo: %s", error)
            except Exception as e:
                logger.error("Error en proxy de licencia DGO %s: %s", raw_id, e)
                self.send_error(503, "Error temporal del proxy de licencia DGO")
        elif urllib.parse.urlsplit(path).path.startswith("/flow/license/"):
            raw_id = path.split("/flow/license/")[-1].split("?")[0].strip()
            if not raw_id:
                self.send_error(400, "Falta identificador de canal en la ruta de licencia Flow")
                return

            try:
                length = int(self.headers.get("Content-Length", 0))
            except (ValueError, TypeError):
                length = 0

            if length <= 0:
                self.send_error(400, "Challenge Widevine vacío")
                return
            if length > MAX_WIDEVINE_CHALLENGE_BYTES:
                self.send_error(413, "Challenge Widevine demasiado grande")
                return

            challenge_data = self.rfile.read(length)
            if len(challenge_data) != length:
                self.send_error(400, "Challenge Widevine truncado")
                return

            try:
                status, license_bytes, _ = self.flow_auth.proxy_license(raw_id, challenge_data)
                self.send_response(status)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "no-cache, no-store")
                self.send_header("Content-Length", str(len(license_bytes)))
                self.end_headers()
                self._write_body(license_bytes)
            except CLIENT_DISCONNECT_ERRORS as error:
                self.close_connection = True
                logger.debug("Kodi canceló una licencia Flow en vuelo: %s", error)
            except Exception as e:
                logger.error("Error en proxy de licencia Flow %s: %s", raw_id, e)
                self.send_error(503, "Error temporal del proxy de licencia Flow")
        elif urllib.parse.urlsplit(path).path.startswith("/disney/license/"):
            raw_id = path.split("/disney/license/")[-1].split("?")[0].strip()
            binding = re.sub(r"\.(mpd|m3u8)$", "", raw_id, flags=re.IGNORECASE).strip()
            if not binding or not re.match(r"^[a-zA-Z0-9_\-]+$", binding):
                self.send_error(400, "Identificador de binding inválido en la ruta de licencia Disney")
                return

            # 1. Leer el cuerpo binario del challenge antes de resolver red o adquirir locks
            try:
                length = int(self.headers.get("Content-Length", 0))
            except (ValueError, TypeError):
                length = 0

            if length <= 0:
                self.send_error(400, "Challenge Widevine vacío")
                return
            if length > MAX_WIDEVINE_CHALLENGE_BYTES:
                self.send_error(413, "Challenge Widevine demasiado grande")
                return

            challenge_data = self.rfile.read(length)
            if len(challenge_data) != length:
                self.send_error(400, "Challenge Widevine truncado")
                return

            # 2. Obtener o resolver en caliente el contexto de derechos DRM
            context = self.disney_registry.get_license_context(binding)
            if not context:
                record = self._ensure_disney_binding(binding)
                if not record:
                    self.send_error(404, f"Contexto de licencia Disney no encontrado o expirado para binding '{binding}'")
                    return

                # El binding es conocido pero carece de contexto o expiró: resolución en caliente acotada
                snapshot = self.disney_session.get_access_token_snapshot(timeout_seconds=5.0)
                if not snapshot:
                    _notify_kodi_throttled("Disney+ DRM", "Sesión expirada. Encienda la PC para sincronizar.", is_error=True)
                    self.send_error(401, "Disney no autenticado o sesión expirada")
                    return

                def _resolve_upstream_lic(rec: Optional[BindingRecord] = None) -> PlaybackContext:
                    target_rec = rec if rec is not None else self.disney_registry.get_binding(binding)
                    current_res_id = target_rec.resource_id if target_rec else record.resource_id
                    current_content_type = target_rec.content_type if target_rec else record.content_type
                    current_snap = self.disney_session.get_access_token_snapshot(timeout_seconds=3.0) or snapshot
                    return self.disney_playback.resolve(
                        resource_id=current_res_id,
                        content_type=current_content_type,
                        access_token=current_snap.token,
                    )

                try:
                    updated_record, _ = self.disney_registry.resolve_single_flight(
                        binding, _resolve_upstream_lic, timeout_seconds=3.5
                    )
                    context = updated_record.playback_context
                except Exception as resolve_err:
                    logger.warning("Fallo en resolución en caliente de licencia Disney para %s: %s", binding, resolve_err)
                    self.send_error(503, f"No se pudo recuperar contexto de licencia para {binding}")
                    return

            if not context:
                self.send_error(404, f"Contexto de licencia Disney no encontrado o expirado para binding '{binding}'")
                return

            snapshot = self.disney_session.get_access_token_snapshot()
            if not snapshot:
                self.send_error(401, "Disney no autenticado o sesión expirada")
                return

            try:
                status, license_bytes, _ = self.disney_license.proxy_license(
                    binding=binding,
                    challenge_bytes=challenge_data,
                    access_token=snapshot.token,
                    context=context,
                )

                # Reintento único ante 401 inequívocamente de autenticación
                if status == 401:
                    logger.warning(
                        "Licencia Disney devolvió 401. Intentando refresco único para generación %d...",
                        snapshot.token_generation,
                    )
                    try:
                        new_snap = self.disney_session.refresh_if_generation(
                            failed_generation=snapshot.token_generation,
                            timeout_seconds=10.0,
                        )
                        status, license_bytes, _ = self.disney_license.proxy_license(
                            binding=binding,
                            challenge_bytes=challenge_data,
                            access_token=new_snap.token,
                            context=context,
                        )
                    except Exception as ref_err:
                        logger.warning("Fallo al refrescar token para reintento de licencia: %s", ref_err)

                self.send_response(status)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "no-cache, no-store")
                self.send_header("Content-Length", str(len(license_bytes)))
                self.end_headers()
                self._write_body(license_bytes)
            except UpstreamHttpError as err:
                self.send_error(err.status, f"Error upstream Disney Widevine {err.status}")
            except CLIENT_DISCONNECT_ERRORS as error:
                self.close_connection = True
                logger.debug("Kodi canceló una licencia Disney en vuelo: %s", error)
            except Exception as e:
                logger.error("Error en proxy de licencia Disney %s: %s", binding, e)
                self.send_error(503, "Error temporal del proxy de licencia Disney")
        else:
            self.send_error(404, "Endpoint POST no reconocido")

    def do_GET(self) -> None:
        path = urllib.parse.unquote(urllib.parse.urlsplit(self.path).path)
        if path == "/sync":
            try:
                res_m3u = _sync_m3u_from_remote("kodi_canales_funcionales.m3u", REMOTE_M3U_FALLBACK_URL, force=True)
                res_epg = _download_epg_fallback(force=True)
                res_vault = _download_dgo_vault_fallback(force=True)
                scan_triggered = False
                try:
                    import xbmc
                    scan_req = json.dumps({"jsonrpc": "2.0", "id": "manual_sync_scan", "method": "PVR.Scan"})
                    xbmc.executeJSONRPC(scan_req)
                    scan_triggered = True
                except Exception:
                    pass

                body = json.dumps({
                    "status": "ok",
                    "m3u_updated": res_m3u is not None and res_m3u.is_file(),
                    "epg_updated": res_epg is not None and res_epg.is_file(),
                    "vault_updated": res_vault is not None and res_vault.is_file(),
                    "pvr_scan_triggered": scan_triggered,
                }).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "no-cache, no-store")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self._write_body(body)
                return
            except Exception as sync_err:
                logger.error("Error en sincronización manual vía /sync: %s", sync_err)
                self.send_error(500, f"Error en sincronización manual: {sync_err}")
                return
        elif path.startswith("/dgo/clearkeys/"):
            # Decisión ClearKey vs Widevine basada en el KID vivo del manifest.
            raw_slug = path.split("/dgo/clearkeys/")[-1]
            slug = re.sub(r"\.(mpd|m3u8)$", "", raw_slug, flags=re.IGNORECASE).strip().lower()
            if not slug or not re.match(r"^[a-z0-9_\-]+$", slug):
                self.send_error(400, f"Slug DGO inválido: {slug}")
                return
            try:
                status_data = self.dgo_resolver.clearkey_status(slug)
            except ValueError:
                self.send_error(404, f"Canal DGO no encontrado: {slug}")
                return
            except CLIENT_DISCONNECT_ERRORS as error:
                self.close_connection = True
                logger.debug("Kodi canceló la consulta ClearKey DGO: %s", error)
                return
            except Exception as error:  # noqa: BLE001
                logger.error("Error evaluando ClearKey DGO %s: %s", slug, error)
                self.send_error(503, f"Error evaluando ClearKey DGO {slug}")
                return
            body = json.dumps(status_data).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Cache-Control", "no-cache, no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self._write_body(body)
        elif "/dgo/live/" in path:
            raw_slug = path.split("/dgo/live/")[-1]
            requested_hls = raw_slug.lower().endswith(".m3u8")
            slug = re.sub(r"\.(mpd|m3u8)$", "", raw_slug, flags=re.IGNORECASE).strip().lower()
            query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            drm_param = (query.get("drm", [""])[0] or "").strip().lower()
            try:
                if requested_hls:
                    # Las señales FAST son HLS claro. El 302 mantiene al proxy fuera
                    # del transporte de segmentos y permite que Kodi resuelva todas
                    # las playlists relativas contra la URL final de Amagi.
                    # La detección de DRM de abajo NO se ejecuta acá: antes se
                    # consultaba el manifest DASH incluso para canales HLS.
                    target_url = self.dgo_resolver.get_hls_url(slug)
                    self.send_response(302)
                    self.send_header("Location", target_url)
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.send_header("Cache-Control", "no-cache, no-store")
                    self.end_headers()
                else:
                    prefer_clearkey = self._prefer_clearkey_for(slug, drm_param)
                    manifest_bytes = self.dgo_resolver.get_manifest(
                        slug, prefer_clearkey=prefer_clearkey
                    )
                    self.send_response(200)
                    self.send_header("Content-Type", "application/dash+xml")
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.send_header("Cache-Control", "no-cache, no-store")
                    self.send_header("Content-Length", str(len(manifest_bytes)))
                    self.end_headers()
                    self._write_body(manifest_bytes)
            except ChannelTemporarilyUnavailable as error:
                self._notify_once(slug, str(error))
                self.send_response(503, "Canal temporalmente no disponible")
                self.send_header("Retry-After", "60")
                self.send_header("Content-Length", "0")
                self.end_headers()
            except ValueError as e:
                self.send_error(404, f"Canal DGO no encontrado: {slug}")
            except CLIENT_DISCONNECT_ERRORS as error:
                self.close_connection = True
                logger.debug("Kodi canceló un manifiesto DGO en vuelo: %s", error)
            except Exception as e:
                logger.error("Error resolviendo canal DGO %s: %s", slug, e)
                self.send_error(503, f"Error resolviendo canal DGO {slug}: {e}")
        elif "/kodi/clear/" in path:
            # Manifiesto saneado: se sirve SIN la declaración de DRM falsa.
            raw_slug = path.split("/kodi/clear/")[-1]
            slug = re.sub(r"\.(mpd|m3u8)$", "", raw_slug, flags=re.IGNORECASE).strip().lower()
            entry = SLUG_MAPPINGS.get(f"clear:{slug}")
            if not isinstance(entry, dict) or not entry.get("clear_url"):
                self.send_error(404, f"Manifiesto claro no encontrado: {slug}")
                return
            try:
                body, final_url = fetch_clear_manifest(str(entry["clear_url"]))
                saneado = strip_content_protection(body, final_url)
            except Exception as e:  # noqa: BLE001
                self.send_error(503, f"Error obteniendo manifiesto {slug}: {e}")
                return
            self.send_response(200)
            self.send_header("Content-Type", "application/dash+xml")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Cache-Control", "no-cache, no-store")
            self.send_header("Content-Length", str(len(saneado)))
            self.end_headers()
            self._write_body(saneado)
        elif "/flow/live/" in path or "/kodi/live/" in path:
            prefix = "/flow/live/" if "/flow/live/" in path else "/kodi/live/"
            raw_slug = path.split(prefix)[-1]
            slug = re.sub(r"\.(mpd|m3u8)$", "", raw_slug, flags=re.IGNORECASE).strip().lower()

            entry = SLUG_MAPPINGS.get(slug)
            target_rel, err = extract_seed_rel(entry)

            if err == "slug_not_found":
                self.send_error(404, f"Canal no encontrado: {slug}")
                return
            elif err:
                self.send_error(400, f"Ruta de seed inválida para canal {slug}: {err}")
                return

            try:
                target_url = self.resolver.resolve_stream(slug, target_rel)

                self.send_response(302)
                self.send_header("Location", target_url)
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "no-cache, no-store")
                self.end_headers()
            except Exception as e:
                self.send_error(503, f"Error resolviendo canal {slug}: {e}")
        elif "/disney/live/" in path:
            raw_slug = path.split("/disney/live/")[-1]
            binding = re.sub(r"\.(mpd|m3u8)$", "", raw_slug, flags=re.IGNORECASE).strip()
            if not binding or not re.match(r"^[a-zA-Z0-9_\-]+$", binding):
                self.send_error(400, f"Identificador de binding inválido: {binding}")
                return

            # Sincronizar bindings si el radar los actualizó en disco o bajo demanda
            record = self._ensure_disney_binding(binding)
            if not record:
                self.send_error(404, f"Binding Disney desconocido: {binding}")
                return

            snapshot = self.disney_session.get_access_token_snapshot()
            if not snapshot:
                _notify_kodi_throttled("Disney+ (FlowProxy)", "Sesión expirada. Encienda la PC para sincronizar.", is_error=True)
                self.send_error(401, "Disney no autenticado o sesión expirada")
                return

            try:
                def _resolve_upstream(rec: Optional[BindingRecord] = None) -> PlaybackContext:
                    target_rec = rec if rec is not None else self.disney_registry.get_binding(binding)
                    current_res_id = target_rec.resource_id if target_rec else record.resource_id
                    current_content_type = target_rec.content_type if target_rec else record.content_type
                    current_snap = self.disney_session.get_access_token_snapshot() or snapshot
                    try:
                        return self.disney_playback.resolve(
                            resource_id=current_res_id,
                            content_type=current_content_type,
                            access_token=current_snap.token,
                        )
                    except UpstreamHttpError as err:
                        # Reintento único sólo ante 401 inequívocamente de autenticación
                        if err.status == 401:
                            logger.warning(
                                "Playback Disney devolvió 401. Intentando refresco único para generación %d...",
                                current_snap.token_generation,
                            )
                            new_snap = self.disney_session.refresh_if_generation(
                                failed_generation=current_snap.token_generation
                            )
                            return self.disney_playback.resolve(
                                resource_id=current_res_id,
                                content_type=current_content_type,
                                access_token=new_snap.token,
                            )
                        raise

                updated_record, _ = self.disney_registry.resolve_single_flight(
                    binding, _resolve_upstream, timeout_seconds=4.0
                )
                if not updated_record.playback_context:
                    self.send_error(503, f"Fallo al resolver playback context para {binding}")
                    return

                target_url = updated_record.playback_context.manifest_url
                self.send_response(302)
                self.send_header("Location", target_url)
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "no-cache, no-store")
                self.end_headers()
            except UpstreamHttpError as err:
                if err.status == 401:
                    _notify_kodi_throttled("Disney+ (FlowProxy)", "Sesión no autorizada. Verifique el coordinador en PC.", is_error=True)
                    self.send_error(401, "Disney upstream: sesión no autorizada")
                elif err.status == 403:
                    _notify_kodi_throttled("Disney+ (FlowProxy)", "Contenido no habilitado o geobloqueado.", is_error=False)
                    self.send_error(403, "Disney upstream: contenido no habilitado o geobloqueado")
                elif err.status == 404:
                    self.send_error(404, "Disney upstream: evento o señal no disponible")
                elif err.status == 410:
                    self.send_error(410, "Disney upstream: evento finalizado")
                else:
                    self.send_error(503, f"Disney upstream error {err.status}")
            except CLIENT_DISCONNECT_ERRORS as error:
                self.close_connection = True
                logger.debug("Kodi canceló resolución de stream Disney en vuelo: %s", error)
            except Exception as e:
                logger.error("Error resolviendo stream Disney %s: %s", binding, e)
                self.send_error(503, f"Error resolviendo stream Disney: {e}")
        elif "/sensa/live/" in path:
            raw_id = path.split("/sensa/live/")[-1]
            channel_id = re.sub(r"\.(mpd|m3u8)$", "", raw_id, flags=re.IGNORECASE).strip()
            if not channel_id or not re.match(r"^[a-zA-Z0-9_\-]+$", channel_id):
                self.send_error(400, f"Identificador de canal Sensa inválido: {channel_id}")
                return
            try:
                target_url, stream_mode = self.sensa_playback.resolve(channel_id)
                if stream_mode == "direct_hls":
                    self.send_response(302)
                    self.send_header("Location", target_url)
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.send_header("Cache-Control", "no-cache, no-store")
                    self.end_headers()
                else:
                    self.send_error(
                        503,
                        "Canal protegido con Verimatrix AES-128 mTLS (DRM_KEY_MTLS_REQUIRED)",
                    )
            except SensaSessionError as e:
                self.send_error(401, f"Sesión Sensa no autorizada: {e}")
            except SensaChannelUnavailable as e:
                self.send_error(404, f"Canal Sensa no disponible: {e}")
            except CLIENT_DISCONNECT_ERRORS as error:
                self.close_connection = True
                logger.debug("Kodi canceló resolución de canal Sensa en vuelo: %s", error)
            except Exception as e:
                logger.error("Error resolviendo canal Sensa %s: %s", channel_id, e)
                self.send_error(503, f"Error resolviendo canal Sensa: {e}")
        elif path == "/sensa/status":
            status_data = self.sensa_session.get_status()
            body = json.dumps(status_data).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self._write_body(body)
        elif path == "/disney/status":
            auth = self.disney_session.is_authenticated()
            sess = self.disney_session.get_session() or {}
            exp = sess.get("expires", 0)
            status_data = {
                "provider": "disney",
                "authenticated": auth,
                "expires_at": exp,
                "profile_id": sess.get("profile_id"),
                "contract": sess.get("contract", "chrome_web"),
            }
            body = json.dumps(status_data).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self._write_body(body)
        elif path == "/dgo/status":
            try:
                status_data = self.dgo_resolver.session_status()
            except Exception as error:  # noqa: BLE001
                logger.error("Error obteniendo estado DGO: %s", error)
                status_data = {"provider": "dgo", "error": "status_unavailable"}
            body = json.dumps(status_data).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self._write_body(body)
        elif path in ("/epg.xml", "/epg.xml.gz", "/epg"):
            self._serve_epg(path, is_head=False)
        elif path.endswith(".m3u"):
            self._serve_m3u(path, is_head=False)
        elif path == "/status" or path == "/health":
            body = b'{"status": "ok", "service": "service.iptv.flowproxy"}'
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self._write_body(body)
        else:
            self.send_error(404, "Endpoint no reconocido")

    def log_message(self, format: str, *args) -> None:
        pass


class ThreadedHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = False
    block_on_close = True
    allow_reuse_address = True

    def __init__(self, *args, max_workers: int = MAX_LOCAL_WORKERS, **kwargs):
        if max_workers < 1:
            raise ValueError("max_workers debe ser >= 1")
        self._worker_slots = threading.BoundedSemaphore(max_workers)
        super().__init__(*args, **kwargs)

    def process_request(self, request, client_address) -> None:
        # No se crean hilos sin límite cuando Kodi abandona muchos canales.
        if not self._worker_slots.acquire(timeout=0.5):
            try:
                request.sendall(
                    b"HTTP/1.1 503 Service Unavailable\r\n"
                    b"Connection: close\r\nRetry-After: 1\r\nContent-Length: 0\r\n\r\n"
                )
            except OSError:
                pass
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self._worker_slots.release()
            raise

    def process_request_thread(self, request, client_address) -> None:
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._worker_slots.release()

    def get_request(self):
        request, client_address = super().get_request()
        # Impide que un cliente local con body truncado bloquee el cierre del addon.
        request.settimeout(15.0)
        return request, client_address


def _get_dgo_resolver() -> DgoSessionResolver:
    """Devuelve el singleton usado por el handler (también para warm-up en Kodi)."""
    return FlowProxyHandler.dgo_resolver


def _get_flow_auth() -> FlowAuthManager:
    """Devuelve el singleton de autenticación oficial Flow usado por el handler."""
    return FlowProxyHandler.flow_auth


def _get_disney_registry() -> PlaybackRegistry:
    """Devuelve el registro de bindings de Disney+."""
    return FlowProxyHandler.disney_registry


def _get_disney_session() -> DisneySessionManager:
    """Devuelve el gestor de sesión Disney+."""
    return FlowProxyHandler.disney_session


def close_resolvers() -> None:
    """Cierra transportes persistentes después de terminar los handlers."""
    FlowProxyHandler.dgo_resolver.close()
    FlowProxyHandler.flow_auth.close()
    FlowProxyHandler.disney_registry.clear()
    try:
        FlowProxyHandler.disney_transport.close()
    except Exception:
        pass
