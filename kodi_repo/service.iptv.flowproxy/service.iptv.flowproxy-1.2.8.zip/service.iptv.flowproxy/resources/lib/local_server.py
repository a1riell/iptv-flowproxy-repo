"""
Servidor HTTP Local Zero-CPU para redirecciones de Flow en Kodi.
"""

from __future__ import annotations

import http.server
import json
import logging
import os
import re
import socket
import socketserver
import ssl
import threading
import urllib.parse
import xml.etree.ElementTree as ET
from urllib.parse import urljoin
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, Union

from .flow_resolver import FlowSessionResolver
from .flow_auth import FlowAuthManager
from .dgo_resolver import (
    DRM_ID_TO_SLUG,
    ChannelTemporarilyUnavailable,
    DgoSessionResolver,
)

logger = logging.getLogger("flowproxy_server")

USER_AGENT = "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 Kodi/21"
MAX_WIDEVINE_CHALLENGE_BYTES = 1024 * 1024
MAX_LOCAL_WORKERS = 8
CLIENT_DISCONNECT_ERRORS = (
    BrokenPipeError,
    ConnectionResetError,
    ConnectionAbortedError,
    socket.timeout,
)

MAPPINGS_FILE = Path(__file__).resolve().parent / "slug_mappings.json"
SLUG_MAPPINGS: Dict[str, str] = {}

if MAPPINGS_FILE.is_file():
    try:
        SLUG_MAPPINGS = json.loads(MAPPINGS_FILE.read_text(encoding="utf-8"))
    except Exception as e:
        logger.warning(f"No se pudo cargar slug_mappings.json: {e}")



def extract_seed_rel(entry: Any) -> Tuple[Optional[str], Optional[str]]:
    """Extrae y valida la ruta relativa del seed desde una entrada de mapping.

    Retorna (seed_rel, error_reason). Si es válida, error_reason es None.
    """
    if entry is None:
        return None, "slug_not_found"

    if isinstance(entry, dict):
        seed = entry.get("seed_rel")
    elif isinstance(entry, str):
        seed = entry
    else:
        return None, "invalid_type"

    if not isinstance(seed, str) or not seed.strip():
        return None, "empty_seed_rel"

    seed = seed.strip()
    if ".." in seed:
        return None, "path_traversal"
    if seed.startswith("/"):
        return None, "absolute_path"
    if "://" in seed:
        return None, "external_host"

    return seed, None


def strip_content_protection(mpd_bytes: bytes, remote_url: str) -> bytes:
    """Quita el <ContentProtection> y hace absolutas las URLs del MPD.

    Varios CDN (PlayMe) DECLARAN Widevine + FairPlay + cenc en el manifiesto pero sirven
    el video EN CLARO. Si ese manifiesto llega tal cual a InputStream Adaptive, el addon
    de Kodi intenta inicializar DRM, no encuentra licencia ni clave, y el canal FALLA
    aunque el stream funcione. Se elimina la declaración de cifrado y se reescribe el
    BaseURL para que los segmentos se pidan al CDN real y no a 127.0.0.1.
    """
    try:
        root = ET.fromstring(mpd_bytes)
    except ET.ParseError:
        return mpd_bytes
    for parent in root.iter():
        for child in list(parent):
            if child.tag.rsplit("}", 1)[-1] == "ContentProtection":
                parent.remove(child)
    namespace_uri = "urn:mpeg:dash:schema:mpd:2011"
    namespace = f"{{{namespace_uri}}}"
    has_base_url = False
    for elem in root.iter():
        if elem.tag.rsplit("}", 1)[-1] != "BaseURL":
            continue
        has_base_url = True
        if elem.text and elem.text.strip():
            elem.text = urljoin(remote_url, elem.text.strip())
    if not has_base_url:
        base = ET.Element(f"{namespace}BaseURL")
        base.text = urljoin(remote_url, ".")
        root.insert(0, base)
    # ElementTree usa el prefijo artificial ``ns0`` si no se registra el
    # namespace por defecto. Aunque XML válido, InputStream Adaptive/Kodi puede
    # rechazar ese MPD DASH. Mantener el namespace DASH por defecto conserva el
    # formato que entrega el CDN.
    ET.register_namespace("", namespace_uri)
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def fetch_clear_manifest(url: str) -> Tuple[bytes, str]:
    """Descarga el manifiesto siguiendo redirecciones y devuelve (cuerpo, url_final)."""
    ctx = ssl.create_default_context()
    # Mismo criterio que el resolver: Kodi en Android no siempre tiene el almacén de CAs.
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=15, context=ctx) as response:
        return response.read(), response.geturl()


class FlowProxyHandler(http.server.BaseHTTPRequestHandler):
    resolver = FlowSessionResolver()
    dgo_resolver = DgoSessionResolver()
    flow_auth = FlowAuthManager()
    _notification_lock = threading.Lock()
    _last_notification: Dict[str, float] = {}

    @classmethod
    def _notify_once(cls, key: str, message: str, interval: float = 60.0) -> None:
        import time

        now = time.monotonic()
        with cls._notification_lock:
            if now - cls._last_notification.get(key, 0.0) < interval:
                return
            cls._last_notification[key] = now
        try:
            import xbmc
            safe_message = message.replace(",", " ").replace(")", " ")[:120]
            xbmc.executebuiltin(
                f"Notification(DGO,Canal temporalmente no disponible: {safe_message},5000)"
            )
        except Exception:
            pass

    def handle_one_request(self) -> None:
        """Trata el abandono de Kodi como cancelación normal, sin traceback."""
        try:
            super().handle_one_request()
        except CLIENT_DISCONNECT_ERRORS as error:
            self.close_connection = True
            logger.debug("Cliente local canceló la petición: %s", error)

    def send_error(self, code: int, message=None, explain=None) -> None:
        try:
            super().send_error(code, message, explain)
        except CLIENT_DISCONNECT_ERRORS as error:
            self.close_connection = True
            logger.debug("Cliente local se desconectó antes del error HTTP: %s", error)

    def _write_body(self, body: bytes) -> bool:
        try:
            self.wfile.write(body)
            return True
        except CLIENT_DISCONNECT_ERRORS as error:
            self.close_connection = True
            logger.debug("Cliente local canceló la respuesta: %s", error)
            return False

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "authorization, content-type, range")
        self.end_headers()

    def do_POST(self) -> None:
        path = urllib.parse.unquote(self.path)
        if urllib.parse.urlsplit(path).path.startswith("/dgo/license/"):
            raw_id = path.split("/dgo/license/")[-1].split("?")[0].strip()
            if not raw_id:
                self.send_error(400, "Falta contentId en la ruta de licencia")
                return
            if raw_id.lower() not in DRM_ID_TO_SLUG:
                self.send_error(404, "contentId DGO desconocido")
                return

            try:
                length = int(self.headers.get("Content-Length", 0))
            except (ValueError, TypeError):
                length = 0

            if length <= 0:
                self.send_error(400, "Challenge Widevine vacío")
                return
            if length > MAX_WIDEVINE_CHALLENGE_BYTES:
                self.send_error(413, "Challenge Widevine demasiado grande")
                return

            challenge_data = self.rfile.read(length)
            if len(challenge_data) != length:
                self.send_error(400, "Challenge Widevine truncado")
                return
            try:
                status, license_bytes, _ = self.dgo_resolver.proxy_license(raw_id, challenge_data)
                self.send_response(status)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "no-cache, no-store")
                self.send_header("Content-Length", str(len(license_bytes)))
                self.end_headers()
                self._write_body(license_bytes)
            except CLIENT_DISCONNECT_ERRORS as error:
                self.close_connection = True
                logger.debug("Kodi canceló una licencia DGO en vuelo: %s", error)
            except Exception as e:
                logger.error("Error en proxy de licencia DGO %s: %s", raw_id, e)
                self.send_error(503, "Error temporal del proxy de licencia DGO")
        elif urllib.parse.urlsplit(path).path.startswith("/flow/license/"):
            raw_id = path.split("/flow/license/")[-1].split("?")[0].strip()
            if not raw_id:
                self.send_error(400, "Falta identificador de canal en la ruta de licencia Flow")
                return

            try:
                length = int(self.headers.get("Content-Length", 0))
            except (ValueError, TypeError):
                length = 0

            if length <= 0:
                self.send_error(400, "Challenge Widevine vacío")
                return
            if length > MAX_WIDEVINE_CHALLENGE_BYTES:
                self.send_error(413, "Challenge Widevine demasiado grande")
                return

            challenge_data = self.rfile.read(length)
            if len(challenge_data) != length:
                self.send_error(400, "Challenge Widevine truncado")
                return

            try:
                status, license_bytes, _ = self.flow_auth.proxy_license(raw_id, challenge_data)
                self.send_response(status)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "no-cache, no-store")
                self.send_header("Content-Length", str(len(license_bytes)))
                self.end_headers()
                self._write_body(license_bytes)
            except CLIENT_DISCONNECT_ERRORS as error:
                self.close_connection = True
                logger.debug("Kodi canceló una licencia Flow en vuelo: %s", error)
            except Exception as e:
                logger.error("Error en proxy de licencia Flow %s: %s", raw_id, e)
                self.send_error(503, "Error temporal del proxy de licencia Flow")
        else:
            self.send_error(404, "Endpoint POST no reconocido")

    def do_GET(self) -> None:
        path = urllib.parse.unquote(urllib.parse.urlsplit(self.path).path)
        if "/dgo/live/" in path:
            raw_slug = path.split("/dgo/live/")[-1]
            requested_hls = raw_slug.lower().endswith(".m3u8")
            slug = re.sub(r"\.(mpd|m3u8)$", "", raw_slug, flags=re.IGNORECASE).strip().lower()
            try:
                if requested_hls:
                    # Las señales FAST son HLS claro. El 302 mantiene al proxy fuera
                    # del transporte de segmentos y permite que Kodi resuelva todas
                    # las playlists relativas contra la URL final de Amagi.
                    target_url = self.dgo_resolver.get_hls_url(slug)
                    self.send_response(302)
                    self.send_header("Location", target_url)
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.send_header("Cache-Control", "no-cache, no-store")
                    self.end_headers()
                else:
                    manifest_bytes = self.dgo_resolver.get_manifest(slug)
                    self.send_response(200)
                    self.send_header("Content-Type", "application/dash+xml")
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.send_header("Cache-Control", "no-cache, no-store")
                    self.send_header("Content-Length", str(len(manifest_bytes)))
                    self.end_headers()
                    self._write_body(manifest_bytes)
            except ChannelTemporarilyUnavailable as error:
                self._notify_once(slug, str(error))
                self.send_response(503, "Canal temporalmente no disponible")
                self.send_header("Retry-After", "60")
                self.send_header("Content-Length", "0")
                self.end_headers()
            except ValueError as e:
                self.send_error(404, f"Canal DGO no encontrado: {slug}")
            except CLIENT_DISCONNECT_ERRORS as error:
                self.close_connection = True
                logger.debug("Kodi canceló un manifiesto DGO en vuelo: %s", error)
            except Exception as e:
                logger.error("Error resolviendo canal DGO %s: %s", slug, e)
                self.send_error(503, f"Error resolviendo canal DGO {slug}: {e}")
        elif "/kodi/clear/" in path:
            # Manifiesto saneado: se sirve SIN la declaración de DRM falsa.
            raw_slug = path.split("/kodi/clear/")[-1]
            slug = re.sub(r"\.(mpd|m3u8)$", "", raw_slug, flags=re.IGNORECASE).strip().lower()
            entry = SLUG_MAPPINGS.get(f"clear:{slug}")
            if not isinstance(entry, dict) or not entry.get("clear_url"):
                self.send_error(404, f"Manifiesto claro no encontrado: {slug}")
                return
            try:
                body, final_url = fetch_clear_manifest(str(entry["clear_url"]))
                saneado = strip_content_protection(body, final_url)
            except Exception as e:  # noqa: BLE001
                self.send_error(503, f"Error obteniendo manifiesto {slug}: {e}")
                return
            self.send_response(200)
            self.send_header("Content-Type", "application/dash+xml")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Cache-Control", "no-cache, no-store")
            self.send_header("Content-Length", str(len(saneado)))
            self.end_headers()
            self._write_body(saneado)
        elif "/flow/live/" in path or "/kodi/live/" in path:
            prefix = "/flow/live/" if "/flow/live/" in path else "/kodi/live/"
            raw_slug = path.split(prefix)[-1]
            slug = re.sub(r"\.(mpd|m3u8)$", "", raw_slug, flags=re.IGNORECASE).strip().lower()

            entry = SLUG_MAPPINGS.get(slug)
            target_rel, err = extract_seed_rel(entry)

            if err == "slug_not_found":
                self.send_error(404, f"Canal no encontrado: {slug}")
                return
            elif err:
                self.send_error(400, f"Ruta de seed inválida para canal {slug}: {err}")
                return

            try:
                target_url = self.resolver.resolve_stream(slug, target_rel)

                self.send_response(302)
                self.send_header("Location", target_url)
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "no-cache, no-store")
                self.end_headers()
            except Exception as e:
                self.send_error(503, f"Error resolviendo canal {slug}: {e}")
        elif path == "/status" or path == "/health":
            body = b'{"status": "ok", "service": "service.iptv.flowproxy"}'
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self._write_body(body)
        else:
            self.send_error(404, "Endpoint no reconocido")

    def log_message(self, format: str, *args) -> None:
        pass


class ThreadedHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = False
    block_on_close = True
    allow_reuse_address = True

    def __init__(self, *args, max_workers: int = MAX_LOCAL_WORKERS, **kwargs):
        if max_workers < 1:
            raise ValueError("max_workers debe ser >= 1")
        self._worker_slots = threading.BoundedSemaphore(max_workers)
        super().__init__(*args, **kwargs)

    def process_request(self, request, client_address) -> None:
        # No se crean hilos sin límite cuando Kodi abandona muchos canales.
        if not self._worker_slots.acquire(timeout=0.05):
            try:
                request.sendall(
                    b"HTTP/1.1 503 Service Unavailable\r\n"
                    b"Connection: close\r\nRetry-After: 1\r\nContent-Length: 0\r\n\r\n"
                )
            except OSError:
                pass
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self._worker_slots.release()
            raise

    def process_request_thread(self, request, client_address) -> None:
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._worker_slots.release()

    def get_request(self):
        request, client_address = super().get_request()
        # Impide que un cliente local con body truncado bloquee el cierre del addon.
        request.settimeout(15.0)
        return request, client_address


def _get_dgo_resolver() -> DgoSessionResolver:
    """Devuelve el singleton usado por el handler (también para warm-up en Kodi)."""
    return FlowProxyHandler.dgo_resolver


def _get_flow_auth() -> FlowAuthManager:
    """Devuelve el singleton de autenticación oficial Flow usado por el handler."""
    return FlowProxyHandler.flow_auth


def close_resolvers() -> None:
    """Cierra transportes persistentes después de terminar los handlers."""
    FlowProxyHandler.dgo_resolver.close()
    FlowProxyHandler.flow_auth.close()
