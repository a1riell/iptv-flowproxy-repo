"""
Entrypoint de servicio para Kodi: service.iptv.flowproxy
"""

import sys
import threading

try:
    import xbmc
    import xbmcaddon
    IN_KODI = True
except ImportError:
    IN_KODI = False

from resources.lib.local_server import FlowProxyHandler, ThreadedHTTPServer, close_resolvers

DEFAULT_PORT = 18080


def get_configured_port() -> int:
    if IN_KODI:
        try:
            addon = xbmcaddon.Addon()
            val = addon.getSetting("proxy_port")
            if val:
                return int(val)
        except Exception:
            pass
    return DEFAULT_PORT


_current_httpd = None


def shutdown_server() -> None:
    global _current_httpd
    if _current_httpd:
        try:
            _current_httpd.shutdown()
            _current_httpd.server_close()
        finally:
            _current_httpd = None
    close_resolvers()


def run_server(port: int) -> None:
    global _current_httpd
    server_address = ("127.0.0.1", port)
    _current_httpd = ThreadedHTTPServer(server_address, FlowProxyHandler)
    msg = f"[IPTV FlowProxy] Servidor iniciado en http://127.0.0.1:{port}"
    if IN_KODI:
        xbmc.log(msg, level=xbmc.LOGINFO)
    else:
        print(msg)
    _current_httpd.serve_forever()


if __name__ == "__main__":
    port = get_configured_port()
    server_thread = threading.Thread(target=run_server, args=(port,), daemon=True)
    server_thread.start()

    # Pre-cargar o auto-descargar credenciales DGO en segundo plano
    def _warmup_dgo():
        try:
            from resources.lib.local_server import _get_dgo_resolver
            resolver = _get_dgo_resolver()
            resolver.warmup()
        except Exception:
            pass

    threading.Thread(target=_warmup_dgo, daemon=True).start()

    if IN_KODI:
        monitor = xbmc.Monitor()
        maintenance_ticks = 0
        while not monitor.abortRequested():
            if monitor.waitForAbort(2):
                break
            maintenance_ticks += 1
            if maintenance_ticks >= 15:
                maintenance_ticks = 0
                try:
                    from resources.lib.local_server import _get_dgo_resolver
                    _get_dgo_resolver().maintenance()
                except Exception as exc:
                    xbmc.log(
                        f"[IPTV FlowProxy] Mantenimiento DGO omitido: {exc}",
                        level=xbmc.LOGWARNING,
                    )
        try:
            shutdown_server()
        except Exception as exc:
            xbmc.log(f"[IPTV FlowProxy] Error durante cierre: {exc}", level=xbmc.LOGERROR)
        xbmc.log("[IPTV FlowProxy] Servicio detenido limpiamente", level=xbmc.LOGINFO)
    else:
        print("[IPTV FlowProxy] Ejecutando en modo standalone (presione Ctrl+C para salir)...")
        try:
            import time
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            shutdown_server()
            print("[IPTV FlowProxy] Detenido.")
            sys.exit(0)
