"""
FlowSessionResolver: Obtención y caché local de tokens y URLs directas para nodos CDN de Flow.

Endurecimiento seguro para Android/Android TV (2026-09-26):
  * Acepta 301, 302, 307 y 308 (antes solo 302: si el CDN cambiaba de código, fallaba).
  * Extrae el claim ``exp`` del JWT, rechaza tokens ya vencidos y calcula el TTL efectivo
    con margen de seguridad, controlando el vencimiento local con ``time.monotonic()``
    (inmune a saltos del reloj de pared / NTP).
  * ELIMINADA la fuga de privacidad: ya NO se registra el header ``Location``, que contiene
    el token de sesión, y el token lleva el claim ``sip`` = IP pública del cliente.
  * TLS: se mantiene SIN verificación de forma CONSCIENTE y documentada.
"""

from __future__ import annotations

import base64
import json
import logging
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Dict, Optional, Tuple

logger = logging.getLogger("flowproxy_resolver")

USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36"

# Códigos de redirección que el CDN puede devolver legítimamente.
REDIRECT_CODES = (301, 302, 307, 308)

_TOKEN_RX = re.compile(r"(tok_[A-Za-z0-9_\-\.]+)")


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _safe_host(url: str) -> str:
    """Devuelve solo el host de una URL: nunca la ruta ni la query (pueden llevar el token)."""
    try:
        return urllib.parse.urlsplit(url).netloc or "<host-desconocido>"
    except Exception:  # noqa: BLE001
        return "<host-desconocido>"


class FlowSessionResolver:
    """Resuelve en caliente la URL con token de sesión de Flow desde la IP pública del dispositivo."""

    #: Margen de gracia antes del vencimiento real del token.
    SAFETY_MARGIN_SECONDS = 180.0
    #: Vida máxima aceptable de un token; por encima se considera fuera de política.
    MAX_TOKEN_LIFETIME_SECONDS = 7 * 24 * 3600
    #: TTL conservador cuando el token no expone ``exp``.
    FALLBACK_TTL_SECONDS = 900.0

    def __init__(self, cache_ttl_seconds: float = 3600.0):
        self.cache_ttl = float(cache_ttl_seconds)
        # slug -> (target_url, deadline_monotonic)
        self._channel_cache: Dict[str, Tuple[str, float]] = {}

        self.ssl_ctx = ssl.create_default_context()
        # DECISIÓN CONSCIENTE (compatibilidad Android / TV Box):
        # Kodi en Android no siempre dispone del almacén de CAs del sistema. Con verificación
        # estricta el addon dejaría de resolver en esos dispositivos. Se mantiene sin verificar
        # hasta poder empaquetar un bundle de CAs dentro del add-on y validarlo en un
        # dispositivo real. NO cambiar a CERT_REQUIRED sin ese bundle.
        self.ssl_ctx.check_hostname = False
        self.ssl_ctx.verify_mode = ssl.CERT_NONE
        self.opener = urllib.request.build_opener(
            urllib.request.HTTPSHandler(context=self.ssl_ctx),
            NoRedirect,
        )

    # ── Análisis del token ────────────────────────────────────────────────────
    @staticmethod
    def extract_exp(location: str) -> Optional[int]:
        """Extrae el claim ``exp`` del JWT del Location SIN validar la firma.

        Devuelve ``None`` si no hay token o no es interpretable.
        """
        m = _TOKEN_RX.search(location or "")
        if not m:
            return None
        raw = m.group(1)[4:]  # quita el prefijo 'tok_'
        parts = raw.split(".")
        if len(parts) < 2:
            return None
        try:
            payload_b64 = parts[1] + "=" * (-len(parts[1]) % 4)
            payload = json.loads(base64.urlsafe_b64decode(payload_b64))
        except Exception:  # noqa: BLE001
            return None
        try:
            return int(str(payload.get("exp", 0)))
        except (TypeError, ValueError):
            return None

    def effective_ttl(self, location: str, wall_now: Optional[float] = None) -> Optional[float]:
        """TTL efectivo en segundos para cachear una resolución.

        Devuelve ``None`` cuando el token ya está vencido (o vence dentro del margen) y por
        tanto NO debe cachearse: se fuerza una renovación inmediata.
        """
        now = time.time() if wall_now is None else float(wall_now)
        exp = self.extract_exp(location)
        if exp is None:
            # Sin metadatos de expiración: TTL conservador, nunca el largo por defecto.
            return min(self.cache_ttl, self.FALLBACK_TTL_SECONDS)
        if exp <= now:
            logger.warning("Token descartado: ya vencido (exp en el pasado).")
            return None
        if exp > now + self.MAX_TOKEN_LIFETIME_SECONDS:
            logger.warning("Token marcado EXP_OUT_OF_POLICY: vida superior al máximo aceptado.")
            return min(self.cache_ttl, self.FALLBACK_TTL_SECONDS)
        remaining = exp - now - self.SAFETY_MARGIN_SECONDS
        if remaining <= 0:
            logger.warning("Token descartado: vence dentro del margen de seguridad.")
            return None
        return float(min(self.cache_ttl, remaining))

    # ── Resolución ────────────────────────────────────────────────────────────
    @staticmethod
    def _restore_playback_profile(location: str, seed_rel: str, playback_rel: str) -> str:
        """Conserva el perfil de reproducción original tras negociar el token.

        El CDN exige consultar ``*_cenc`` para emitir el JWT, pero perfiles
        como ``*_enc_C`` y ``*_enc_wl`` sólo reproducen correctamente si el
        cliente vuelve a pedir el MPD original.  La sustitución se limita al
        sufijo de ruta, preserva token/query sin registrarlos y no altera los
        mappings que ya usan CENC como perfil de reproducción.
        """
        source = seed_rel.strip("/")
        target = playback_rel.strip("/")
        if not source or source == target:
            return location
        try:
            parsed = urllib.parse.urlsplit(location)
            suffix = "/" + source
            if not parsed.path.endswith(suffix):
                return location
            restored_path = parsed.path[:-len(source)] + target
            return urllib.parse.urlunsplit(parsed._replace(path=restored_path))
        except Exception:  # noqa: BLE001
            # Un Location inusual no debe impedir una redirección que antes era
            # válida; se conserva tal cual y sin escribirlo en logs.
            return location

    def resolve_stream(self, slug: str, rel_path: str) -> str:
        mono_now = time.monotonic()
        cached = self._channel_cache.get(slug)
        if cached is not None:
            url, deadline = cached
            if mono_now < deadline:
                return url
            self._channel_cache.pop(slug, None)

        # Telecom Flow requiere consultar con el perfil SA_Live_dash_cenc
        playback_rel = rel_path.lstrip("/")
        # ``enc_C`` y demás sufijos experimentales de listas históricas no
        # son perfiles reproducibles del edge final. El actualizador ya los
        # normaliza a ``enc`` tras obtener el JWT; el proxy debe aplicar la
        # misma regla para que ambos caminos reproduzcan el mismo MPD.
        playback_rel = re.sub(
            r"SA_Live_dash_enc_(?!wl(?:/|$))[^/]+",
            "SA_Live_dash_enc",
            playback_rel,
        )
        seed_rel = re.sub(
            r"SA_Live_dash_enc(?:_[^/]+)?",
            "SA_Live_dash_cenc",
            playback_rel,
        )
        seed_url = f"https://cdn.cvattv.com.ar/{seed_rel}"

        req = urllib.request.Request(seed_url, headers={"User-Agent": USER_AGENT})
        try:
            self.opener.open(req, timeout=4.0)
        except urllib.error.HTTPError as err:
            if err.code in REDIRECT_CODES:
                loc = err.headers.get("Location")
                if loc:
                    ttl = self.effective_ttl(loc)
                    if ttl is None:
                        raise RuntimeError(
                            f"Token no utilizable para el canal {slug} (vencido o fuera de política)"
                        )
                    playback_url = self._restore_playback_profile(loc, seed_rel, playback_rel)
                    self._channel_cache[slug] = (playback_url, time.monotonic() + ttl)
                    return playback_url
            # NO se registra el Location: contiene el token, y el token lleva el claim
            # 'sip' con la IP pública del cliente. Solo código y host.
            logger.warning("Seed %s devolvió HTTP %s", _safe_host(seed_url), err.code)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Error consultando seed en %s: %s", _safe_host(seed_url), type(exc).__name__)

        raise RuntimeError(
            f"No se pudo resolver una redirección {REDIRECT_CODES} para el canal {slug}"
        )
