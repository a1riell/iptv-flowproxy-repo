"""
Servidor HTTP Local Zero-CPU para redirecciones de Flow en Kodi.
"""

from __future__ import annotations

import http.server
import json
import logging
import os
import re
import socket
import socketserver
import ssl
import tempfile
import threading
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from urllib.parse import urljoin
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, Union

from .flow_resolver import FlowSessionResolver
from .flow_auth import FlowAuthManager
from .dgo_resolver import (
    DRM_ID_TO_SLUG,
    ChannelTemporarilyUnavailable,
    DgoSessionResolver,
)
from .providers.disney import (
    ChromeWebContract,
    DefaultHttpTransport,
    DisneyLicenseProxy,
    DisneyPlaybackEngine,
    DisneySessionManager,
    PlaybackRegistry,
)
from .providers.disney.http_transport import UpstreamHttpError
from .providers.disney.models import PlaybackContext
from .providers.sensa import (
    SensaChannelUnavailable,
    SensaPlaybackEngine,
    SensaPlaybackError,
    SensaSessionError,
    SensaSessionManager,
)

logger = logging.getLogger("flowproxy_server")

USER_AGENT = "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 Kodi/21"
MAX_WIDEVINE_CHALLENGE_BYTES = 1024 * 1024
MAX_LOCAL_WORKERS = 8
CLIENT_DISCONNECT_ERRORS = (
    BrokenPipeError,
    ConnectionResetError,
    ConnectionAbortedError,
    socket.timeout,
)

MAPPINGS_FILE = Path(__file__).resolve().parent / "slug_mappings.json"
SLUG_MAPPINGS: Dict[str, str] = {}
DISNEY_BINDINGS_URL = (
    "https://gist.githubusercontent.com/a1riell/"
    "9c1db121510fc81709f28c132afb9c81/raw/disney_bindings.json"
)
_bindings_download_lock = threading.Lock()
_last_bindings_download_attempt = 0.0

if MAPPINGS_FILE.is_file():
    try:
        SLUG_MAPPINGS = json.loads(MAPPINGS_FILE.read_text(encoding="utf-8"))
    except Exception as e:
        logger.warning(f"No se pudo cargar slug_mappings.json: {e}")


def _find_disney_bindings_file() -> Optional[Path]:
    """Busca el archivo de bindings persistidos de Disney+."""
    try:
        import xbmcaddon
        import xbmcvfs
        addon = xbmcaddon.Addon("service.iptv.flowproxy")
        profile_dir = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        p = Path(profile_dir) / "disney_bindings.json"
        if p.is_file():
            return p
    except Exception:
        pass

    candidates = [
        Path.home() / ".kodi" / "userdata" / "addon_data" / "service.iptv.flowproxy" / "disney_bindings.json",
        Path.home() / ".flow_cache" / "disney_bindings.json",
        Path(__file__).resolve().parent / "disney_bindings.json",
    ]
    for c in candidates:
        if c.is_file():
            return c
    return None


def _find_epg_files() -> Tuple[Optional[Path], Optional[Path]]:
    """Busca archivos epg.xml y epg.xml.gz en ubicaciones estándar."""
    candidates = []
    try:
        import xbmcaddon
        import xbmcvfs
        addon = xbmcaddon.Addon("service.iptv.flowproxy")
        profile = Path(xbmcvfs.translatePath(addon.getAddonInfo("profile")))
        candidates.append(profile)
    except Exception:
        pass

    candidates.extend([
        Path.home() / ".kodi" / "userdata" / "addon_data" / "service.iptv.flowproxy",
        Path.home() / "listas_gist",
        Path("/home/fer/listas_gist"),
        Path.home() / ".flow_cache",
        Path.home() / ".flow_cache" / "epg",
        Path("/home/fer"),
        Path("/storage/emulated/0/Download"),
    ])

    xml_found = None
    gz_found = None
    for folder in candidates:
        if not xml_found:
            candidate_xml = folder / "epg.xml"
            if candidate_xml.is_file():
                xml_found = candidate_xml
        if not gz_found:
            candidate_gz = folder / "epg.xml.gz"
            if candidate_gz.is_file():
                gz_found = candidate_gz
        if xml_found and gz_found:
            break
    return xml_found, gz_found


def _disney_bindings_target() -> Path:
    """Devuelve una ruta escribible y privada dentro del perfil del add-on."""
    try:
        import xbmcaddon
        import xbmcvfs
        addon = xbmcaddon.Addon("service.iptv.flowproxy")
        profile = Path(xbmcvfs.translatePath(addon.getAddonInfo("profile")))
    except Exception:
        profile = (
            Path.home()
            / ".kodi"
            / "userdata"
            / "addon_data"
            / "service.iptv.flowproxy"
        )
    profile.mkdir(parents=True, exist_ok=True)
    return profile / "disney_bindings.json"


REMOTE_EPG_FALLBACK_URL = (
    "https://gist.githubusercontent.com/a1riell/9c1db121510fc81709f28c132afb9c81/raw/epg.xml"
)
_epg_download_lock = threading.Lock()
_last_epg_download_attempt: float = 0.0


def _download_epg_fallback(force: bool = False) -> Optional[Path]:
    """Descarga de respaldo la guía EPG publicada en el Gist si no existe en disco local."""
    global _last_epg_download_attempt
    with _epg_download_lock:
        now = time.monotonic()
        if not force and (now - _last_epg_download_attempt < 120):
            return None
        _last_epg_download_attempt = now
        try:
            profile = _disney_bindings_target().parent
            profile.mkdir(parents=True, exist_ok=True)
            target = profile / "epg.xml"
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            req = urllib.request.Request(
                REMOTE_EPG_FALLBACK_URL,
                headers={"User-Agent": USER_AGENT},
            )
            with urllib.request.urlopen(req, timeout=20, context=ctx) as resp:
                if resp.status == 200:
                    data = resp.read()
                    if len(data) > 1000:
                        fd, tmp = tempfile.mkstemp(
                            prefix="epg_fallback_", suffix=".tmp", dir=str(profile)
                        )
                        try:
                            with os.fdopen(fd, "wb") as h:
                                fd = -1
                                h.write(data)
                                h.flush()
                                os.fsync(h.fileno())
                            os.replace(tmp, target)
                            logger.info("Guía EPG de respaldo descargada exitosamente en %s", target)
                            return target
                        finally:
                            if fd >= 0:
                                os.close(fd)
                            try:
                                os.unlink(tmp)
                            except FileNotFoundError:
                                pass
        except Exception as exc:
            logger.warning("No se pudo descargar guía EPG desde respaldo remoto: %s", exc)
    return None


def sync_disney_bindings_from_remote(force: bool = False) -> Optional[Path]:
    """Descarga y valida el mapa de eventos Disney publicado por el radar."""
    global _last_bindings_download_attempt
    with _bindings_download_lock:
        now = time.monotonic()
        if not force and now - _last_bindings_download_attempt < 5 * 60:
            return _find_disney_bindings_file()
        _last_bindings_download_attempt = now
        try:
            separator = "&" if "?" in DISNEY_BINDINGS_URL else "?"
            bindings_url = (
                DISNEY_BINDINGS_URL
                + separator
                + urllib.parse.urlencode({"generation_check": int(time.time() // 60)})
            )
            request = urllib.request.Request(
                bindings_url,
                headers={
                    "User-Agent": USER_AGENT,
                    "Cache-Control": "no-cache",
                    "Pragma": "no-cache",
                },
            )
            with urllib.request.urlopen(
                request, timeout=12.0, context=ssl.create_default_context()
            ) as response:
                raw = response.read(2 * 1024 * 1024 + 1)
            if len(raw) > 2 * 1024 * 1024:
                raise ValueError("mapa Disney remoto demasiado grande")
            payload = json.loads(raw.decode("utf-8"))
            if not isinstance(payload, dict) or not payload or len(payload) > 2000:
                raise ValueError("mapa Disney remoto vacío o inválido")
            for binding, item in payload.items():
                if not re.fullmatch(r"disney-(?:linear|live)-[A-Za-z0-9_-]+", binding):
                    raise ValueError(f"binding Disney inválido: {binding}")
                if not isinstance(item, dict) or not isinstance(item.get("resource_id"), str) or not item["resource_id"]:
                    raise ValueError(f"resource_id ausente para {binding}")

            target = _disney_bindings_target()
            fd, temporary = tempfile.mkstemp(
                prefix="disney_bindings_", suffix=".tmp", dir=str(target.parent)
            )
            try:
                os.fchmod(fd, 0o600)
                with os.fdopen(fd, "wb") as handle:
                    fd = -1
                    handle.write(raw)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(temporary, target)
            finally:
                if fd >= 0:
                    os.close(fd)
                try:
                    os.unlink(temporary)
                except FileNotFoundError:
                    pass
            return target
        except Exception as error:
            logger.warning("No se pudo actualizar el mapa remoto Disney: %s", error)
            return _find_disney_bindings_file()



def extract_seed_rel(entry: Any) -> Tuple[Optional[str], Optional[str]]:
    """Extrae y valida la ruta relativa del seed desde una entrada de mapping.

    Retorna (seed_rel, error_reason). Si es válida, error_reason es None.
    """
    if entry is None:
        return None, "slug_not_found"

    if isinstance(entry, dict):
        seed = entry.get("seed_rel")
    elif isinstance(entry, str):
        seed = entry
    else:
        return None, "invalid_type"

    if not isinstance(seed, str) or not seed.strip():
        return None, "empty_seed_rel"

    seed = seed.strip()
    if ".." in seed:
        return None, "path_traversal"
    if seed.startswith("/"):
        return None, "absolute_path"
    if "://" in seed:
        return None, "external_host"

    return seed, None


def strip_content_protection(mpd_bytes: bytes, remote_url: str) -> bytes:
    """Quita el <ContentProtection> y hace absolutas las URLs del MPD.

    Varios CDN (PlayMe) DECLARAN Widevine + FairPlay + cenc en el manifiesto pero sirven
    el video EN CLARO. Si ese manifiesto llega tal cual a InputStream Adaptive, el addon
    de Kodi intenta inicializar DRM, no encuentra licencia ni clave, y el canal FALLA
    aunque el stream funcione. Se elimina la declaración de cifrado y se reescribe el
    BaseURL para que los segmentos se pidan al CDN real y no a 127.0.0.1.
    """
    try:
        root = ET.fromstring(mpd_bytes)
    except ET.ParseError:
        return mpd_bytes
    for parent in root.iter():
        for child in list(parent):
            if child.tag.rsplit("}", 1)[-1] == "ContentProtection":
                parent.remove(child)
    namespace_uri = "urn:mpeg:dash:schema:mpd:2011"
    namespace = f"{{{namespace_uri}}}"
    has_base_url = False
    for elem in root.iter():
        if elem.tag.rsplit("}", 1)[-1] != "BaseURL":
            continue
        has_base_url = True
        if elem.text and elem.text.strip():
            elem.text = urljoin(remote_url, elem.text.strip())
    if not has_base_url:
        base = ET.Element(f"{namespace}BaseURL")
        base.text = urljoin(remote_url, ".")
        root.insert(0, base)
    # ElementTree usa el prefijo artificial ``ns0`` si no se registra el
    # namespace por defecto. Aunque XML válido, InputStream Adaptive/Kodi puede
    # rechazar ese MPD DASH. Mantener el namespace DASH por defecto conserva el
    # formato que entrega el CDN.
    ET.register_namespace("", namespace_uri)
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def fetch_clear_manifest(url: str) -> Tuple[bytes, str]:
    """Descarga el manifiesto siguiendo redirecciones y devuelve (cuerpo, url_final)."""
    ctx = ssl.create_default_context()
    # Mismo criterio que el resolver: Kodi en Android no siempre tiene el almacén de CAs.
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=15, context=ctx) as response:
        return response.read(), response.geturl()


class FlowProxyHandler(http.server.BaseHTTPRequestHandler):
    resolver = FlowSessionResolver()
    dgo_resolver = DgoSessionResolver()
    flow_auth = FlowAuthManager()

    # Proveedor Disney+ (BAMGrid)
    disney_registry = PlaybackRegistry()
    disney_transport = DefaultHttpTransport()
    disney_contract = ChromeWebContract()
    disney_playback = DisneyPlaybackEngine(transport=disney_transport, contract=disney_contract)
    disney_license = DisneyLicenseProxy(
        registry=disney_registry, transport=disney_transport, contract=disney_contract
    )
    disney_session = DisneySessionManager()
    _last_bindings_mtime: float = 0.0

    # Proveedor Sensa (Pontis PRM)
    sensa_session = SensaSessionManager()
    sensa_playback = SensaPlaybackEngine(session_manager=sensa_session)

    @classmethod
    def _sync_bindings_if_modified(cls) -> None:
        """Sincroniza bindings desde disco si el archivo fue actualizado por el radar."""
        bfile = _find_disney_bindings_file()
        if not bfile:
            return
        try:
            mtime = bfile.stat().st_mtime
            if mtime > cls._last_bindings_mtime:
                cls.disney_registry.load_from_file(bfile)
                cls._last_bindings_mtime = mtime
        except Exception as e:
            logger.debug("Error comprobando mtime de bindings Disney: %s", e)

    _notification_lock = threading.Lock()
    _last_notification: Dict[str, float] = {}

    @classmethod
    def _notify_once(cls, key: str, message: str, interval: float = 60.0) -> None:
        import time

        now = time.monotonic()
        with cls._notification_lock:
            if now - cls._last_notification.get(key, 0.0) < interval:
                return
            cls._last_notification[key] = now
        try:
            import xbmc
            safe_message = message.replace(",", " ").replace(")", " ")[:120]
            xbmc.executebuiltin(
                f"Notification(DGO,Canal temporalmente no disponible: {safe_message},5000)"
            )
        except Exception:
            pass

    def handle_one_request(self) -> None:
        """Trata el abandono de Kodi como cancelación normal, sin traceback."""
        try:
            super().handle_one_request()
        except CLIENT_DISCONNECT_ERRORS as error:
            self.close_connection = True
            logger.debug("Cliente local canceló la petición: %s", error)

    def send_error(self, code: int, message=None, explain=None) -> None:
        try:
            super().send_error(code, message, explain)
        except CLIENT_DISCONNECT_ERRORS as error:
            self.close_connection = True
            logger.debug("Cliente local se desconectó antes del error HTTP: %s", error)

    def _write_body(self, body: bytes) -> bool:
        try:
            self.wfile.write(body)
            return True
        except CLIENT_DISCONNECT_ERRORS as error:
            self.close_connection = True
            logger.debug("Cliente local canceló la respuesta: %s", error)
            return False

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS, HEAD")
        self.send_header("Access-Control-Allow-Headers", "authorization, content-type, range, x-playback-rights-authorization")
        self.end_headers()

    def _serve_epg(self, path: str, is_head: bool = False) -> None:
        """Sirve el archivo XMLTV EPG generado localmente para Kodi IPTV Simple Client."""
        epg_xml, epg_gz = _find_epg_files()
        want_gz = path.endswith(".gz")

        target_file = None
        content_type = "application/xml; charset=utf-8"
        need_compress = False
        need_decompress = False

        if want_gz:
            if epg_gz and epg_gz.is_file():
                target_file = epg_gz
                content_type = "application/gzip"
            elif epg_xml and epg_xml.is_file():
                target_file = epg_xml
                content_type = "application/gzip"
                need_compress = True
        else:
            if epg_xml and epg_xml.is_file():
                target_file = epg_xml
                content_type = "application/xml; charset=utf-8"
            elif epg_gz and epg_gz.is_file():
                target_file = epg_gz
                content_type = "application/xml; charset=utf-8"
                need_decompress = True

        if not target_file or not target_file.is_file():
            fallback = _download_epg_fallback()
            if fallback and fallback.is_file():
                target_file = fallback
                if want_gz:
                    need_compress = True
                    content_type = "application/gzip"
                else:
                    content_type = "application/xml; charset=utf-8"
        elif (time.time() - target_file.stat().st_mtime > 12 * 3600):
            threading.Thread(
                target=lambda: _download_epg_fallback(force=True), daemon=True
            ).start()

        if not target_file or not target_file.is_file():
            self.send_error(404, "Guía EPG local no encontrada")
            return

        try:
            if is_head and not need_compress and not need_decompress:
                size = target_file.stat().st_size
                self.send_response(200)
                self.send_header("Content-Type", content_type)
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "public, max-age=3600")
                self.send_header("Content-Length", str(size))
                self.end_headers()
                return

            raw_bytes = target_file.read_bytes()
            if need_compress:
                import gzip
                raw_bytes = gzip.compress(raw_bytes, compresslevel=6)
            elif need_decompress:
                import gzip
                raw_bytes = gzip.decompress(raw_bytes)

            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Cache-Control", "public, max-age=3600")
            self.send_header("Content-Length", str(len(raw_bytes)))
            self.end_headers()
            if not is_head:
                self._write_body(raw_bytes)
        except CLIENT_DISCONNECT_ERRORS as error:
            self.close_connection = True
            logger.debug("Kodi canceló la descarga de EPG: %s", error)
        except Exception as e:
            logger.error("Error sirviendo EPG local: %s", e)
            self.send_error(500, f"Error sirviendo EPG: {e}")

    def do_HEAD(self) -> None:
        path = urllib.parse.unquote(urllib.parse.urlsplit(self.path).path)
        if path in ("/epg.xml", "/epg.xml.gz", "/epg"):
            self._serve_epg(path, is_head=True)
            return
        if "/disney/live/" in path:
            raw_slug = path.split("/disney/live/")[-1]
            binding = re.sub(r"\.(mpd|m3u8)$", "", raw_slug, flags=re.IGNORECASE).strip()
            if not binding or not re.match(r"^[a-zA-Z0-9_\-]+$", binding):
                self.send_error(400, f"Identificador de binding inválido: {binding}")
                return
            self._sync_bindings_if_modified()
            record = self.disney_registry.get_binding(binding)
            if not record:
                self.send_error(404, f"Binding Disney desconocido: {binding}")
                return
            self.send_response(200)
            self.send_header("Content-Type", "application/vnd.apple.mpegurl")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Cache-Control", "no-cache, no-store")
            self.end_headers()
        else:
            self.send_error(404, "Endpoint HEAD no reconocido")

    def do_POST(self) -> None:
        path = urllib.parse.unquote(self.path)
        if urllib.parse.urlsplit(path).path.startswith("/dgo/license/"):
            raw_id = path.split("/dgo/license/")[-1].split("?")[0].strip()
            if not raw_id:
                self.send_error(400, "Falta contentId en la ruta de licencia")
                return
            if raw_id.lower() not in DRM_ID_TO_SLUG:
                self.send_error(404, "contentId DGO desconocido")
                return

            try:
                length = int(self.headers.get("Content-Length", 0))
            except (ValueError, TypeError):
                length = 0

            if length <= 0:
                self.send_error(400, "Challenge Widevine vacío")
                return
            if length > MAX_WIDEVINE_CHALLENGE_BYTES:
                self.send_error(413, "Challenge Widevine demasiado grande")
                return

            challenge_data = self.rfile.read(length)
            if len(challenge_data) != length:
                self.send_error(400, "Challenge Widevine truncado")
                return
            try:
                status, license_bytes, _ = self.dgo_resolver.proxy_license(raw_id, challenge_data)
                self.send_response(status)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "no-cache, no-store")
                self.send_header("Content-Length", str(len(license_bytes)))
                self.end_headers()
                self._write_body(license_bytes)
            except CLIENT_DISCONNECT_ERRORS as error:
                self.close_connection = True
                logger.debug("Kodi canceló una licencia DGO en vuelo: %s", error)
            except Exception as e:
                logger.error("Error en proxy de licencia DGO %s: %s", raw_id, e)
                self.send_error(503, "Error temporal del proxy de licencia DGO")
        elif urllib.parse.urlsplit(path).path.startswith("/flow/license/"):
            raw_id = path.split("/flow/license/")[-1].split("?")[0].strip()
            if not raw_id:
                self.send_error(400, "Falta identificador de canal en la ruta de licencia Flow")
                return

            try:
                length = int(self.headers.get("Content-Length", 0))
            except (ValueError, TypeError):
                length = 0

            if length <= 0:
                self.send_error(400, "Challenge Widevine vacío")
                return
            if length > MAX_WIDEVINE_CHALLENGE_BYTES:
                self.send_error(413, "Challenge Widevine demasiado grande")
                return

            challenge_data = self.rfile.read(length)
            if len(challenge_data) != length:
                self.send_error(400, "Challenge Widevine truncado")
                return

            try:
                status, license_bytes, _ = self.flow_auth.proxy_license(raw_id, challenge_data)
                self.send_response(status)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "no-cache, no-store")
                self.send_header("Content-Length", str(len(license_bytes)))
                self.end_headers()
                self._write_body(license_bytes)
            except CLIENT_DISCONNECT_ERRORS as error:
                self.close_connection = True
                logger.debug("Kodi canceló una licencia Flow en vuelo: %s", error)
            except Exception as e:
                logger.error("Error en proxy de licencia Flow %s: %s", raw_id, e)
                self.send_error(503, "Error temporal del proxy de licencia Flow")
        elif urllib.parse.urlsplit(path).path.startswith("/disney/license/"):
            raw_id = path.split("/disney/license/")[-1].split("?")[0].strip()
            binding = re.sub(r"\.(mpd|m3u8)$", "", raw_id, flags=re.IGNORECASE).strip()
            if not binding or not re.match(r"^[a-zA-Z0-9_\-]+$", binding):
                self.send_error(400, "Identificador de binding inválido en la ruta de licencia Disney")
                return

            context = self.disney_registry.get_license_context(binding)
            if not context:
                self.send_error(404, f"Contexto de licencia Disney no encontrado o expirado para binding '{binding}'")
                return

            try:
                length = int(self.headers.get("Content-Length", 0))
            except (ValueError, TypeError):
                length = 0

            if length <= 0:
                self.send_error(400, "Challenge Widevine vacío")
                return
            if length > MAX_WIDEVINE_CHALLENGE_BYTES:
                self.send_error(413, "Challenge Widevine demasiado grande")
                return

            challenge_data = self.rfile.read(length)
            if len(challenge_data) != length:
                self.send_error(400, "Challenge Widevine truncado")
                return

            snapshot = self.disney_session.get_access_token_snapshot()
            if not snapshot:
                self.send_error(401, "Disney no autenticado o sesión expirada")
                return

            try:
                status, license_bytes, _ = self.disney_license.proxy_license(
                    binding=binding,
                    challenge_bytes=challenge_data,
                    access_token=snapshot.token,
                    context=context,
                )

                # Reintento único ante 401 inequívocamente de autenticación (incluso con body de error no vacío)
                if status == 401:
                    logger.warning(
                        "Licencia Disney devolvió 401. Intentando refresco único para generación %d...",
                        snapshot.token_generation,
                    )
                    try:
                        new_snap = self.disney_session.refresh_if_generation(
                            failed_generation=snapshot.token_generation
                        )
                        status, license_bytes, _ = self.disney_license.proxy_license(
                            binding=binding,
                            challenge_bytes=challenge_data,
                            access_token=new_snap.token,
                            context=context,
                        )
                    except Exception as ref_err:
                        logger.warning("Fallo al refrescar token para reintento de licencia: %s", ref_err)

                self.send_response(status)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "no-cache, no-store")
                self.send_header("Content-Length", str(len(license_bytes)))
                self.end_headers()
                self._write_body(license_bytes)
            except UpstreamHttpError as err:
                self.send_error(err.status, f"Error upstream Disney Widevine {err.status}")
            except CLIENT_DISCONNECT_ERRORS as error:
                self.close_connection = True
                logger.debug("Kodi canceló una licencia Disney en vuelo: %s", error)
            except Exception as e:
                logger.error("Error en proxy de licencia Disney %s: %s", binding, e)
                self.send_error(503, "Error temporal del proxy de licencia Disney")
        else:
            self.send_error(404, "Endpoint POST no reconocido")

    def do_GET(self) -> None:
        path = urllib.parse.unquote(urllib.parse.urlsplit(self.path).path)
        if path.startswith("/dgo/clearkeys/"):
            # Decisión ClearKey vs Widevine basada en el KID vivo del manifest.
            raw_slug = path.split("/dgo/clearkeys/")[-1]
            slug = re.sub(r"\.(mpd|m3u8)$", "", raw_slug, flags=re.IGNORECASE).strip().lower()
            if not slug or not re.match(r"^[a-z0-9_\-]+$", slug):
                self.send_error(400, f"Slug DGO inválido: {slug}")
                return
            try:
                status_data = self.dgo_resolver.clearkey_status(slug)
            except ValueError:
                self.send_error(404, f"Canal DGO no encontrado: {slug}")
                return
            except CLIENT_DISCONNECT_ERRORS as error:
                self.close_connection = True
                logger.debug("Kodi canceló la consulta ClearKey DGO: %s", error)
                return
            except Exception as error:  # noqa: BLE001
                logger.error("Error evaluando ClearKey DGO %s: %s", slug, error)
                self.send_error(503, f"Error evaluando ClearKey DGO {slug}")
                return
            body = json.dumps(status_data).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Cache-Control", "no-cache, no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self._write_body(body)
        elif "/dgo/live/" in path:
            raw_slug = path.split("/dgo/live/")[-1]
            requested_hls = raw_slug.lower().endswith(".m3u8")
            slug = re.sub(r"\.(mpd|m3u8)$", "", raw_slug, flags=re.IGNORECASE).strip().lower()
            query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            prefer_clearkey = (query.get("drm", [""])[0] or "").strip().lower() == "clearkey"
            try:
                if requested_hls:
                    # Las señales FAST son HLS claro. El 302 mantiene al proxy fuera
                    # del transporte de segmentos y permite que Kodi resuelva todas
                    # las playlists relativas contra la URL final de Amagi.
                    target_url = self.dgo_resolver.get_hls_url(slug)
                    self.send_response(302)
                    self.send_header("Location", target_url)
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.send_header("Cache-Control", "no-cache, no-store")
                    self.end_headers()
                else:
                    manifest_bytes = self.dgo_resolver.get_manifest(
                        slug, prefer_clearkey=prefer_clearkey
                    )
                    self.send_response(200)
                    self.send_header("Content-Type", "application/dash+xml")
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.send_header("Cache-Control", "no-cache, no-store")
                    self.send_header("Content-Length", str(len(manifest_bytes)))
                    self.end_headers()
                    self._write_body(manifest_bytes)
            except ChannelTemporarilyUnavailable as error:
                self._notify_once(slug, str(error))
                self.send_response(503, "Canal temporalmente no disponible")
                self.send_header("Retry-After", "60")
                self.send_header("Content-Length", "0")
                self.end_headers()
            except ValueError as e:
                self.send_error(404, f"Canal DGO no encontrado: {slug}")
            except CLIENT_DISCONNECT_ERRORS as error:
                self.close_connection = True
                logger.debug("Kodi canceló un manifiesto DGO en vuelo: %s", error)
            except Exception as e:
                logger.error("Error resolviendo canal DGO %s: %s", slug, e)
                self.send_error(503, f"Error resolviendo canal DGO {slug}: {e}")
        elif "/kodi/clear/" in path:
            # Manifiesto saneado: se sirve SIN la declaración de DRM falsa.
            raw_slug = path.split("/kodi/clear/")[-1]
            slug = re.sub(r"\.(mpd|m3u8)$", "", raw_slug, flags=re.IGNORECASE).strip().lower()
            entry = SLUG_MAPPINGS.get(f"clear:{slug}")
            if not isinstance(entry, dict) or not entry.get("clear_url"):
                self.send_error(404, f"Manifiesto claro no encontrado: {slug}")
                return
            try:
                body, final_url = fetch_clear_manifest(str(entry["clear_url"]))
                saneado = strip_content_protection(body, final_url)
            except Exception as e:  # noqa: BLE001
                self.send_error(503, f"Error obteniendo manifiesto {slug}: {e}")
                return
            self.send_response(200)
            self.send_header("Content-Type", "application/dash+xml")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Cache-Control", "no-cache, no-store")
            self.send_header("Content-Length", str(len(saneado)))
            self.end_headers()
            self._write_body(saneado)
        elif "/flow/live/" in path or "/kodi/live/" in path:
            prefix = "/flow/live/" if "/flow/live/" in path else "/kodi/live/"
            raw_slug = path.split(prefix)[-1]
            slug = re.sub(r"\.(mpd|m3u8)$", "", raw_slug, flags=re.IGNORECASE).strip().lower()

            entry = SLUG_MAPPINGS.get(slug)
            target_rel, err = extract_seed_rel(entry)

            if err == "slug_not_found":
                self.send_error(404, f"Canal no encontrado: {slug}")
                return
            elif err:
                self.send_error(400, f"Ruta de seed inválida para canal {slug}: {err}")
                return

            try:
                target_url = self.resolver.resolve_stream(slug, target_rel)

                self.send_response(302)
                self.send_header("Location", target_url)
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "no-cache, no-store")
                self.end_headers()
            except Exception as e:
                self.send_error(503, f"Error resolviendo canal {slug}: {e}")
        elif "/disney/live/" in path:
            raw_slug = path.split("/disney/live/")[-1]
            binding = re.sub(r"\.(mpd|m3u8)$", "", raw_slug, flags=re.IGNORECASE).strip()
            if not binding or not re.match(r"^[a-zA-Z0-9_\-]+$", binding):
                self.send_error(400, f"Identificador de binding inválido: {binding}")
                return

            # Sincronizar bindings si el radar los actualizó en disco
            self._sync_bindings_if_modified()
            record = self.disney_registry.get_binding(binding)
            if not record:
                self.send_error(404, f"Binding Disney desconocido: {binding}")
                return

            snapshot = self.disney_session.get_access_token_snapshot()
            if not snapshot:
                self.send_error(401, "Disney no autenticado o sesión expirada")
                return

            try:
                def _resolve_upstream(rec: Optional[BindingRecord] = None) -> PlaybackContext:
                    target_rec = rec if rec is not None else self.disney_registry.get_binding(binding)
                    current_res_id = target_rec.resource_id if target_rec else record.resource_id
                    current_content_type = target_rec.content_type if target_rec else record.content_type
                    current_snap = self.disney_session.get_access_token_snapshot() or snapshot
                    try:
                        return self.disney_playback.resolve(
                            resource_id=current_res_id,
                            content_type=current_content_type,
                            access_token=current_snap.token,
                        )
                    except UpstreamHttpError as err:
                        # Reintento único sólo ante 401 inequívocamente de autenticación
                        if err.status == 401:
                            logger.warning(
                                "Playback Disney devolvió 401. Intentando refresco único para generación %d...",
                                current_snap.token_generation,
                            )
                            new_snap = self.disney_session.refresh_if_generation(
                                failed_generation=current_snap.token_generation
                            )
                            return self.disney_playback.resolve(
                                resource_id=current_res_id,
                                content_type=current_content_type,
                                access_token=new_snap.token,
                            )
                        raise

                updated_record, _ = self.disney_registry.resolve_single_flight(
                    binding, _resolve_upstream
                )
                if not updated_record.playback_context:
                    self.send_error(503, f"Fallo al resolver playback context para {binding}")
                    return

                target_url = updated_record.playback_context.manifest_url
                self.send_response(302)
                self.send_header("Location", target_url)
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Cache-Control", "no-cache, no-store")
                self.end_headers()
            except UpstreamHttpError as err:
                if err.status == 401:
                    self.send_error(401, "Disney upstream: sesión no autorizada")
                elif err.status == 403:
                    self.send_error(403, "Disney upstream: contenido no habilitado o geobloqueado")
                elif err.status == 404:
                    self.send_error(404, "Disney upstream: evento o señal no disponible")
                elif err.status == 410:
                    self.send_error(410, "Disney upstream: evento finalizado")
                else:
                    self.send_error(503, f"Disney upstream error {err.status}")
            except CLIENT_DISCONNECT_ERRORS as error:
                self.close_connection = True
                logger.debug("Kodi canceló resolución de stream Disney en vuelo: %s", error)
            except Exception as e:
                logger.error("Error resolviendo stream Disney %s: %s", binding, e)
                self.send_error(503, f"Error resolviendo stream Disney: {e}")
        elif "/sensa/live/" in path:
            raw_id = path.split("/sensa/live/")[-1]
            channel_id = re.sub(r"\.(mpd|m3u8)$", "", raw_id, flags=re.IGNORECASE).strip()
            if not channel_id or not re.match(r"^[a-zA-Z0-9_\-]+$", channel_id):
                self.send_error(400, f"Identificador de canal Sensa inválido: {channel_id}")
                return
            try:
                target_url, stream_mode = self.sensa_playback.resolve(channel_id)
                if stream_mode == "direct_hls":
                    self.send_response(302)
                    self.send_header("Location", target_url)
                    self.send_header("Access-Control-Allow-Origin", "*")
                    self.send_header("Cache-Control", "no-cache, no-store")
                    self.end_headers()
                else:
                    self.send_error(
                        503,
                        "Canal protegido con Verimatrix AES-128 mTLS (DRM_KEY_MTLS_REQUIRED)",
                    )
            except SensaSessionError as e:
                self.send_error(401, f"Sesión Sensa no autorizada: {e}")
            except SensaChannelUnavailable as e:
                self.send_error(404, f"Canal Sensa no disponible: {e}")
            except CLIENT_DISCONNECT_ERRORS as error:
                self.close_connection = True
                logger.debug("Kodi canceló resolución de canal Sensa en vuelo: %s", error)
            except Exception as e:
                logger.error("Error resolviendo canal Sensa %s: %s", channel_id, e)
                self.send_error(503, f"Error resolviendo canal Sensa: {e}")
        elif path == "/sensa/status":
            status_data = self.sensa_session.get_status()
            body = json.dumps(status_data).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self._write_body(body)
        elif path == "/disney/status":
            auth = self.disney_session.is_authenticated()
            sess = self.disney_session.get_session() or {}
            exp = sess.get("expires", 0)
            status_data = {
                "provider": "disney",
                "authenticated": auth,
                "expires_at": exp,
                "profile_id": sess.get("profile_id"),
                "contract": sess.get("contract", "chrome_web"),
            }
            body = json.dumps(status_data).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self._write_body(body)
        elif path == "/dgo/status":
            try:
                status_data = self.dgo_resolver.session_status()
            except Exception as error:  # noqa: BLE001
                logger.error("Error obteniendo estado DGO: %s", error)
                status_data = {"provider": "dgo", "error": "status_unavailable"}
            body = json.dumps(status_data).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self._write_body(body)
        elif path in ("/epg.xml", "/epg.xml.gz", "/epg"):
            self._serve_epg(path, is_head=False)
        elif path == "/status" or path == "/health":
            body = b'{"status": "ok", "service": "service.iptv.flowproxy"}'
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self._write_body(body)
        else:
            self.send_error(404, "Endpoint no reconocido")

    def log_message(self, format: str, *args) -> None:
        pass


class ThreadedHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = False
    block_on_close = True
    allow_reuse_address = True

    def __init__(self, *args, max_workers: int = MAX_LOCAL_WORKERS, **kwargs):
        if max_workers < 1:
            raise ValueError("max_workers debe ser >= 1")
        self._worker_slots = threading.BoundedSemaphore(max_workers)
        super().__init__(*args, **kwargs)

    def process_request(self, request, client_address) -> None:
        # No se crean hilos sin límite cuando Kodi abandona muchos canales.
        if not self._worker_slots.acquire(timeout=0.05):
            try:
                request.sendall(
                    b"HTTP/1.1 503 Service Unavailable\r\n"
                    b"Connection: close\r\nRetry-After: 1\r\nContent-Length: 0\r\n\r\n"
                )
            except OSError:
                pass
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self._worker_slots.release()
            raise

    def process_request_thread(self, request, client_address) -> None:
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._worker_slots.release()

    def get_request(self):
        request, client_address = super().get_request()
        # Impide que un cliente local con body truncado bloquee el cierre del addon.
        request.settimeout(15.0)
        return request, client_address


def _get_dgo_resolver() -> DgoSessionResolver:
    """Devuelve el singleton usado por el handler (también para warm-up en Kodi)."""
    return FlowProxyHandler.dgo_resolver


def _get_flow_auth() -> FlowAuthManager:
    """Devuelve el singleton de autenticación oficial Flow usado por el handler."""
    return FlowProxyHandler.flow_auth


def _get_disney_registry() -> PlaybackRegistry:
    """Devuelve el registro de bindings de Disney+."""
    return FlowProxyHandler.disney_registry


def _get_disney_session() -> DisneySessionManager:
    """Devuelve el gestor de sesión Disney+."""
    return FlowProxyHandler.disney_session


def close_resolvers() -> None:
    """Cierra transportes persistentes después de terminar los handlers."""
    FlowProxyHandler.dgo_resolver.close()
    FlowProxyHandler.flow_auth.close()
    FlowProxyHandler.disney_registry.clear()
