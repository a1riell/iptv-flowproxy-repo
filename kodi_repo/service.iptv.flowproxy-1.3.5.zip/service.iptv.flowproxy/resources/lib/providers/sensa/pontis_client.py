"""Cliente REST para Pontis Cloud y Policy Rights Manager (PRM) de Sensa."""

from __future__ import annotations

import json
import logging
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from typing import Any, Dict, Optional

from .models import PlaybackResource, SensaAccount, SensaSession

logger = logging.getLogger("flowproxy_sensa_client")

DEFAULT_PONTIS_CONTROL_PLANE = "https://geo.edge.pontiscloud.com:4446"
DEFAULT_SDK_CONFIG_URL = "https://player.sensa.com.ar/sdkConfig"
DEFAULT_PLAYER_ORIGIN = "https://player.sensa.com.ar"
DEFAULT_USER_AGENT = "VisualOn OSMP 3.40"
DEFAULT_PRM_REGISTER_URL = "https://prm.pontiscloud.com:9060/policy_manager/v3/register/"
SENSA_EDGE_HOSTS = ("cdn.sensa.com.ar", "smt-usr-edge05.sensa.com.ar")

# Contexto SSL permisivo para endpoints internos de Pontis Cloud (CAs propias/no estándar)
SSL_CONTEXT = ssl.create_default_context()
SSL_CONTEXT.check_hostname = False
SSL_CONTEXT.verify_mode = ssl.CERT_NONE


def _normalise_key(value: Any) -> str:
    return str(value).replace("-", "_").lower()


def _find_value(value: Any, names: set[str]) -> Optional[Any]:
    if isinstance(value, dict):
        for key, item in value.items():
            if _normalise_key(key) in names and item not in (None, ""):
                return item
            found = _find_value(item, names)
            if found not in (None, ""):
                return found
    elif isinstance(value, list):
        for item in value:
            found = _find_value(item, names)
            if found not in (None, ""):
                return found
    return None


def _find_named_endpoint(value: Any, wanted: str) -> Optional[str]:
    if isinstance(value, dict):
        name = str(value.get("name") or value.get("id") or "").lower()
        if name == wanted.lower():
            url = value.get("baseHttpsUrl") or value.get("baseUrl") or value.get("url")
            if url:
                return str(url)
        for item in value.values():
            found = _find_named_endpoint(item, wanted)
            if found:
                return found
    elif isinstance(value, list):
        for item in value:
            found = _find_named_endpoint(item, wanted)
            if found:
                return found
    return None


def _first_playback_resource(value: Any) -> Optional[dict[str, Any]]:
    if isinstance(value, dict):
        for key, item in value.items():
            if _normalise_key(key) in {"playback_resources", "playbackresources"}:
                if isinstance(item, list):
                    return next((x for x in item if isinstance(x, dict)), None)
                if isinstance(item, dict):
                    return item
        for item in value.values():
            found = _first_playback_resource(item)
            if found:
                return found
    elif isinstance(value, list):
        for item in value:
            found = _first_playback_resource(item)
            if found:
                return found
    return None


class PontisClient:
    """Implementa provisión, sesión, registro PRM y autorización de canales Sensa."""

    def __init__(
        self,
        control_plane_url: str = DEFAULT_PONTIS_CONTROL_PLANE,
        sdk_config_url: str = DEFAULT_SDK_CONFIG_URL,
        user_agent: str = DEFAULT_USER_AGENT,
        timeout: float = 8.0,
    ) -> None:
        self.control_plane_url = control_plane_url.rstrip("/")
        self.sdk_config_url = sdk_config_url
        self.user_agent = user_agent
        self.timeout = timeout
        self._playback_cache: dict[tuple[str, str], PlaybackResource] = {}

    def _headers(self, content: bool = False) -> dict[str, str]:
        headers = {
            "User-Agent": self.user_agent,
            "Referer": f"{DEFAULT_PLAYER_ORIGIN}/",
            "Origin": DEFAULT_PLAYER_ORIGIN,
            "Accept": "application/json, text/plain, */*",
        }
        if content:
            headers["Content-Type"] = "application/json"
        return headers

    def _request_json(
        self,
        url: str,
        payload: Optional[dict[str, Any]] = None,
        extra_headers: Optional[dict[str, str]] = None,
    ) -> tuple[int, dict[str, Any], dict[str, str]]:
        body = json.dumps(payload, separators=(",", ":")).encode("utf-8") if payload is not None else None
        headers = self._headers(payload is not None)
        headers.update(extra_headers or {})
        request = urllib.request.Request(
            url,
            data=body,
            headers=headers,
            method="POST" if payload is not None else "GET",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout, context=SSL_CONTEXT) as response:
                raw = response.read().decode("utf-8", errors="replace")
                parsed = json.loads(raw) if raw else {}
                return int(getattr(response, "status", 200)), parsed if isinstance(parsed, dict) else {}, {
                    str(k).lower(): str(v) for k, v in response.headers.items()
                }
        except urllib.error.HTTPError as exc:
            raw = exc.read().decode("utf-8", errors="replace") if exc.fp else ""
            try:
                parsed = json.loads(raw) if raw else {}
            except json.JSONDecodeError:
                parsed = {}
            return exc.code, parsed if isinstance(parsed, dict) else {}, {}
        except Exception as exc:
            logger.debug("Error de red Pontis %s: %s", url, exc)
            return 0, {}, {}

    def fetch_sdk_config(self) -> Dict[str, Any]:
        """Obtiene el contrato vivo del reproductor si el endpoint está disponible."""
        status, data, _ = self._request_json(self.sdk_config_url)
        return data if status < 400 else {}

    @staticmethod
    def _device_info(account: SensaAccount) -> tuple[str, str, dict[str, str]]:
        device_id = account.device_id or (
            "cfc2366d-aae0-409e-b1ea-87f9627f5f38"
            if account.account_id == "14586001"
            else str(uuid.uuid5(uuid.NAMESPACE_URL, f"sensa:{account.account_id}:{account.device_name}"))
        )
        mac = device_id.replace("-", "").replace(":", "")[:12].upper()
        return device_id, mac, {
            "deviceName": "WindowsPC",
            "deviceModel": "WindowsPC",
            "deviceBrand": "WindowsPC",
            "deviceOs": "WindowsPC",
            "deviceType": "cloud_client",
            "deviceOsVersion": "3.4.405-LA",
            "firmwareVersion": "153.0",
            "appVersion": "3.4.405",
            "networkType": "Broadband",
            "playerType": "Webplayer",
            "mac": mac,
            "uuid": device_id,
            "casId": device_id,
        }

    def _post_candidates(
        self, path: str, payload: dict[str, Any], headers: Optional[dict[str, str]] = None
    ) -> tuple[int, dict[str, Any], dict[str, str]]:
        bases = [f"{self.control_plane_url}/xtv-ws-client", self.control_plane_url]
        last = (0, {}, {})
        for base in bases:
            result = self._request_json(f"{base}{path}", payload, headers)
            if result[0] < 400 or result[0] not in (404, 405):
                return result
            last = result
        return last

    def _provision_device(
        self, account: SensaAccount, device_id: str, device_info: dict[str, str]
    ) -> tuple[str, str]:
        credentials_payload = {
            "username": account.account_id,
            "password": account.password,
            "type": "undefined",
            "identifier": device_id,
            "deviceInfo": device_info,
        }
        status, response, _ = self._post_candidates("/api/v1/provision/credentials", credentials_payload)
        if status < 400:
            token = _find_value(response, {"devicetoken", "provisiontoken", "token"})
            if token:
                account_id = _find_value(response, {"accountid", "account_id"})
                return str(token).removeprefix("Bearer ").strip(), str(account_id or account.account_id)
        return "", ""

    def authenticate(self, account: SensaAccount) -> Optional[SensaSession]:
        """Aprovisiona el dispositivo, abre sesión y registra PRM."""
        if not account.account_id or not account.password:
            return None
        try:
            self.fetch_sdk_config()
            device_id, device_mac, device_info = self._device_info(account)
            device_token, pontis_account_id = self._provision_device(account, device_id, device_info)
            if not device_token:
                logger.debug("Pontis no devolvió deviceToken")
                return None

            status, session_data, response_headers = self._post_candidates(
                f"/api/v1/session/{pontis_account_id}",
                {"deviceToken": device_token, "deviceInfo": device_info},
            )
            if status >= 400:
                logger.debug("Pontis session respondió HTTP %s", status)
                return None

            raw_jwt = response_headers.get("authorization") or _find_value(
                session_data, {"webtoken", "sessiontoken", "accesstoken", "access_token", "jwt"}
            )
            if not raw_jwt:
                return None

            session_jwt = str(raw_jwt).removeprefix("Bearer ").strip()
            expires = _find_value(session_data, {"expiresin", "expires_in", "ttl", "lifetime"})
            expires_in = float(expires) if expires not in (None, "") else 86400.0
            prm_url = _find_named_endpoint(session_data, "prm") or ""

            session = SensaSession(
                webtoken=session_jwt,
                account_id=pontis_account_id,
                edge_host=str(_find_value(session_data, {"edgehost", "host", "cdnhost"}) or SENSA_EDGE_HOSTS[0]),
                expires_at=time.time() + max(60.0, expires_in),
                source="pontis_prm_rest",
                device_token=device_token,
                device_id=device_id,
                device_mac=device_mac,
                prm_register_url=prm_url or DEFAULT_PRM_REGISTER_URL,
            )
            if not self.register_prm(session):
                return None
            return session
        except Exception as exc:
            logger.debug("Autenticación REST Pontis falló: %s", exc)
            return None

    def _prm_headers(self, session: SensaSession) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {session.webtoken}",
            "MN-DeviceID": session.device_mac,
            "MN-CustomerID": session.account_id,
            "MN-RegionID": session.region_id,
        }

    def register_prm(self, session: SensaSession) -> bool:
        """Registra el dispositivo ante PRM y obtiene endpoints de fuentes."""
        if not session.webtoken or not session.device_mac:
            return False
        payload = {
            "appVersion": "3.4.0-18834_a7b4fe83b4",
            "deviceType": "phone",
            "networkType": "WiFi",
            "deviceModel": "Pixel 6",
            "deviceBrand": "Google",
            "deviceOs": "ANDROID",
            "playerType": "VisualOn",
            "regionId": session.region_id,
        }
        status, data, _ = self._request_json(
            session.prm_register_url or DEFAULT_PRM_REGISTER_URL,
            payload,
            self._prm_headers(session),
        )
        if status >= 400:
            logger.debug("PRM register respondió HTTP %s", status)
            return False
        session.service_session_id = str(_find_value(data, {"servicesessionid"}) or "")
        session.device_info_token = str(_find_value(data, {"deviceinfotoken"}) or "")
        session.prm_session_token = str(_find_value(data, {"prmsessiontoken"}) or "")
        session.content_source_url = str(_find_value(data, {"contentsourceurl", "content_source_url"}) or "")
        return bool(session.service_session_id and session.device_info_token and session.content_source_url)

    def acquire_playback_resource(
        self, session: SensaSession, channel_id: str | int
    ) -> Optional[PlaybackResource]:
        """Solicita a PRM un recurso HLS autorizado con mn-playback."""
        if not session.service_session_id or not session.content_source_url:
            if not self.register_prm(session):
                return None
        key = (session.service_session_id, str(channel_id))
        cached = self._playback_cache.get(key)
        if cached and cached.is_valid():
            return cached
        query = urllib.parse.urlencode({
            "contentId": str(channel_id),
            "serviceSessionId": session.service_session_id,
            "deviceInfoToken": session.device_info_token,
        })
        base = session.content_source_url.rstrip("/")
        status, data, _ = self._request_json(
            f"{base}/TV_CHANNEL/?{query}", None, self._prm_headers(session)
        )
        if status >= 400:
            logger.debug("PRM content source respondió HTTP %s", status)
            return None
        item = _first_playback_resource(data)
        if not item:
            return None
        content_url = _find_value(item, {"contenturl", "content_url"})
        playback_id = _find_value(item, {"playbackresourceid", "playback_resource_id"})
        if not content_url or not playback_id:
            return None
        try:
            cache_duration = float(_find_value(item, {"cacheduration", "cache_duration"}) or 300.0)
        except (TypeError, ValueError):
            cache_duration = 300.0
        resource = PlaybackResource(str(content_url), str(playback_id), cache_duration)
        self._playback_cache[key] = resource
        return resource

    def resolve_channel(self, session: SensaSession, channel_id: str | int) -> Optional[str]:
        """Devuelve la URL canónica HLS autorizada para el canal."""
        resource = self.acquire_playback_resource(session, channel_id)
        return resource.authorized_url if resource else None
