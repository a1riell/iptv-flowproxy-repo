"""Motor de reproducción y resolución de canales para Sensa."""

from __future__ import annotations

import logging
import re
import urllib.error
import urllib.parse
import urllib.request
from typing import Callable, Dict, Optional, Tuple

from .models import PlaybackResource
from .pontis_client import DEFAULT_USER_AGENT, SSL_CONTEXT
from .session_manager import SensaSessionManager

logger = logging.getLogger("flowproxy_sensa_playback")


class SensaPlaybackError(Exception):
    """Error base de reproducción Sensa."""


class SensaSessionError(SensaPlaybackError):
    """Error de sesión o autenticación Sensa."""


class SensaChannelUnavailable(SensaPlaybackError):
    """Canal no disponible en el catálogo de Sensa."""


def default_fetch_manifest(url: str, timeout: float = 6.0) -> str:
    """Descarga el contenido de un manifiesto HLS usando el contexto y User-Agent de Sensa."""
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": DEFAULT_USER_AGENT,
            "Accept": "*/*",
        },
    )
    with urllib.request.urlopen(req, timeout=timeout, context=SSL_CONTEXT) as response:
        return response.read().decode("utf-8", errors="replace")


def is_key_encrypted(line: str) -> bool:
    """Evalúa si una directiva EXT-X-KEY o EXT-X-SESSION-KEY indica cifrado activo."""
    match = re.search(r"METHOD=([^,\s]+)", line)
    if match:
        method = match.group(1).strip().upper().strip('"')
        return method not in {"NONE", ""}
    return True


def inspect_hls_encryption(
    manifest_url: str,
    fetcher: Callable[[str], str] = default_fetch_manifest,
) -> str:
    """Inspecciona dinámicamente un flujo HLS para determinar si utiliza cifrado.

    Devuelve:
    - 'direct_hls': si no contiene directivas de cifrado activas (#EXT-X-KEY).
    - 'encrypted_aes128': si contiene #EXT-X-KEY o #EXT-X-SESSION-KEY con método != NONE.
    """
    try:
        master_content = fetcher(manifest_url)
    except Exception as exc:
        logger.warning("Fallo al descargar manifiesto HLS %s: %s", manifest_url, exc)
        return "encrypted_aes128"

    lines = [line.strip() for line in master_content.splitlines() if line.strip()]

    # 1. Chequeo de directivas a nivel Master (ej. EXT-X-SESSION-KEY o EXT-X-KEY)
    for line in lines:
        if line.startswith("#EXT-X-SESSION-KEY:") or line.startswith("#EXT-X-KEY:"):
            if is_key_encrypted(line):
                return "encrypted_aes128"

    # 2. Si es Master Playlist con variantes (#EXT-X-STREAM-INF)
    has_variants = any(line.startswith("#EXT-X-STREAM-INF:") for line in lines)
    if has_variants:
        variant_rel = None
        for i, line in enumerate(lines):
            if line.startswith("#EXT-X-STREAM-INF:"):
                for next_line in lines[i + 1 :]:
                    if not next_line.startswith("#"):
                        variant_rel = next_line
                        break
                if variant_rel:
                    break

        if variant_rel:
            variant_url = urllib.parse.urljoin(manifest_url, variant_rel)
            try:
                variant_content = fetcher(variant_url)
                for var_line in variant_content.splitlines():
                    var_line = var_line.strip()
                    if var_line.startswith("#EXT-X-KEY:"):
                        if is_key_encrypted(var_line):
                            return "encrypted_aes128"
            except Exception as exc:
                logger.warning("Fallo al descargar playlist variante %s: %s", variant_url, exc)
                return "encrypted_aes128"

    # 3. Si no tiene directivas de cifrado ni en master ni en variante, es HLS en claro
    return "direct_hls"


class SensaPlaybackEngine:
    """Resuelve canales Sensa contra Pontis PRM y determina el modo de entrega dinámicamente."""

    def __init__(
        self,
        session_manager: SensaSessionManager,
        manifest_fetcher: Optional[Callable[[str], str]] = None,
    ) -> None:
        self.session_manager = session_manager
        self._manifest_fetcher = manifest_fetcher or default_fetch_manifest
        self._encryption_cache: Dict[str, str] = {}

    def clear_cache(self) -> None:
        """Limpia la caché en memoria de detección de cifrado."""
        self._encryption_cache.clear()

    def resolve(self, channel_id: str | int) -> Tuple[str, str]:
        """Resuelve el canal y devuelve (authorized_url, mode).

        mode puede ser:
        - 'direct_hls': canal entregable directamente sin DRM (sin directiva de clave).
        - 'encrypted_aes128': canal protegido con AES-128 y clave Verimatrix.
        """
        channel_str = str(channel_id).strip()
        session = self.session_manager.get_valid_session()
        if not session:
            raise SensaSessionError("No se pudo obtener sesión activa de Sensa")

        resource = self.session_manager.client.acquire_playback_resource(session, channel_id)
        if not resource:
            # Intento único de refresco por si la sesión de servicio expiró upstream
            session = self.session_manager.get_valid_session(force_refresh=True)
            if session:
                resource = self.session_manager.client.acquire_playback_resource(session, channel_id)

        if not resource:
            raise SensaChannelUnavailable(f"Canal {channel_id} no disponible en Pontis PRM")

        # Caché en memoria para evitar descargar el manifiesto en cada consulta
        if channel_str in self._encryption_cache:
            return resource.authorized_url, self._encryption_cache[channel_str]

        # Detección dinámica inspeccionando el manifiesto HLS
        mode = inspect_hls_encryption(resource.authorized_url, self._manifest_fetcher)
        self._encryption_cache[channel_str] = mode
        return resource.authorized_url, mode
