"""Modelos canónicos de datos para credenciales, sesiones y recursos de Sensa."""

from __future__ import annotations

from dataclasses import dataclass, field
import time
from typing import Any, Dict, Optional


@dataclass
class SensaAccount:
    """Credenciales de abonado y dispositivo para Pontis Cloud."""
    account_id: str
    password: str = ""
    device_name: str = "WebPlayer"
    device_id: str = ""

    def to_dict(self) -> Dict[str, str]:
        return {
            "account_id": self.account_id,
            "device_name": self.device_name,
            "device_id": self.device_id,
        }


@dataclass
class PlaybackResource:
    """Recurso de reproducción HLS autorizado por Pontis PRM."""
    content_url: str
    playback_resource_id: str
    cache_duration: float = 300.0
    created_at: float = field(default_factory=time.time)

    def is_valid(self) -> bool:
        return (time.time() - self.created_at) < max(30.0, self.cache_duration - 15.0)

    @property
    def authorized_url(self) -> str:
        sep = "&" if "?" in self.content_url else "?"
        return f"{self.content_url}{sep}mn-playback={self.playback_resource_id}"


@dataclass
class SensaSession:
    """Sesión Pontis activa, incluyendo el estado necesario para PRM."""
    webtoken: str
    account_id: str = ""
    edge_host: str = "cdn.sensa.com.ar"
    refresh_token: str = ""
    expires_at: Optional[float] = None
    created_at: float = field(default_factory=time.time)
    cookies: Dict[str, str] = field(default_factory=dict)
    source: str = "pontis_cloud"
    device_token: str = ""
    device_id: str = ""
    device_mac: str = ""
    prm_register_url: str = ""
    content_source_url: str = ""
    service_session_id: str = ""
    device_info_token: str = ""
    prm_session_token: str = ""
    region_id: str = "7"

    @property
    def is_expired(self) -> bool:
        """Determina si el token expiró con margen de seguridad de 60 segundos."""
        if not self.expires_at:
            return False
        return (time.time() + 60.0) >= self.expires_at

    @property
    def time_remaining_seconds(self) -> float:
        if not self.expires_at:
            return 86400.0
        return max(0.0, self.expires_at - time.time())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "account_id": self.account_id,
            "webtoken": self.webtoken,
            "edge_host": self.edge_host,
            "refresh_token": self.refresh_token,
            "expires_at": self.expires_at,
            "created_at": self.created_at,
            "cookies": self.cookies,
            "source": self.source,
            "device_token": self.device_token,
            "device_id": self.device_id,
            "device_mac": self.device_mac,
            "prm_register_url": self.prm_register_url,
            "content_source_url": self.content_source_url,
            "service_session_id": self.service_session_id,
            "device_info_token": self.device_info_token,
            "prm_session_token": self.prm_session_token,
            "region_id": self.region_id,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> SensaSession:
        return cls(
            webtoken=data.get("webtoken", ""),
            account_id=str(data.get("account_id", "")),
            edge_host=data.get("edge_host", "cdn.sensa.com.ar"),
            refresh_token=data.get("refresh_token", ""),
            expires_at=data.get("expires_at"),
            created_at=data.get("created_at", time.time()),
            cookies=data.get("cookies", {}),
            source=data.get("source", "pontis_cloud"),
            device_token=data.get("device_token", ""),
            device_id=data.get("device_id", ""),
            device_mac=data.get("device_mac", ""),
            prm_register_url=data.get("prm_register_url", ""),
            content_source_url=data.get("content_source_url", ""),
            service_session_id=data.get("service_session_id", ""),
            device_info_token=data.get("device_info_token", ""),
            prm_session_token=data.get("prm_session_token", ""),
            region_id=data.get("region_id", "7"),
        )
