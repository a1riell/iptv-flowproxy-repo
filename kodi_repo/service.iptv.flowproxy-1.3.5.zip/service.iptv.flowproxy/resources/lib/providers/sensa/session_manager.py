"""Gestor de sesión persistente y auto-renovación para Sensa / Pontis Cloud."""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
import threading
import time
from typing import Any, Dict, List, Optional

from .models import SensaAccount, SensaSession
from .pontis_client import PontisClient

logger = logging.getLogger("flowproxy_sensa_session")

DEFAULT_ACCOUNT_ID = "14586001"


class SensaSessionManager:
    """Administra el ciclo de vida de la sesión Sensa de forma concurrente y segura."""

    def __init__(
        self,
        cache_path: Optional[str] = None,
        account: Optional[SensaAccount] = None,
        client: Optional[PontisClient] = None,
    ) -> None:
        self._lock = threading.Lock()
        self.client = client or PontisClient()
        self.account = account or SensaAccount(account_id=DEFAULT_ACCOUNT_ID, password=DEFAULT_ACCOUNT_ID)
        self.cache_path = Path(cache_path) if cache_path else self._default_cache_path()
        self._cached_session: Optional[SensaSession] = None

    def _default_cache_path(self) -> Path:
        """Determina la ruta de persistencia según el entorno de ejecución."""
        try:
            import xbmcaddon
            import xbmcvfs
            addon = xbmcaddon.Addon("service.iptv.flowproxy")
            profile_dir = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
            p = Path(profile_dir) / "sensa_sessions.json"
            p.parent.mkdir(parents=True, exist_ok=True)
            return p
        except Exception:
            pass

        candidates = [
            Path.home() / ".flow_cache" / "sensa_sessions.json",
            Path.home() / ".cache" / "sensa-session-provider" / "sensa_sessions.json",
            Path.home() / ".kodi" / "userdata" / "addon_data" / "service.iptv.flowproxy" / "sensa_sessions.json",
        ]
        for c in candidates:
            if c.is_file():
                return c
        # Por defecto usar .flow_cache
        fallback = Path.home() / ".flow_cache" / "sensa_sessions.json"
        fallback.parent.mkdir(parents=True, exist_ok=True)
        return fallback

    def load_cached_session(self) -> Optional[SensaSession]:
        """Carga la sesión persistida si existe."""
        if self.cache_path.is_file():
            try:
                raw = json.loads(self.cache_path.read_text(encoding="utf-8"))
                session = SensaSession.from_dict(raw)
                if session.webtoken and not session.is_expired:
                    return session
            except Exception as e:
                logger.debug("Error leyendo caché de sesión Sensa: %s", e)
        return None

    def save_session(self, session: SensaSession) -> None:
        """Persiste la sesión con permisos restrictivos (modo 600)."""
        try:
            self.cache_path.parent.mkdir(parents=True, exist_ok=True)
            data = session.to_dict()
            tmp_path = self.cache_path.with_suffix(".tmp")
            tmp_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
            try:
                os.chmod(tmp_path, 0o600)
            except OSError:
                pass
            tmp_path.replace(self.cache_path)
            try:
                os.chmod(self.cache_path, 0o600)
            except OSError:
                pass
        except Exception as e:
            logger.warning("No se pudo persistir la sesión Sensa: %s", e)

    def get_valid_session(self, force_refresh: bool = False) -> Optional[SensaSession]:
        """Devuelve una sesión activa válida, renovándola de forma desatendida si es necesario."""
        with self._lock:
            if not force_refresh:
                if self._cached_session and not self._cached_session.is_expired:
                    return self._cached_session
                loaded = self.load_cached_session()
                if loaded and not loaded.is_expired:
                    self._cached_session = loaded
                    return loaded

            logger.info("Autenticando nueva sesión Sensa ante Pontis Cloud...")
            session = self.client.authenticate(self.account)
            if session:
                self._cached_session = session
                self.save_session(session)
                return session

            logger.error("No se pudo autenticar o renovar la sesión Sensa")
            return None

    def is_authenticated(self) -> bool:
        session = self._cached_session or self.load_cached_session()
        return bool(session and not session.is_expired)

    def get_status(self) -> Dict[str, Any]:
        """Estado resumido seguro para /status y /sensa/status."""
        session = self._cached_session or self.load_cached_session()
        if not session or session.is_expired:
            return {
                "provider": "sensa",
                "authenticated": False,
                "reason": "no_active_session",
            }
        return {
            "provider": "sensa",
            "authenticated": True,
            "account_id": session.account_id or "anon",
            "edge_host": session.edge_host,
            "expires_in_seconds": round(session.time_remaining_seconds, 1),
            "service_session_active": bool(session.service_session_id),
        }
